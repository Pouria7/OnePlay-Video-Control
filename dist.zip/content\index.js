(function() {
  "use strict";
  const DEFAULT_SHORTCUTS = {
    togglePlay: "Space",
    seekBackward: "ArrowLeft",
    seekForward: "ArrowRight",
    volumeUp: "ArrowUp",
    volumeDown: "ArrowDown",
    toggleMute: "KeyM",
    toggleFullscreen: "KeyF"
  };
  const DEFAULT_GLOBAL_SETTINGS = {
    enabled: true,
    defaultSitePolicy: "universal",
    defaultTheme: "classic-dark",
    controllerPosition: "bottom-inside",
    controlsLayout: "full",
    minWidth: 160,
    minHeight: 120,
    visibilityThreshold: 0.7,
    seekInterval: 5,
    allowMultiple: true,
    autoHideDelay: 2200,
    shortcuts: DEFAULT_SHORTCUTS
  };
  const COMMON_TWO_PART_TLDS = /* @__PURE__ */ new Set([
    "co.uk",
    "com.au",
    "co.nz",
    "co.jp",
    "com.br",
    "com.mx",
    "co.za",
    "org.uk",
    "gov.uk"
  ]);
  function normalizeDomain(rawHostname) {
    if (!rawHostname) return "";
    let host = rawHostname.toLowerCase().trim();
    if (host.includes(":")) {
      host = host.split(":")[0];
    }
    if (host.startsWith("www.")) {
      host = host.slice(4);
    }
    return host;
  }
  function extractBaseDomain(rawHostname) {
    const host = normalizeDomain(rawHostname);
    if (!host) return "";
    if (/^(\d{1,3}\.){3}\d{1,3}$/.test(host) || host === "localhost") {
      return host;
    }
    const parts = host.split(".");
    if (parts.length <= 2) {
      return host;
    }
    const lastTwo = parts.slice(-2).join(".");
    if (COMMON_TWO_PART_TLDS.has(lastTwo)) {
      if (parts.length >= 3) {
        return parts.slice(-3).join(".");
      }
      return host;
    }
    return parts.slice(-2).join(".");
  }
  function domainMatches(currentHostname, targetDomainPattern) {
    const current = normalizeDomain(currentHostname);
    const target = normalizeDomain(targetDomainPattern);
    if (!current || !target) return false;
    if (current === target) {
      return true;
    }
    if (current.endsWith(`.${target}`)) {
      return true;
    }
    if (extractBaseDomain(current) === target) {
      return true;
    }
    return false;
  }
  function getDomainFromUrl(urlOrLocation) {
    try {
      if (typeof urlOrLocation === "string") {
        const parsed = new URL(urlOrLocation);
        return extractBaseDomain(parsed.hostname);
      }
      return extractBaseDomain(urlOrLocation.hostname);
    } catch {
      return "";
    }
  }
  class StorageManager {
    inMemoryCache = {
      globalSettings: { ...DEFAULT_GLOBAL_SETTINGS },
      siteSettings: {},
      customThemes: {}
    };
    isChromeStorageAvailable() {
      return typeof chrome !== "undefined" && !!chrome.storage && (!!chrome.storage.sync || !!chrome.storage.local);
    }
    getStorageArea() {
      if (!this.isChromeStorageAvailable()) return null;
      return chrome.storage.sync || chrome.storage.local || null;
    }
    /**
     * Initializes or fetches all current settings from storage
     */
    async getAll() {
      const storage = this.getStorageArea();
      if (!storage) {
        return this.inMemoryCache;
      }
      try {
        const result = await storage.get(["globalSettings", "siteSettings", "customThemes"]);
        this.inMemoryCache = {
          globalSettings: { ...DEFAULT_GLOBAL_SETTINGS, ...result.globalSettings || {} },
          siteSettings: result.siteSettings || {},
          customThemes: result.customThemes || {}
        };
        return this.inMemoryCache;
      } catch (err) {
        console.warn("[UFVC Storage] Failed to read from chrome.storage, using in-memory cache:", err);
        return this.inMemoryCache;
      }
    }
    /**
     * Retrieves global settings
     */
    async getGlobalSettings() {
      const all = await this.getAll();
      return all.globalSettings;
    }
    /**
     * Updates global settings
     */
    async setGlobalSettings(partial) {
      const all = await this.getAll();
      all.globalSettings = { ...all.globalSettings, ...partial };
      await this.persist("globalSettings", all.globalSettings);
      return all.globalSettings;
    }
    /**
     * Retrieves settings for a specific domain
     */
    async getSiteSettings(rawDomain) {
      const domain = normalizeDomain(rawDomain);
      const all = await this.getAll();
      return all.siteSettings[domain];
    }
    /**
     * Updates or sets settings for a specific domain
     */
    async setSiteSettings(rawDomain, settings) {
      const domain = normalizeDomain(rawDomain);
      const all = await this.getAll();
      const existing = all.siteSettings[domain] || {};
      all.siteSettings[domain] = { ...existing, ...settings };
      await this.persist("siteSettings", all.siteSettings);
      return all.siteSettings[domain];
    }
    /**
     * Retrieves custom theme definitions
     */
    async getCustomThemes() {
      const all = await this.getAll();
      return all.customThemes;
    }
    /**
     * Saves or updates a custom theme definition
     */
    async saveCustomTheme(theme) {
      const all = await this.getAll();
      all.customThemes[theme.id] = theme;
      await this.persist("customThemes", all.customThemes);
    }
    /**
     * Adds an observer callback triggered whenever storage changes
     */
    onChanged(callback) {
      if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.onChanged) {
        const listener = (changes, areaName) => {
          if (areaName === "sync" || areaName === "local") {
            if (changes.globalSettings?.newValue) {
              this.inMemoryCache.globalSettings = changes.globalSettings.newValue;
            }
            if (changes.siteSettings?.newValue) {
              this.inMemoryCache.siteSettings = changes.siteSettings.newValue;
            }
            if (changes.customThemes?.newValue) {
              this.inMemoryCache.customThemes = changes.customThemes.newValue;
            }
            callback(changes);
          }
        };
        chrome.storage.onChanged.addListener(listener);
        return () => chrome.storage.onChanged.removeListener(listener);
      }
      return () => {
      };
    }
    async persist(key, value) {
      const storage = this.getStorageArea();
      if (!storage) return;
      try {
        await storage.set({ [key]: value });
      } catch (err) {
        console.warn(`[UFVC Storage] Failed to persist ${key} to primary storage, trying fallback:`, err);
        if (chrome.storage.local && storage !== chrome.storage.local) {
          try {
            await chrome.storage.local.set({ [key]: value });
          } catch (localErr) {
            console.error("[UFVC Storage] Fallback persistence failed:", localErr);
          }
        }
      }
    }
  }
  const storageManager = new StorageManager();
  function resolveEffectiveConfig(input) {
    const defaults = input.builtInDefaults ?? DEFAULT_GLOBAL_SETTINGS;
    const globalUser = input.globalUserSettings ?? {};
    const adapter = input.adapterOverrides ?? {};
    const site = input.userSiteSettings ?? {};
    function pick(siteVal, adapterVal, globalVal, defaultVal) {
      if (siteVal !== void 0) return siteVal;
      if (adapterVal !== void 0) return adapterVal;
      if (globalVal !== void 0) return globalVal;
      return defaultVal;
    }
    const policy = globalUser.defaultSitePolicy ?? defaults.defaultSitePolicy;
    let baseEnabled = globalUser.enabled ?? defaults.enabled;
    if (baseEnabled && policy === "selective" && site.enabled === void 0) {
      baseEnabled = false;
    }
    const enabled = pick(site.enabled, adapter.enabled, void 0, baseEnabled);
    const theme = pick(site.theme, adapter.theme, globalUser.defaultTheme, defaults.defaultTheme);
    const controllerPosition = pick(
      site.controllerPosition,
      adapter.controllerPosition,
      globalUser.controllerPosition,
      defaults.controllerPosition
    );
    const controlsLayout = pick(
      site.controlsLayout,
      adapter.controlsLayout,
      globalUser.controlsLayout,
      defaults.controlsLayout
    );
    const minWidth = pick(site.minWidth, adapter.minWidth, globalUser.minWidth, defaults.minWidth);
    const minHeight = pick(site.minHeight, adapter.minHeight, globalUser.minHeight, defaults.minHeight);
    const visibilityThreshold = pick(
      site.visibilityThreshold,
      adapter.visibilityThreshold,
      globalUser.visibilityThreshold,
      defaults.visibilityThreshold
    );
    const seekInterval = pick(
      site.seekInterval,
      adapter.seekInterval,
      globalUser.seekInterval,
      defaults.seekInterval
    );
    const allowMultiple = pick(
      site.allowMultiple,
      adapter.allowMultiple,
      globalUser.allowMultiple,
      defaults.allowMultiple
    );
    const autoHideDelay = pick(
      void 0,
      void 0,
      globalUser.autoHideDelay,
      defaults.autoHideDelay
    );
    const defaultShortcuts = defaults.shortcuts || DEFAULT_GLOBAL_SETTINGS.shortcuts;
    const userShortcuts = globalUser.shortcuts || {};
    const shortcuts = { ...defaultShortcuts, ...userShortcuts };
    return {
      enabled,
      theme,
      controllerPosition,
      controlsLayout,
      minWidth,
      minHeight,
      visibilityThreshold,
      seekInterval,
      allowMultiple,
      autoHideDelay,
      shortcuts
    };
  }
  const BUILTIN_THEMES = {
    "classic-dark": {
      id: "classic-dark",
      name: "Classic Dark (Default)",
      isBuiltin: true,
      properties: {
        bg: "rgba(18, 20, 24, 0.82)",
        text: "#f3f4f6",
        accent: "#38bdf8",
        accentHover: "#7dd3fc",
        border: "1px solid rgba(255, 255, 255, 0.14)",
        radius: "10px",
        blur: "blur(8px)",
        opacity: 0.95,
        shadow: "0 8px 24px -4px rgba(0, 0, 0, 0.35)",
        scale: 1
      }
    },
    midnight: {
      id: "midnight",
      name: "Midnight OLED",
      isBuiltin: true,
      properties: {
        bg: "rgba(8, 8, 10, 0.95)",
        text: "#ffffff",
        accent: "#e2e8f0",
        accentHover: "#ffffff",
        border: "1px solid rgba(255, 255, 255, 0.18)",
        radius: "8px",
        blur: "none",
        opacity: 1,
        shadow: "0 10px 30px rgba(0, 0, 0, 0.65)",
        scale: 1
      }
    },
    glass: {
      id: "glass",
      name: "Glassmorphism",
      isBuiltin: true,
      properties: {
        bg: "rgba(255, 255, 255, 0.14)",
        text: "#ffffff",
        accent: "#38bdf8",
        accentHover: "#7dd3fc",
        border: "1px solid rgba(255, 255, 255, 0.28)",
        radius: "14px",
        blur: "blur(16px) saturate(180%)",
        opacity: 0.96,
        shadow: "0 12px 32px 0 rgba(31, 38, 135, 0.37), inset 0 1px 0 0 rgba(255, 255, 255, 0.35)",
        scale: 1
      }
    },
    "ocean-blue": {
      id: "ocean-blue",
      name: "Ocean Blue",
      isBuiltin: true,
      properties: {
        bg: "rgba(15, 23, 42, 0.88)",
        text: "#f8fafc",
        accent: "#3b82f6",
        accentHover: "#60a5fa",
        border: "1px solid rgba(59, 130, 246, 0.35)",
        radius: "10px",
        blur: "blur(10px)",
        opacity: 0.98,
        shadow: "0 8px 24px -2px rgba(14, 165, 233, 0.25)",
        scale: 1
      }
    }
  };
  class ThemeEngine {
    customThemes = {};
    /**
     * Registers or updates custom theme definitions from storage
     */
    setCustomThemes(customThemes) {
      this.customThemes = {};
      for (const [id, def] of Object.entries(customThemes)) {
        this.customThemes[id] = {
          id: def.id,
          name: def.name,
          isBuiltin: false,
          properties: {
            bg: def.background,
            text: def.textColor,
            accent: def.accentColor,
            accentHover: def.accentColor,
            border: def.borderColor,
            radius: def.borderRadius,
            blur: def.backdropBlur,
            opacity: def.opacity ?? 1,
            shadow: "0 8px 24px rgba(0, 0, 0, 0.4)",
            scale: def.scale ?? 1
          }
        };
      }
    }
    /**
     * Resolves a theme by ID, falling back to classic-dark if not found
     */
    resolveTheme(themeId) {
      let effectiveId = themeId;
      if (themeId === "minimal") effectiveId = "classic-dark";
      if (themeId === "minimal-dark") effectiveId = "midnight";
      if (themeId === "accent-blue") effectiveId = "ocean-blue";
      if (BUILTIN_THEMES[effectiveId]) {
        return BUILTIN_THEMES[effectiveId];
      }
      if (this.customThemes[effectiveId]) {
        return this.customThemes[effectiveId];
      }
      return BUILTIN_THEMES["classic-dark"];
    }
    /**
     * Converts theme properties into CSS variable key-value pairs
     */
    getCssVariables(properties) {
      return {
        "--ufvc-bg": properties.bg,
        "--ufvc-text": properties.text,
        "--ufvc-accent": properties.accent,
        "--ufvc-accent-hover": properties.accentHover,
        "--ufvc-border": properties.border,
        "--ufvc-radius": properties.radius,
        "--ufvc-blur": properties.blur,
        "--ufvc-opacity": String(properties.opacity),
        "--ufvc-shadow": properties.shadow,
        "--ufvc-scale": String(properties.scale)
      };
    }
    /**
     * Injects or updates CSS variables on a controller host/container element
     */
    applyTheme(element, themeId) {
      const theme = this.resolveTheme(themeId);
      const vars = this.getCssVariables(theme.properties);
      for (const [key, value] of Object.entries(vars)) {
        element.style.setProperty(key, value);
      }
    }
  }
  const themeEngine = new ThemeEngine();
  class GenericAdapter {
    id = "generic";
    name = "Universal Generic Adapter";
    matches(_url) {
      return true;
    }
    getConfigOverrides() {
      return {};
    }
  }
  class InstagramAdapter {
    id = "instagram";
    name = "Instagram Web Adapter";
    matches(url) {
      return domainMatches(url.hostname, "instagram.com");
    }
    getConfigOverrides() {
      return {
        // Instagram feed and reel videos are at least 180x180px
        minWidth: 180,
        minHeight: 180,
        visibilityThreshold: 0.65,
        // Slightly more lenient threshold for scroll feeds
        allowMultiple: false
        // In Instagram feed/reels, user expects controls on the primary visible item
      };
    }
    /**
     * Filter out Instagram story preview thumbnails or background preloaders
     */
    filterVideo(video) {
      const rect = video.getBoundingClientRect();
      if (rect.width < 140 || rect.height < 140) {
        return false;
      }
      return true;
    }
    /**
     * Instagram-specific scoring:
     * Boost videos that are actively rendering frames in viewport
     */
    scoreVideo(_video, context) {
      let bonus = 0;
      if (context.isPlaying && context.intersectionRatio >= 0.65) {
        bonus += 150;
      }
      return bonus;
    }
    onVideoActivated(video) {
      video.style.pointerEvents = "auto";
    }
  }
  class YouTubeAdapter {
    id = "youtube";
    name = "YouTube Adapter";
    // Ensures we only attach the mouseleave listener once per preview element
    boundPreviews = /* @__PURE__ */ new WeakSet();
    audioInterceptors = /* @__PURE__ */ new WeakSet();
    matches(url) {
      return domainMatches(url.hostname, "youtube.com");
    }
    getConfigOverrides() {
      return {
        minWidth: 100,
        minHeight: 60,
        visibilityThreshold: 0.2,
        allowMultiple: false
        // Only one active preview at a time
      };
    }
    /**
     * Suppresses YouTube's automatic volume muting and event listeners on preview videos.
     */
    interceptVideoAudio(video) {
      if (this.audioInterceptors.has(video)) return;
      this.audioInterceptors.add(video);
      video.addEventListener(
        "volumechange",
        (e) => {
          e.stopImmediatePropagation();
        },
        true
        // Capture phase intercepts before YouTube's bubble/target listeners
      );
      video.removeAttribute("muted");
      if (video.muted) {
        video.muted = false;
      }
    }
    /**
     * Binds mouseleave with stopImmediatePropagation directly to ytd-video-preview once
     */
    bindPreviewElement(element) {
      if (!element || this.boundPreviews.has(element)) return;
      this.boundPreviews.add(element);
      element.addEventListener(
        "mouseleave",
        (e) => {
          e.stopImmediatePropagation();
        },
        true
      );
    }
    /**
     * YouTube Candidate Filter:
     * 1. Whitelists preview video cards (inline-player, ytd-video-preview, secondary/sidebar recommendations).
     * 2. Excludes YouTube's main watch player.
     * 3. Excludes full-screen Shorts reels.
     */
    filterVideo(video) {
      const isPreview = !!video.closest(
        "ytd-video-preview, #video-preview, #inline-preview-player, ytd-player#inline-player"
      );
      if (isPreview) {
        const previewEl = video.closest("ytd-video-preview");
        if (previewEl) {
          this.bindPreviewElement(previewEl);
        }
        return true;
      }
      const isMainWatchPlayer = !!video.closest(
        "ytd-watch-flexy, ytd-watch-grid, #player-theater-container, #full-bleed-container, #primary #player, #primary #ytd-player"
      );
      if (isMainWatchPlayer) {
        return false;
      }
      if (video.closest("ytd-shorts, ytd-reel-video-renderer")) {
        return false;
      }
      const rect = video.getBoundingClientRect();
      if (rect.width > 550 || rect.height > 420) {
        return false;
      }
      return true;
    }
    scoreVideo(_video, context) {
      if (context.isPlaying) {
        return 300;
      }
      return 100;
    }
    onVideoDetected(video) {
      this.interceptVideoAudio(video);
      const preview = video.closest("ytd-video-preview") || document.querySelector("ytd-video-preview");
      if (preview) {
        this.bindPreviewElement(preview);
      }
    }
    onVideoActivated(video) {
      this.interceptVideoAudio(video);
      const preview = video.closest("ytd-video-preview") || document.querySelector("ytd-video-preview");
      if (preview) {
        this.bindPreviewElement(preview);
      }
    }
  }
  class AdapterManager {
    adapters = [];
    genericAdapter = new GenericAdapter();
    constructor() {
      this.register(new InstagramAdapter());
      this.register(new YouTubeAdapter());
    }
    /**
     * Registers a site adapter
     */
    register(adapter) {
      this.adapters.push(adapter);
    }
    /**
     * Resolves the matching adapter for a given URL, falling back to GenericAdapter
     */
    resolve(url) {
      const urlObj = url instanceof URL ? url : new URL(url.href);
      for (const adapter of this.adapters) {
        try {
          if (adapter.matches(urlObj)) {
            return adapter;
          }
        } catch (err) {
          console.warn(`[UFVC AdapterManager] Error matching adapter ${adapter.id}:`, err);
        }
      }
      return this.genericAdapter;
    }
  }
  const adapterManager = new AdapterManager();
  var VideoLifecycleState = /* @__PURE__ */ ((VideoLifecycleState2) => {
    VideoLifecycleState2["DISCOVERED"] = "DISCOVERED";
    VideoLifecycleState2["TRACKED"] = "TRACKED";
    VideoLifecycleState2["CANDIDATE"] = "CANDIDATE";
    VideoLifecycleState2["ACTIVE"] = "ACTIVE";
    VideoLifecycleState2["INACTIVE"] = "INACTIVE";
    VideoLifecycleState2["REMOVED"] = "REMOVED";
    VideoLifecycleState2["CLEANED"] = "CLEANED";
    return VideoLifecycleState2;
  })(VideoLifecycleState || {});
  function calculateControllerPosition(videoRect, controllerWidth = 380, controllerHeight = 44, margin = 10, positionMode = "bottom-inside") {
    if (videoRect.width <= 0 || videoRect.height <= 0) {
      return { left: -9999, top: -9999, width: 0, height: 0, visible: false };
    }
    const viewportWidth = window.innerWidth || document.documentElement.clientWidth;
    const viewportHeight = window.innerHeight || document.documentElement.clientHeight;
    const isOutOfBounds = videoRect.bottom < 0 || videoRect.top > viewportHeight || videoRect.right < 0 || videoRect.left > viewportWidth;
    if (isOutOfBounds) {
      return { left: -9999, top: -9999, width: 0, height: 0, visible: false };
    }
    const minAllowed = Math.min(controllerWidth, 100);
    const actualWidth = Math.min(controllerWidth, Math.max(minAllowed, videoRect.width - margin * 2));
    let left = videoRect.left + (videoRect.width - actualWidth) / 2;
    left = Math.max(margin, Math.min(left, viewportWidth - actualWidth - margin));
    let top;
    switch (positionMode) {
      case "top-outside":
        top = videoRect.top - controllerHeight - margin;
        if (top < margin) {
          top = Math.max(margin, videoRect.top + margin);
        }
        break;
      case "top-inside":
        top = videoRect.top + margin;
        if (top + controllerHeight > videoRect.bottom - margin) {
          top = Math.max(margin, videoRect.bottom - controllerHeight - margin);
        }
        break;
      case "bottom-outside":
        top = videoRect.bottom + margin;
        const maxOutsideTop = viewportHeight - controllerHeight - margin;
        if (top > maxOutsideTop) {
          top = Math.min(maxOutsideTop, videoRect.bottom - controllerHeight - margin);
        }
        break;
      case "bottom-inside":
      default:
        top = videoRect.bottom - controllerHeight - margin;
        const maxInsideTop = viewportHeight - controllerHeight - margin;
        if (top > maxInsideTop && videoRect.top < maxInsideTop) {
          top = maxInsideTop;
        }
        const minInsideTop = Math.max(margin, videoRect.top + margin);
        top = Math.max(minInsideTop, Math.min(top, maxInsideTop));
        break;
    }
    top = Math.max(margin, Math.min(top, viewportHeight - controllerHeight - margin));
    return {
      left: Math.round(left),
      top: Math.round(top),
      width: Math.round(actualWidth),
      height: Math.round(controllerHeight),
      visible: true
    };
  }
  function calculateViewportIntersectionRatio(rect) {
    if (rect.width <= 0 || rect.height <= 0) return 0;
    const viewportWidth = window.innerWidth || document.documentElement.clientWidth;
    const viewportHeight = window.innerHeight || document.documentElement.clientHeight;
    const visibleLeft = Math.max(0, rect.left);
    const visibleTop = Math.max(0, rect.top);
    const visibleRight = Math.min(viewportWidth, rect.right);
    const visibleBottom = Math.min(viewportHeight, rect.bottom);
    const visibleWidth = Math.max(0, visibleRight - visibleLeft);
    const visibleHeight = Math.max(0, visibleBottom - visibleTop);
    const visibleArea = visibleWidth * visibleHeight;
    const totalArea = rect.width * rect.height;
    if (totalArea <= 0) return 0;
    return Math.min(1, Math.max(0, visibleArea / totalArea));
  }
  class IntersectionTracker {
    observer = null;
    callbacks = /* @__PURE__ */ new Map();
    constructor() {
      if (typeof IntersectionObserver !== "undefined") {
        const thresholds = [0, 0.1, 0.25, 0.5, 0.7, 0.8, 0.9, 1];
        this.observer = new IntersectionObserver(
          (entries) => {
            for (const entry of entries) {
              const video = entry.target;
              const cb = this.callbacks.get(video);
              if (cb) {
                cb(entry.intersectionRatio, entry);
              }
            }
          },
          { threshold: thresholds }
        );
      }
    }
    /**
     * Starts tracking intersection for a video element
     */
    observe(video, callback) {
      this.callbacks.set(video, callback);
      if (this.observer) {
        this.observer.observe(video);
      } else {
        const rect = video.getBoundingClientRect();
        const ratio = calculateViewportIntersectionRatio(rect);
        callback(ratio, null);
      }
    }
    /**
     * Stops tracking intersection for a video element
     */
    unobserve(video) {
      this.callbacks.delete(video);
      if (this.observer) {
        this.observer.unobserve(video);
      }
    }
    /**
     * Cleans up the observer completely
     */
    destroy() {
      if (this.observer) {
        this.observer.disconnect();
        this.observer = null;
      }
      this.callbacks.clear();
    }
  }
  const intersectionTracker = new IntersectionTracker();
  function getDeepActiveElement(root = document) {
    let active = root.activeElement;
    while (active && active.shadowRoot && active.shadowRoot.activeElement) {
      active = active.shadowRoot.activeElement;
    }
    return active;
  }
  function isEditableElement(element) {
    if (!element) return false;
    const tagName = element.tagName.toUpperCase();
    if (tagName === "INPUT" || tagName === "TEXTAREA" || tagName === "SELECT") {
      return true;
    }
    if (element.hasAttribute("contenteditable")) {
      const attr = element.getAttribute("contenteditable");
      if (attr === "" || attr === "true" || attr === "plaintext-only") {
        return true;
      }
    }
    if (element.closest('[contenteditable="true"], [contenteditable="plaintext-only"]')) {
      return true;
    }
    return false;
  }
  function isElementVisibleInDOM(element) {
    if (!element.isConnected) return false;
    const style = window.getComputedStyle(element);
    if (style.display === "none") return false;
    if (style.visibility === "hidden" || style.visibility === "collapse") return false;
    if (parseFloat(style.opacity || "1") <= 0.01) return false;
    return true;
  }
  function formatTime(seconds) {
    if (isNaN(seconds) || !isFinite(seconds) || seconds < 0) {
      return "0:00";
    }
    const rounded = Math.floor(seconds);
    const hrs = Math.floor(rounded / 3600);
    const mins = Math.floor(rounded % 3600 / 60);
    const secs = rounded % 60;
    const paddedSecs = secs.toString().padStart(2, "0");
    if (hrs > 0) {
      const paddedMins = mins.toString().padStart(2, "0");
      return `${hrs}:${paddedMins}:${paddedSecs}`;
    }
    return `${mins}:${paddedSecs}`;
  }
  function isCandidateVideo(video, config, customFilter) {
    if (!video || !(video instanceof HTMLVideoElement)) {
      return false;
    }
    if (!video.isConnected) {
      return false;
    }
    if (!isElementVisibleInDOM(video)) {
      return false;
    }
    const rect = video.getBoundingClientRect();
    if (rect.width < config.minWidth || rect.height < config.minHeight) {
      return false;
    }
    if (customFilter && !customFilter(video)) {
      return false;
    }
    return true;
  }
  function calculateVideoScore(video, context, visibilityThreshold = 0.7, customScorer) {
    let audibleBonus = 0;
    let playingMutedBonus = 0;
    let highVisibilityBonus = 0;
    const isAudible = context.isPlaying && !context.isMuted && context.volume > 0;
    const isPlayingMuted = context.isPlaying && (context.isMuted || context.volume === 0);
    if (isAudible) {
      audibleBonus = 1e3;
    } else if (isPlayingMuted) {
      playingMutedBonus = 500;
    }
    if (context.intersectionRatio >= visibilityThreshold) {
      highVisibilityBonus = 300;
    }
    const visibilityScore = Math.round(context.intersectionRatio * 100);
    const area = context.boundingRect.width * context.boundingRect.height;
    const dimensionScore = Math.min(50, Math.round(area / 1e4));
    let adapterBonus = 0;
    if (customScorer) {
      const custom = customScorer(video, context);
      if (custom !== null && !isNaN(custom)) {
        adapterBonus = custom;
      }
    }
    const total = audibleBonus + playingMutedBonus + highVisibilityBonus + visibilityScore + dimensionScore + adapterBonus;
    return {
      audibleBonus,
      playingMutedBonus,
      highVisibilityBonus,
      visibilityScore,
      dimensionScore,
      adapterBonus,
      total
    };
  }
  class VideoRegistry {
    records = /* @__PURE__ */ new Map();
    idCounter = 0;
    onUpdateCallback = null;
    onRemoveCallback = null;
    customFilter;
    customScorer;
    constructor(onUpdate, onRemove, hooks) {
      if (onUpdate) this.onUpdateCallback = onUpdate;
      if (onRemove) this.onRemoveCallback = onRemove;
      if (hooks) {
        this.customFilter = hooks.filterVideo;
        this.customScorer = hooks.scoreVideo;
      }
    }
    setCallbacks(onUpdate, onRemove) {
      this.onUpdateCallback = onUpdate;
      this.onRemoveCallback = onRemove;
    }
    setHooks(hooks) {
      this.customFilter = hooks.filterVideo;
      this.customScorer = hooks.scoreVideo;
    }
    /**
     * Registers a newly discovered HTMLVideoElement
     */
    register(video, config) {
      const existing = this.records.get(video);
      if (existing) {
        this.updateVideoState(video, config);
        return existing;
      }
      const videoId = `ufvc-video-${++this.idCounter}`;
      const cleanupFns = [];
      const rect = video.getBoundingClientRect();
      const record = {
        id: videoId,
        element: video,
        state: VideoLifecycleState.DISCOVERED,
        intersectionRatio: 0,
        boundingRect: rect,
        dimensions: { width: rect.width, height: rect.height },
        isPlaying: !video.paused && !video.ended && video.readyState > 2,
        isMuted: video.muted || video.volume === 0,
        volume: video.volume,
        currentTime: video.currentTime || 0,
        duration: isFinite(video.duration) ? video.duration : 0,
        playbackRate: video.playbackRate || 1,
        score: 0,
        lastUpdated: Date.now(),
        cleanupFns
      };
      this.records.set(video, record);
      record.state = VideoLifecycleState.TRACKED;
      const handleMediaEvent = () => {
        this.updateVideoState(video, config);
      };
      const events2 = [
        "play",
        "playing",
        "pause",
        "ended",
        "volumechange",
        "loadedmetadata",
        "loadeddata",
        "loadstart",
        "canplay",
        "durationchange",
        "emptied",
        "ratechange"
      ];
      events2.forEach((evt) => {
        video.addEventListener(evt, handleMediaEvent, { passive: true });
        cleanupFns.push(() => video.removeEventListener(evt, handleMediaEvent));
      });
      let lastTimeUpdate = 0;
      const handleTimeUpdate = () => {
        const now = Date.now();
        if (now - lastTimeUpdate > 250) {
          lastTimeUpdate = now;
          record.currentTime = video.currentTime;
          record.duration = isFinite(video.duration) ? video.duration : 0;
          if (this.onUpdateCallback) {
            this.onUpdateCallback(record);
          }
        }
      };
      video.addEventListener("timeupdate", handleTimeUpdate, { passive: true });
      cleanupFns.push(() => video.removeEventListener("timeupdate", handleTimeUpdate));
      intersectionTracker.observe(video, (ratio) => {
        record.intersectionRatio = ratio;
        this.updateVideoState(video, config);
      });
      cleanupFns.push(() => intersectionTracker.unobserve(video));
      if (typeof ResizeObserver !== "undefined") {
        const ro = new ResizeObserver(() => {
          const newRect = video.getBoundingClientRect();
          record.boundingRect = newRect;
          record.dimensions = { width: newRect.width, height: newRect.height };
          this.updateVideoState(video, config);
        });
        ro.observe(video);
        record.resizeObserver = ro;
        cleanupFns.push(() => ro.disconnect());
      }
      this.updateVideoState(video, config);
      return record;
    }
    /**
     * Updates state, recalculates bounding rect, candidate eligibility, and score
     */
    updateVideoState(video, config) {
      const record = this.records.get(video);
      if (!record) return;
      if (!video.isConnected) {
        this.unregister(video);
        return;
      }
      const rect = video.getBoundingClientRect();
      record.boundingRect = rect;
      record.dimensions = { width: rect.width, height: rect.height };
      record.isPlaying = !video.paused && !video.ended;
      record.isMuted = video.muted || video.volume === 0;
      record.volume = video.volume;
      record.currentTime = video.currentTime;
      record.duration = isFinite(video.duration) ? video.duration : 0;
      record.playbackRate = video.playbackRate;
      record.lastUpdated = Date.now();
      const activeFilter = this.customFilter;
      const isCandidate = isCandidateVideo(video, config, activeFilter);
      if (isCandidate) {
        if (record.state !== VideoLifecycleState.ACTIVE) {
          record.state = VideoLifecycleState.CANDIDATE;
        }
        const breakdown = calculateVideoScore(
          video,
          {
            intersectionRatio: record.intersectionRatio,
            boundingRect: record.boundingRect,
            isPlaying: record.isPlaying,
            isMuted: record.isMuted,
            volume: record.volume
          },
          config.visibilityThreshold,
          this.customScorer
        );
        record.score = breakdown.total;
        record.scoreBreakdown = breakdown;
      } else {
        record.state = VideoLifecycleState.INACTIVE;
        record.score = 0;
      }
      if (this.onUpdateCallback) {
        this.onUpdateCallback(record);
      }
    }
    /**
     * Re-evaluates all tracked videos with current config and hooks
     */
    updateAll(config) {
      for (const video of this.records.keys()) {
        this.updateVideoState(video, config);
      }
    }
    /**
     * Unregisters a video, cleans up all listeners and observers
     */
    unregister(video) {
      const record = this.records.get(video);
      if (!record) return;
      record.state = VideoLifecycleState.REMOVED;
      if (this.onRemoveCallback) {
        this.onRemoveCallback(record.id, video);
      }
      record.cleanupFns.forEach((fn) => {
        try {
          fn();
        } catch (err) {
          console.error("[UFVC Registry] Cleanup error:", err);
        }
      });
      record.cleanupFns = [];
      record.state = VideoLifecycleState.CLEANED;
      this.records.delete(video);
    }
    /**
     * Checks if an element is currently in the registry
     */
    has(video) {
      return this.records.has(video);
    }
    /**
     * Returns all currently candidate-eligible tracked videos
     */
    getCandidates() {
      const list = [];
      for (const [video, record] of this.records.entries()) {
        if (!video.isConnected) {
          this.unregister(video);
          continue;
        }
        if (record.state === VideoLifecycleState.CANDIDATE || record.state === VideoLifecycleState.ACTIVE) {
          list.push(record);
        }
      }
      return list;
    }
    /**
     * Returns a record by element
     */
    get(video) {
      return this.records.get(video);
    }
    /**
     * Returns total number of tracked videos
     */
    size() {
      return this.records.size;
    }
    /**
     * Complete teardown of all tracked videos
     */
    destroy() {
      for (const video of Array.from(this.records.keys())) {
        this.unregister(video);
      }
      this.records.clear();
    }
  }
  class VideoObserver {
    observer = null;
    callbacks;
    isScanning = false;
    constructor(callbacks) {
      this.callbacks = callbacks;
    }
    /**
     * Starts observing the DOM for video additions and removals
     */
    start() {
      this.scanInitialVideos();
      if (typeof MutationObserver !== "undefined" && document.documentElement) {
        this.observer = new MutationObserver((mutations) => {
          for (const mutation of mutations) {
            if (mutation.type === "childList") {
              for (let i = 0; i < mutation.addedNodes.length; i++) {
                const node = mutation.addedNodes[i];
                if (node.nodeType === Node.ELEMENT_NODE) {
                  const el = node;
                  if (el instanceof HTMLVideoElement) {
                    this.callbacks.onVideoAdded(el);
                  } else if (el.querySelectorAll) {
                    const videos = el.querySelectorAll("video");
                    videos.forEach((v) => this.callbacks.onVideoAdded(v));
                  }
                }
              }
              for (let i = 0; i < mutation.removedNodes.length; i++) {
                const node = mutation.removedNodes[i];
                if (node.nodeType === Node.ELEMENT_NODE) {
                  const el = node;
                  if (el instanceof HTMLVideoElement) {
                    this.callbacks.onVideoRemoved(el);
                  } else if (el.querySelectorAll) {
                    const videos = el.querySelectorAll("video");
                    videos.forEach((v) => this.callbacks.onVideoRemoved(v));
                  }
                }
              }
            }
          }
        });
        this.observer.observe(document.documentElement, {
          childList: true,
          subtree: true
        });
      }
    }
    /**
     * Scans for existing video elements in document
     */
    scanInitialVideos() {
      if (this.isScanning) return;
      this.isScanning = true;
      try {
        const existingVideos = document.querySelectorAll("video");
        existingVideos.forEach((v) => {
          this.callbacks.onVideoAdded(v);
        });
      } finally {
        this.isScanning = false;
      }
    }
    /**
     * Disconnects the MutationObserver
     */
    stop() {
      if (this.observer) {
        this.observer.disconnect();
        this.observer = null;
      }
    }
  }
  function selectActiveVideos(candidates, config, customSelector) {
    if (!candidates || candidates.length === 0) {
      return [];
    }
    if (customSelector) {
      const customResult = customSelector(candidates);
      if (customResult !== null) {
        return customResult;
      }
    }
    const audiblePlaying = candidates.filter(
      (c) => c.isPlaying && !c.isMuted && c.volume > 0 && c.intersectionRatio > 0.05
    );
    const mutedPlaying = candidates.filter(
      (c) => c.isPlaying && (c.isMuted || c.volume === 0) && c.intersectionRatio > 0.1
    );
    const visiblePaused = candidates.filter(
      (c) => !c.isPlaying && c.intersectionRatio >= config.visibilityThreshold
    );
    if (audiblePlaying.length > 0) {
      if (!config.allowMultiple) {
        return [audiblePlaying.sort((a, b) => b.score - a.score)[0]];
      }
      return audiblePlaying.sort((a, b) => b.score - a.score);
    }
    const highlyVisiblePlaying = mutedPlaying.filter(
      (c) => c.intersectionRatio >= config.visibilityThreshold
    );
    if (highlyVisiblePlaying.length > 0) {
      if (!config.allowMultiple) {
        return [highlyVisiblePlaying.sort((a, b) => b.score - a.score)[0]];
      }
      return highlyVisiblePlaying.sort((a, b) => b.score - a.score);
    }
    if (mutedPlaying.length > 0) {
      const sortedMuted = [...mutedPlaying].sort((a, b) => {
        if (Math.abs(b.intersectionRatio - a.intersectionRatio) > 0.05) {
          return b.intersectionRatio - a.intersectionRatio;
        }
        return b.score - a.score;
      });
      if (!config.allowMultiple) {
        return [sortedMuted[0]];
      }
      const topRatio = sortedMuted[0].intersectionRatio;
      return sortedMuted.filter((c) => c.intersectionRatio >= Math.max(0.25, topRatio - 0.15));
    }
    if (visiblePaused.length > 0) {
      const sortedPaused = [...visiblePaused].sort((a, b) => b.score - a.score);
      if (!config.allowMultiple) {
        return [sortedPaused[0]];
      }
      return sortedPaused;
    }
    return [];
  }
  const ICONS = {
    play: `<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M8 5v14l11-7z"/></svg>`,
    pause: `<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>`,
    seekBack: `<svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"/><text x="12" y="15.5" font-size="7.5" font-weight="700" font-family="system-ui, -apple-system, sans-serif" text-anchor="middle" fill="currentColor">5</text></svg>`,
    seekForward: `<svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M12 5V1l5 5-5 5V7c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6h2c0 4.42-3.58 8-8 8s-8-3.58-8-8 3.58-8 8-8z"/><text x="12" y="15.5" font-size="7.5" font-weight="700" font-family="system-ui, -apple-system, sans-serif" text-anchor="middle" fill="currentColor">5</text></svg>`,
    volumeHigh: `<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>`,
    volumeLow: `<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M18.5 12c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM5 9v6h4l5 5V4L9 9H5z"/></svg>`,
    volumeMute: `<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg>`,
    fullscreen: `<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg>`,
    download: `<svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/></svg>`
  };
  function createShadowUI() {
    const host = document.createElement("div");
    host.className = "ufvc-controller-root";
    host.style.cssText = `
    position: fixed;
    z-index: 2147483647;
    pointer-events: none;
    transition: opacity 0.25s ease, transform 0.25s ease;
    user-select: none;
    -webkit-user-select: none;
  `;
    const shadowRoot = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = `
    :host {
      all: initial;
      direction: ltr !important;
      unicode-bidi: isolate !important;
      box-sizing: border-box !important;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif !important;
      font-size: 13px !important;
      line-height: 1 !important;
      pointer-events: none !important;
    }

    *, *::before, *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    .ufvc-bar {
      display: flex;
      align-items: center;
      gap: 6px;
      width: 100%;
      height: 100%;
      padding: 0 10px;
      background: var(--ufvc-bg, rgba(18, 20, 24, 0.76));
      color: var(--ufvc-text, #f3f4f6);
      border: var(--ufvc-border, 1px solid rgba(255, 255, 255, 0.12));
      border-radius: var(--ufvc-radius, 10px);
      backdrop-filter: var(--ufvc-blur, blur(8px));
      -webkit-backdrop-filter: var(--ufvc-blur, blur(8px));
      box-shadow: var(--ufvc-shadow, 0 8px 24px -4px rgba(0, 0, 0, 0.35));
      opacity: var(--ufvc-opacity, 0.95);
      transform: scale(var(--ufvc-scale, 1.0));
      transform-origin: bottom center;
      pointer-events: auto;
      transition: opacity 0.25s ease, transform 0.2s ease, background 0.2s ease, display 0.25s ease allow-discrete;
    }

    @starting-style {
      .ufvc-bar {
        opacity: 0;
      }
    }

    /* Single-row layout (default) */
    .ufvc-row-top,
    .ufvc-row-bottom {
      display: contents;
    }

    .ufvc-play-btn { order: 1; }
    .ufvc-seek-back-btn { order: 2; }
    .ufvc-seek-forward-btn { order: 3; }
    .ufvc-time { order: 4; }
    .ufvc-progress-container { order: 5; flex: 1; }
    .ufvc-volume-wrapper { order: 6; }
    .ufvc-speed-wrapper { order: 7; }
    .ufvc-fullscreen-btn { order: 8; }

    /* Responsive Two-row layout for small / compact videos */
    .ufvc-bar.two-row {
      flex-direction: column;
      justify-content: center;
      gap: 4px;
      padding: 6px 10px;
    }

    .ufvc-bar.two-row .ufvc-row-top {
      display: flex;
      align-items: center;
      gap: 8px;
      width: 100%;
      height: 22px;
    }

    .ufvc-bar.two-row .ufvc-row-bottom {
      display: flex;
      align-items: center;
      justify-content: space-between;
      width: 100%;
      height: 28px;
    }

    .ufvc-bar.two-row .ufvc-progress-container {
      order: 1;
      flex: 1;
    }

    .ufvc-bar.two-row .ufvc-time {
      order: 2;
    }

    /* Mini non-interactive progress bar (shown in minimal mode) */
    .ufvc-mini-progress-container {
      display: none;
    }
    .ufvc-mini-progress {
      position: absolute;
      bottom: 0;
      width: 100%;
      height: 3px;
      background: rgba(255, 255, 255, 0.15);
      pointer-events: none;
      overflow: hidden;
    }

    /* Minimal controls mode: compact floating pill */
    .ufvc-bar.minimal-mode {
      position: relative;
      width: 118px;
      height: 34px;
      padding: 0 6px 3px 6px;
      justify-content: center;
      gap: 4px;
      border-radius: var(--ufvc-radius, 10px);
    }

    .ufvc-bar.minimal-mode .ufvc-row-top,
    .ufvc-bar.minimal-mode .ufvc-time,
    .ufvc-bar.minimal-mode .ufvc-progress-container,
    .ufvc-bar.minimal-mode .ufvc-volume-wrapper,
    .ufvc-bar.minimal-mode .ufvc-speed-wrapper,
    .ufvc-bar.minimal-mode .ufvc-fullscreen-btn {
      display: none !important;
    }

    .ufvc-bar.minimal-mode .ufvc-row-bottom {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      width: 100%;
      height: 100%;
    }

    .ufvc-bar.minimal-mode .ufvc-btn {
      padding: 4px 6px;
      border-radius: 6px;
    }

    /* Button order: Seek Back (left), Play/Pause (center), Seek Forward (right) */
    .ufvc-bar.minimal-mode .ufvc-seek-back-btn { order: 1; }
    .ufvc-bar.minimal-mode .ufvc-play-btn { order: 2; }
    .ufvc-bar.minimal-mode .ufvc-seek-forward-btn { order: 3; }

    /* Non-interactive slim progress line underneath */
    .ufvc-bar.minimal-mode .ufvc-mini-progress-container {
      display: block;
      position: absolute;
      height: var(--ufvc-radius, 10px);
      left: 0;
      bottom: 0;
      right: 0;
      overflow: clip;
      border-radius: 0 0 var(--ufvc-radius, 10px) var(--ufvc-radius, 10px)
    }

    .ufvc-bar.minimal-mode .ufvc-mini-progress-bar {
      height: 100%;
      width: 0%;
      background: var(--ufvc-accent, #38bdf8);
      transition: width 0.12s linear;
    }

    .ufvc-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      background: transparent;
      border: none;
      color: inherit;
      cursor: pointer;
      padding: 5px;
      border-radius: 6px;
      transition: background 0.15s ease, color 0.15s ease, transform 0.1s ease;
      flex-shrink: 0;
    }

    .ufvc-btn:hover {
      background: rgba(255, 255, 255, 0.15);
      color: var(--ufvc-accent-hover, #ffffff);
    }

    .ufvc-btn:active {
      transform: scale(0.92);
    }

    .ufvc-time {
      font-size: 11px;
      font-variant-numeric: tabular-nums;
      font-weight: 500;
      color: rgba(255, 255, 255, 0.85);
      white-space: nowrap;
      flex-shrink: 0;
    }

    /* Progress bar */
    .ufvc-progress-container {
      position: relative;
      flex: 1;
      height: 16px;
      display: flex;
      align-items: center;
      cursor: pointer;
      touch-action: none;
      min-width: 60px;
    }

    .ufvc-progress-track {
      position: relative;
      width: 100%;
      height: 4px;
      background: rgba(255, 255, 255, 0.2);
      border-radius: 2px;
      overflow: hidden;
      transition: height 0.15s ease;
    }

    .ufvc-progress-container:hover .ufvc-progress-track {
      height: 6px;
    }

    .ufvc-buffer-bar {
      position: absolute;
      left: 0;
      top: 0;
      height: 100%;
      width: 0%;
      background: rgba(255, 255, 255, 0.3);
      border-radius: 2px;
    }

    .ufvc-progress-bar {
      position: absolute;
      left: 0;
      top: 0;
      height: 100%;
      width: 0%;
      background: var(--ufvc-accent, #38bdf8);
      border-radius: 2px;
    }

    .ufvc-scrub-thumb {
      position: absolute;
      left: 0%;
      top: 50%;
      transform: translate(-50%, -50%) scale(0);
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: #ffffff;
      box-shadow: 0 1px 4px rgba(0,0,0,0.5);
      transition: transform 0.15s ease;
      pointer-events: none;
    }

    .ufvc-progress-container:hover .ufvc-scrub-thumb,
    .ufvc-progress-container.dragging .ufvc-scrub-thumb {
      transform: translate(-50%, -50%) scale(1);
    }

    /* Tooltip */
    .ufvc-time-tooltip {
      position: absolute;
      bottom: 22px;
      left: 0;
      transform: translateX(-50%);
      background: rgba(0, 0, 0, 0.85);
      color: #ffffff;
      padding: 3px 6px;
      font-size: 10px;
      font-weight: 500;
      border-radius: 4px;
      pointer-events: none;
      white-space: nowrap;
      opacity: 0;
      transition: opacity 0.12s ease;
    }

    .ufvc-progress-container:hover .ufvc-time-tooltip {
      opacity: 1;
    }

    /* Volume wrapper */
    .ufvc-volume-wrapper {
      position: relative;
      display: flex;
      align-items: center;
    }

    .ufvc-volume-slider-box {
      display: none;
      position: absolute;
      bottom: 30px;
      left: 50%;
      transform: translateX(-50%);
      background: var(--ufvc-bg, rgba(18, 20, 24, 0.9));
      padding: 8px 10px;
      border-radius: 8px;
      border: var(--ufvc-border, 1px solid rgba(255, 255, 255, 0.12));
      box-shadow: var(--ufvc-shadow, 0 4px 16px rgba(0,0,0,0.4));
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      height: 90px;
      align-items: center;
      justify-content: center;
    }

    .ufvc-volume-wrapper:hover .ufvc-volume-slider-box,
    .ufvc-volume-slider-box.active {
      display: flex;
    }

    .ufvc-volume-slider-box::before {
      content: '';
      position: absolute;
      bottom: -10px;
      left: 0;
      right: 0;
      height: 10px;
    }

    .ufvc-bar.popups-down .ufvc-volume-slider-box {
      bottom: auto;
      top: 34px;
    }

    .ufvc-bar.popups-down .ufvc-volume-slider-box::before {
      top: -10px;
      bottom: auto;
    }

    .ufvc-bar.popups-down .ufvc-speed-menu {
      bottom: auto;
      top: 34px;
    }

  .ufvc-volume-slider {
    -webkit-appearance: none;
    appearance: none;
    writing-mode: vertical-lr;
    direction: rtl;
    width: 4px;
    height: 74px;
    background: var(--ufvc-text, rgba(255, 255, 255, 0.15));
    border-radius: var(--ufvc-radius, 9999px);
    outline: none;
    cursor: pointer;
    transition: width 0.2s ease, opacity 0.2s ease;
  }


.ufvc-volume-slider:hover {
    width: 6px;
  }


  .ufvc-volume-slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 12px;
    height: 12px;
    background: var(--ufvc-accent, #38bdf8);
    border-radius: 50%;
    box-shadow: var(--ufvc-shadow, 0 0 8px rgba(56, 189, 248, 0.4));
    transition: transform 0.15s ease, background-color 0.15s ease;
  }

  .ufvc-volume-slider::-webkit-slider-thumb:hover {
    transform: scale(1.25);
    background: var(--ufvc-accent-hover, #7dd3fc);
  }


  .ufvc-volume-slider::-moz-range-thumb {
    width: 12px;
    height: 12px;
    background: var(--ufvc-accent, #38bdf8);
    border: none;
    border-radius: 50%;
    box-shadow: var(--ufvc-shadow, 0 0 8px rgba(56, 189, 248, 0.4));
    transition: transform 0.15s ease, background-color 0.15s ease;
  }

  .ufvc-volume-slider::-moz-range-thumb:hover {
    transform: scale(1.25);
    background: var(--ufvc-accent-hover, #7dd3fc);
  }

    /* Speed Menu */
    .ufvc-speed-wrapper {
      position: relative;
    }

    .ufvc-speed-btn {
      font-size: 11px;
      font-weight: 600;
      padding: 4px 6px;
      min-width: 34px;
    }

    .ufvc-speed-menu {
      display: none;
      position: absolute;
      bottom: 34px;
      left: 50%;
      transform: translateX(-50%);
      background: var(--ufvc-bg, rgba(18, 20, 24, 0.95));
      border: var(--ufvc-border, 1px solid rgba(255, 255, 255, 0.12));
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.5);
      padding: 4px;
      flex-direction: column;
      gap: 2px;
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      z-index: 10;
      max-height: 210px;
      overflow-y: auto;
    }

    .ufvc-speed-menu::-webkit-scrollbar {
      width: 4px;
    }
    .ufvc-speed-menu::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.3);
      border-radius: 2px;
    }

    .ufvc-speed-menu.open {
      display: flex;
    }

    .ufvc-speed-item {
      background: transparent;
      border: none;
      color: #e5e7eb;
      font-size: 11px;
      font-weight: 500;
      padding: 4px 10px;
      border-radius: 4px;
      cursor: pointer;
      text-align: center;
      transition: background 0.1s ease;
    }

    .ufvc-speed-item:hover {
      background: rgba(255, 255, 255, 0.15);
      color: #ffffff;
    }

    .ufvc-speed-item.active {
      background: var(--ufvc-accent, #38bdf8);
      color: #000000;
      font-weight: 700;
    }

    /* HTML Context Menu */
    .ufvc-context-menu {
      display: none;
      position: absolute;
      background: var(--ufvc-bg, rgba(18, 20, 24, 0.95));
      border: var(--ufvc-border, 1px solid rgba(255, 255, 255, 0.15));
      border-radius: 8px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.5);
      padding: 4px;
      flex-direction: column;
      gap: 2px;
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      z-index: 100;
      min-width: 140px;
    }

    .ufvc-context-menu.open {
      display: flex;
    }

    .ufvc-context-item {
      display: flex;
      align-items: center;
      gap: 8px;
      background: transparent;
      border: none;
      color: #e5e7eb;
      font-size: 12px;
      font-weight: 500;
      padding: 6px 10px;
      border-radius: 6px;
      cursor: pointer;
      text-align: left;
      width: 100%;
      white-space: nowrap;
      transition: background 0.12s ease, color 0.12s ease;
    }

    .ufvc-context-item:hover {
      background: rgba(255, 255, 255, 0.15);
      color: #ffffff;
    }

    .ufvc-context-item:active {
      background: rgba(255, 255, 255, 0.25);
    }

    .ufvc-context-item svg {
      flex-shrink: 0;
    }

    /* Stream Recording Indicator */
    .ufvc-rec-indicator {
      display: inline-flex;
      align-items: center;
      gap: 3px;
      font-size: 10px;
      font-weight: 700;
      color: #ef4444;
      background: rgba(239, 68, 68, 0.16);
      border: 1px solid rgba(239, 68, 68, 0.45);
      padding: 1px 5px;
      border-radius: 4px;
      flex-shrink: 0;
    }

    .ufvc-rec-dot {
      font-size: 10px;
      animation: ufvc-pulse 1s infinite;
    }

    @keyframes ufvc-pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.2; }
    }

    /* Auto-hide fade */
    .ufvc-bar.idle {
      opacity: 0 !important;
      display: none !important;
      pointer-events: none !important;
    }
  `;
    shadowRoot.appendChild(style);
    const container = document.createElement("div");
    container.className = "ufvc-bar";
    container.innerHTML = `
    <div class="ufvc-row-top">
      <div class="ufvc-progress-container" title="Seek (Left/Right Arrow)">
        <div class="ufvc-progress-track">
          <div class="ufvc-buffer-bar"></div>
          <div class="ufvc-progress-bar"></div>
        </div>
        <div class="ufvc-scrub-thumb"></div>
        <div class="ufvc-time-tooltip">0:00</div>
      </div>

      <div class="ufvc-rec-indicator" style="display: none;" title="Recording stream in progress">
        <span class="ufvc-rec-dot">●</span> <span>REC</span> <span class="ufvc-rec-time">0:00</span>
      </div>

      <div class="ufvc-time">
        <span class="ufvc-current-time">0:00</span> / <span class="ufvc-duration">0:00</span>
      </div>
    </div>

    <div class="ufvc-row-bottom">
      <button class="ufvc-btn ufvc-play-btn" title="Play/Pause (Space)" aria-label="Play or Pause">
        <span class="ufvc-icon-play">${ICONS.play}</span>
        <span class="ufvc-icon-pause" style="display:none;">${ICONS.pause}</span>
      </button>

      <button class="ufvc-btn ufvc-seek-back-btn" title="Seek -5s (←)" aria-label="Seek Backward 5 Seconds">
        ${ICONS.seekBack}
      </button>

      <button class="ufvc-btn ufvc-seek-forward-btn" title="Seek +5s (→)" aria-label="Seek Forward 5 Seconds">
        ${ICONS.seekForward}
      </button>

      <div class="ufvc-volume-wrapper">
        <button class="ufvc-btn ufvc-volume-btn" title="Mute/Unmute" aria-label="Mute or Unmute">
          <span class="ufvc-icon-vol-high">${ICONS.volumeHigh}</span>
          <span class="ufvc-icon-vol-low" style="display:none;">${ICONS.volumeLow}</span>
          <span class="ufvc-icon-vol-mute" style="display:none;">${ICONS.volumeMute}</span>
        </button>
        <div class="ufvc-volume-slider-box">
          <input type="range" class="ufvc-volume-slider" min="0" max="1" step="0.05" value="1" title="Volume (Up/Down Arrow)">
        </div>
      </div>

      <div class="ufvc-speed-wrapper">
        <button class="ufvc-btn ufvc-speed-btn" title="Playback Speed">1x</button>
        <div class="ufvc-speed-menu">
          <button class="ufvc-speed-item" data-speed="0.5">0.5x</button>
          <button class="ufvc-speed-item" data-speed="0.75">0.75x</button>
          <button class="ufvc-speed-item active" data-speed="1">1x</button>
          <button class="ufvc-speed-item" data-speed="1.25">1.25x</button>
          <button class="ufvc-speed-item" data-speed="1.5">1.5x</button>
          <button class="ufvc-speed-item" data-speed="1.75">1.75x</button>
          <button class="ufvc-speed-item" data-speed="2">2x</button>
          <button class="ufvc-speed-item" data-speed="2.5">2.5x</button>
          <button class="ufvc-speed-item" data-speed="3">3x</button>
        </div>
      </div>

      <button class="ufvc-btn ufvc-fullscreen-btn" title="Toggle Fullscreen" aria-label="Toggle Fullscreen">
        ${ICONS.fullscreen}
      </button>
    </div>

    <div class="ufvc-mini-progress-container">
       <div class="ufvc-mini-progress">
          <div class="ufvc-mini-progress-bar"></div>
       </div>
    </div>

    <div class="ufvc-context-menu" role="menu">
      <button class="ufvc-context-item ufvc-context-download" role="menuitem" title="Download Video">
        ${ICONS.download}
        <span>Download Video</span>
      </button>
    </div>
  `;
    shadowRoot.appendChild(container);
    return {
      host,
      shadowRoot,
      container,
      playPauseBtn: container.querySelector(".ufvc-play-btn"),
      playIcon: container.querySelector(".ufvc-icon-play"),
      pauseIcon: container.querySelector(".ufvc-icon-pause"),
      timeDisplay: container.querySelector(".ufvc-time"),
      currentTimeSpan: container.querySelector(".ufvc-current-time"),
      durationSpan: container.querySelector(".ufvc-duration"),
      progressContainer: container.querySelector(".ufvc-progress-container"),
      progressBar: container.querySelector(".ufvc-progress-bar"),
      bufferBar: container.querySelector(".ufvc-buffer-bar"),
      scrubThumb: container.querySelector(".ufvc-scrub-thumb"),
      timeTooltip: container.querySelector(".ufvc-time-tooltip"),
      volumeBtn: container.querySelector(".ufvc-volume-btn"),
      volumeHighIcon: container.querySelector(".ufvc-icon-vol-high"),
      volumeLowIcon: container.querySelector(".ufvc-icon-vol-low"),
      volumeMuteIcon: container.querySelector(".ufvc-icon-vol-mute"),
      volumeSliderContainer: container.querySelector(".ufvc-volume-slider-box"),
      volumeSlider: container.querySelector(".ufvc-volume-slider"),
      speedBtn: container.querySelector(".ufvc-speed-btn"),
      speedMenu: container.querySelector(".ufvc-speed-menu"),
      fullscreenBtn: container.querySelector(".ufvc-fullscreen-btn"),
      seekBackBtn: container.querySelector(".ufvc-seek-back-btn"),
      seekForwardBtn: container.querySelector(".ufvc-seek-forward-btn"),
      miniProgressBar: container.querySelector(".ufvc-mini-progress-bar"),
      contextMenu: container.querySelector(".ufvc-context-menu"),
      contextDownloadBtn: container.querySelector(".ufvc-context-download"),
      recIndicator: container.querySelector(".ufvc-rec-indicator"),
      recTime: container.querySelector(".ufvc-rec-time")
    };
  }
  function rafThrottle(fn) {
    let isTicking = false;
    let lastArgs = null;
    return function(...args) {
      lastArgs = args;
      if (!isTicking) {
        isTicking = true;
        requestAnimationFrame(() => {
          isTicking = false;
          if (lastArgs) {
            fn.apply(this, lastArgs);
            lastArgs = null;
          }
        });
      }
    };
  }
  function debounce(fn, waitMs) {
    let timeoutId = null;
    return function(...args) {
      if (timeoutId !== null) {
        clearTimeout(timeoutId);
      }
      timeoutId = setTimeout(() => {
        timeoutId = null;
        fn.apply(this, args);
      }, waitMs);
    };
  }
  class PositionManager {
    video;
    hostElement;
    containerElement;
    config;
    cleanupListeners = [];
    isDestroyed = false;
    lastLeft = -1;
    lastTop = -1;
    lastWidth = -1;
    lastHeight = -1;
    constructor(video, hostElement, containerElement, config) {
      this.video = video;
      this.hostElement = hostElement;
      this.containerElement = containerElement;
      this.config = config;
      this.attachListeners();
      this.updatePosition();
      this.startPeriodicPositionCheck();
    }
    /**
     * Updates configuration and recalculates position
     */
    updateConfig(newConfig) {
      this.config = newConfig;
      this.updatePosition();
    }
    /**
     * Recalculates and applies fixed position coordinates
     */
    updatePosition = rafThrottle(() => {
      if (this.isDestroyed || !this.video.isConnected) return;
      const videoRect = this.video.getBoundingClientRect();
      this.lastLeft = videoRect.left;
      this.lastTop = videoRect.top;
      this.lastWidth = videoRect.width;
      this.lastHeight = videoRect.height;
      const isMinimal = this.config.controlsLayout === "minimal";
      this.containerElement.classList.toggle("minimal-mode", isMinimal);
      let controllerWidth;
      let controllerHeight;
      if (isMinimal) {
        this.containerElement.classList.remove("two-row");
        controllerWidth = 118;
        controllerHeight = 34;
      } else {
        const isNarrow = videoRect.width < 340;
        this.containerElement.classList.toggle("two-row", isNarrow);
        controllerWidth = 390;
        controllerHeight = isNarrow ? 62 : 44;
      }
      const pos = calculateControllerPosition(
        videoRect,
        controllerWidth,
        controllerHeight,
        10,
        this.config.controllerPosition
      );
      if (!pos.visible) {
        this.hostElement.style.opacity = "0";
        this.hostElement.style.pointerEvents = "none";
        return;
      }
      this.hostElement.style.left = `${pos.left}px`;
      this.hostElement.style.top = `${pos.top}px`;
      this.hostElement.style.width = `${pos.width}px`;
      this.hostElement.style.height = `${pos.height}px`;
      this.hostElement.style.opacity = "1";
      this.hostElement.style.pointerEvents = "none";
      this.containerElement.classList.toggle("popups-down", pos.top < 250);
    });
    attachListeners() {
      const handleUpdate = () => {
        this.updatePosition();
      };
      window.addEventListener("scroll", handleUpdate, { passive: true, capture: true });
      window.addEventListener("resize", handleUpdate, { passive: true });
      window.addEventListener("mousemove", handleUpdate, { passive: true });
      document.addEventListener("fullscreenchange", handleUpdate, { passive: true });
      this.cleanupListeners.push(() => {
        window.removeEventListener("scroll", handleUpdate, { capture: true });
        window.removeEventListener("resize", handleUpdate);
        window.removeEventListener("mousemove", handleUpdate);
        document.removeEventListener("fullscreenchange", handleUpdate);
      });
    }
    /**
     * Periodic check to detect position changes when element is moved via JavaScript/CSS transforms
     * without scrolling (e.g. YouTube moving single preview card or carousel sliding).
     */
    startPeriodicPositionCheck() {
      const intervalId = setInterval(() => {
        if (this.isDestroyed || !this.video.isConnected) return;
        const r = this.video.getBoundingClientRect();
        if (Math.abs(r.left - this.lastLeft) > 1 || Math.abs(r.top - this.lastTop) > 1 || Math.abs(r.width - this.lastWidth) > 1 || Math.abs(r.height - this.lastHeight) > 1) {
          this.updatePosition();
        }
      }, 250);
      this.cleanupListeners.push(() => clearInterval(intervalId));
    }
    /**
     * Destroys position tracking and cleans up listeners
     */
    destroy() {
      this.isDestroyed = true;
      this.cleanupListeners.forEach((fn) => fn());
      this.cleanupListeners = [];
    }
  }
  function getBestVideoSource(video) {
    if (video.currentSrc && !video.currentSrc.startsWith("blob:")) {
      return video.currentSrc;
    }
    if (video.src && !video.src.startsWith("blob:")) {
      return video.src;
    }
    const sources = video.querySelectorAll("source");
    for (let i = 0; i < sources.length; i++) {
      const s = sources[i].getAttribute("src") || sources[i].src;
      if (s && !s.startsWith("blob:")) return s;
    }
    const dataSrc = video.getAttribute("data-src") || video.getAttribute("data-orig-src") || video.getAttribute("data-video-src");
    if (dataSrc && !dataSrc.startsWith("blob:")) return dataSrc;
    const ogVideo = document.querySelector('meta[property="og:video:secure_url"]')?.getAttribute("content") || document.querySelector('meta[property="og:video"]')?.getAttribute("content") || document.querySelector('meta[name="twitter:player:stream"]')?.getAttribute("content");
    if (ogVideo && !ogVideo.startsWith("blob:")) return ogVideo;
    return video.currentSrc || video.src || (sources[0] ? sources[0].getAttribute("src") || sources[0].src : "");
  }
  function deriveFilename(src) {
    try {
      const urlObj = new URL(src, window.location.href);
      const baseName = urlObj.pathname.substring(urlObj.pathname.lastIndexOf("/") + 1);
      if (baseName && /\.(mp4|webm|mkv|mov)$/i.test(baseName)) {
        return baseName.split("?")[0];
      }
      const pageTitle = document.title.replace(/[/\\?%*:|"<>]/g, "_").trim() || "video";
      return `${pageTitle.slice(0, 50)}.mp4`;
    } catch {
      return `video_${Date.now()}.mp4`;
    }
  }
  function getDefaultExportFromCjs(x) {
    return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
  }
  var lib = {};
  var ebml = {};
  var EBML = {};
  var hasRequiredEBML;
  function requireEBML() {
    if (hasRequiredEBML) return EBML;
    hasRequiredEBML = 1;
    Object.defineProperty(EBML, "__esModule", { value: true });
    return EBML;
  }
  var EBMLDecoder = {};
  var int64Buffer = {};
  var hasRequiredInt64Buffer;
  function requireInt64Buffer() {
    if (hasRequiredInt64Buffer) return int64Buffer;
    hasRequiredInt64Buffer = 1;
    (function(exports) {
      !(function(exports2) {
        var UNDEFINED = "undefined";
        var BUFFER = UNDEFINED !== typeof Buffer && Buffer;
        var UINT8ARRAY = UNDEFINED !== typeof Uint8Array && Uint8Array;
        var ARRAYBUFFER = UNDEFINED !== typeof ArrayBuffer && ArrayBuffer;
        var ZERO = [0, 0, 0, 0, 0, 0, 0, 0];
        var isArray = Array.isArray || _isArray;
        var BIT32 = 4294967296;
        var BIT24 = 16777216;
        var storage;
        factory("Uint64BE", true, true);
        factory("Int64BE", true, false);
        factory("Uint64LE", false, true);
        factory("Int64LE", false, false);
        function factory(name, bigendian, unsigned) {
          var posH = bigendian ? 0 : 4;
          var posL = bigendian ? 4 : 0;
          var pos0 = bigendian ? 0 : 3;
          var pos1 = bigendian ? 1 : 2;
          var pos2 = bigendian ? 2 : 1;
          var pos3 = bigendian ? 3 : 0;
          var fromPositive = bigendian ? fromPositiveBE : fromPositiveLE;
          var fromNegative = bigendian ? fromNegativeBE : fromNegativeLE;
          var proto = Int64.prototype;
          var isName = "is" + name;
          var _isInt64 = "_" + isName;
          proto.buffer = void 0;
          proto.offset = 0;
          proto[_isInt64] = true;
          proto.toNumber = toNumber;
          proto.toString = toString;
          proto.toJSON = toNumber;
          proto.toArray = toArray;
          if (BUFFER) proto.toBuffer = toBuffer;
          if (UINT8ARRAY) proto.toArrayBuffer = toArrayBuffer;
          Int64[isName] = isInt64;
          exports2[name] = Int64;
          return Int64;
          function Int64(buffer2, offset, value, raddix) {
            if (!(this instanceof Int64)) return new Int64(buffer2, offset, value, raddix);
            return init(this, buffer2, offset, value, raddix);
          }
          function isInt64(b) {
            return !!(b && b[_isInt64]);
          }
          function init(that, buffer2, offset, value, raddix) {
            if (UINT8ARRAY && ARRAYBUFFER) {
              if (buffer2 instanceof ARRAYBUFFER) buffer2 = new UINT8ARRAY(buffer2);
              if (value instanceof ARRAYBUFFER) value = new UINT8ARRAY(value);
            }
            if (!buffer2 && !offset && !value && !storage) {
              that.buffer = newArray(ZERO, 0);
              return;
            }
            if (!isValidBuffer(buffer2, offset)) {
              var _storage = storage || Array;
              raddix = offset;
              value = buffer2;
              offset = 0;
              buffer2 = storage === BUFFER ? BUFFER.alloc(8) : new _storage(8);
            }
            that.buffer = buffer2;
            that.offset = offset |= 0;
            if (UNDEFINED === typeof value) return;
            if ("string" === typeof value) {
              fromString(buffer2, offset, value, raddix || 10);
            } else if (isValidBuffer(value, raddix)) {
              fromArray(buffer2, offset, value, raddix);
            } else if ("number" === typeof raddix) {
              writeInt32(buffer2, offset + posH, value);
              writeInt32(buffer2, offset + posL, raddix);
            } else if (value > 0) {
              fromPositive(buffer2, offset, value);
            } else if (value < 0) {
              fromNegative(buffer2, offset, value);
            } else {
              fromArray(buffer2, offset, ZERO, 0);
            }
          }
          function fromString(buffer2, offset, str, raddix) {
            var pos = 0;
            var len = str.length;
            var high = 0;
            var low = 0;
            if (str[0] === "-") pos++;
            var sign = pos;
            while (pos < len) {
              var chr = parseInt(str[pos++], raddix);
              if (!(chr >= 0)) break;
              low = low * raddix + chr;
              high = high * raddix + Math.floor(low / BIT32);
              low %= BIT32;
            }
            if (sign) {
              high = ~high;
              if (low) {
                low = BIT32 - low;
              } else {
                high++;
              }
            }
            writeInt32(buffer2, offset + posH, high);
            writeInt32(buffer2, offset + posL, low);
          }
          function toNumber() {
            var buffer2 = this.buffer;
            var offset = this.offset;
            var high = readInt32(buffer2, offset + posH);
            var low = readInt32(buffer2, offset + posL);
            if (!unsigned) high |= 0;
            return high ? high * BIT32 + low : low;
          }
          function toString(radix) {
            var buffer2 = this.buffer;
            var offset = this.offset;
            var high = readInt32(buffer2, offset + posH);
            var low = readInt32(buffer2, offset + posL);
            var str = "";
            var sign = !unsigned && high & 2147483648;
            if (sign) {
              high = ~high;
              low = BIT32 - low;
            }
            radix = radix || 10;
            while (1) {
              var mod = high % radix * BIT32 + low;
              high = Math.floor(high / radix);
              low = Math.floor(mod / radix);
              str = (mod % radix).toString(radix) + str;
              if (!high && !low) break;
            }
            if (sign) {
              str = "-" + str;
            }
            return str;
          }
          function writeInt32(buffer2, offset, value) {
            buffer2[offset + pos3] = value & 255;
            value = value >> 8;
            buffer2[offset + pos2] = value & 255;
            value = value >> 8;
            buffer2[offset + pos1] = value & 255;
            value = value >> 8;
            buffer2[offset + pos0] = value & 255;
          }
          function readInt32(buffer2, offset) {
            return buffer2[offset + pos0] * BIT24 + (buffer2[offset + pos1] << 16) + (buffer2[offset + pos2] << 8) + buffer2[offset + pos3];
          }
        }
        function toArray(raw) {
          var buffer2 = this.buffer;
          var offset = this.offset;
          storage = null;
          if (raw !== false && isArray(buffer2)) {
            return buffer2.length === 8 ? buffer2 : buffer2.slice(offset, offset + 8);
          }
          return newArray(buffer2, offset);
        }
        function toBuffer(raw) {
          var buffer2 = this.buffer;
          var offset = this.offset;
          storage = BUFFER;
          if (raw !== false && BUFFER.isBuffer(buffer2)) {
            return buffer2.length === 8 ? buffer2 : buffer2.slice(offset, offset + 8);
          }
          return BUFFER.from(toArrayBuffer.call(this, raw));
        }
        function toArrayBuffer(raw) {
          var buffer2 = this.buffer;
          var offset = this.offset;
          var arrbuf = buffer2.buffer;
          storage = UINT8ARRAY;
          if (raw !== false && !buffer2.offset && arrbuf instanceof ARRAYBUFFER) {
            return arrbuf.byteLength === 8 ? arrbuf : arrbuf.slice(offset, offset + 8);
          }
          var dest = new UINT8ARRAY(8);
          fromArray(dest, 0, buffer2, offset);
          return dest.buffer;
        }
        function isValidBuffer(buffer2, offset) {
          var len = buffer2 && buffer2.length;
          offset |= 0;
          return len && offset + 8 <= len && "string" !== typeof buffer2[offset];
        }
        function fromArray(destbuf, destoff, srcbuf, srcoff) {
          destoff |= 0;
          srcoff |= 0;
          for (var i = 0; i < 8; i++) {
            destbuf[destoff++] = srcbuf[srcoff++] & 255;
          }
        }
        function newArray(buffer2, offset) {
          return Array.prototype.slice.call(buffer2, offset, offset + 8);
        }
        function fromPositiveBE(buffer2, offset, value) {
          var pos = offset + 8;
          while (pos > offset) {
            buffer2[--pos] = value & 255;
            value /= 256;
          }
        }
        function fromNegativeBE(buffer2, offset, value) {
          var pos = offset + 8;
          value++;
          while (pos > offset) {
            buffer2[--pos] = -value & 255 ^ 255;
            value /= 256;
          }
        }
        function fromPositiveLE(buffer2, offset, value) {
          var end = offset + 8;
          while (offset < end) {
            buffer2[offset++] = value & 255;
            value /= 256;
          }
        }
        function fromNegativeLE(buffer2, offset, value) {
          var end = offset + 8;
          value++;
          while (offset < end) {
            buffer2[offset++] = -value & 255 ^ 255;
            value /= 256;
          }
        }
        function _isArray(val) {
          return !!val && "[object Array]" == Object.prototype.toString.call(val);
        }
      })(typeof exports.nodeName !== "string" ? exports : int64Buffer || {});
    })(int64Buffer);
    return int64Buffer;
  }
  var tools = {};
  var EBMLEncoder = {};
  var ebmlID = {};
  var hasRequiredEbmlID;
  function requireEbmlID() {
    if (hasRequiredEbmlID) return ebmlID;
    hasRequiredEbmlID = 1;
    Object.defineProperty(ebmlID, "__esModule", { value: true });
    ebmlID.byEbmlID = void 0;
    ebmlID.byEbmlID = {
      128: {
        name: "ChapterDisplay",
        level: 4,
        type: "m",
        multiple: true,
        minver: 1,
        webm: true,
        description: "Contains all possible strings to use for the chapter display."
      },
      131: {
        name: "TrackType",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 1,
        range: "1-254",
        description: "A set of track types coded on 8 bits (1: video, 2: audio, 3: complex, 0x10: logo, 0x11: subtitle, 0x12: buttons, 0x20: control)."
      },
      133: {
        name: "ChapString",
        cppname: "ChapterString",
        level: 5,
        type: "8",
        mandatory: true,
        minver: 1,
        webm: true,
        description: "Contains the string to use as the chapter atom."
      },
      134: {
        name: "CodecID",
        level: 3,
        type: "s",
        mandatory: true,
        minver: 1,
        description: "An ID corresponding to the codec, see the codec page for more info."
      },
      136: {
        name: "FlagDefault",
        cppname: "TrackFlagDefault",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 1,
        "default": 1,
        range: "0-1",
        description: "Set if that track (audio, video or subs) SHOULD be active if no language found matches the user preference. (1 bit)"
      },
      137: {
        name: "ChapterTrackNumber",
        level: 5,
        type: "u",
        mandatory: true,
        multiple: true,
        minver: 1,
        webm: false,
        range: "not 0",
        description: "UID of the Track to apply this chapter too. In the absense of a control track, choosing this chapter will select the listed Tracks and deselect unlisted tracks. Absense of this element indicates that the Chapter should be applied to any currently used Tracks."
      },
      145: {
        name: "ChapterTimeStart",
        level: 4,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: true,
        description: "Timestamp of the start of Chapter (not scaled)."
      },
      146: {
        name: "ChapterTimeEnd",
        level: 4,
        type: "u",
        minver: 1,
        webm: false,
        description: "Timestamp of the end of Chapter (timestamp excluded, not scaled)."
      },
      150: {
        name: "CueRefTime",
        level: 5,
        type: "u",
        mandatory: true,
        minver: 2,
        webm: false,
        description: "Timestamp of the referenced Block."
      },
      151: {
        name: "CueRefCluster",
        level: 5,
        type: "u",
        mandatory: true,
        webm: false,
        description: "The Position of the Cluster containing the referenced Block."
      },
      152: {
        name: "ChapterFlagHidden",
        level: 4,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        "default": 0,
        range: "0-1",
        description: "If a chapter is hidden (1), it should not be available to the user interface (but still to Control Tracks; see flag notes). (1 bit)"
      },
      16980: {
        name: "ContentCompAlgo",
        level: 6,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        "default": 0,
        // "br": [ "", "", "", "" ],
        // "del": [ "1 - bzlib,", "2 - lzo1x" ],
        description: "The compression algorithm used. Algorithms that have been specified so far are: 0 - zlib,   3 - Header Stripping"
      },
      16981: {
        name: "ContentCompSettings",
        level: 6,
        type: "b",
        minver: 1,
        webm: false,
        description: "Settings that might be needed by the decompressor. For Header Stripping (ContentCompAlgo=3), the bytes that were removed from the beggining of each frames of the track."
      },
      17026: {
        name: "DocType",
        level: 1,
        type: "s",
        mandatory: true,
        "default": "matroska",
        minver: 1,
        description: "A string that describes the type of document that follows this EBML header. 'matroska' in our case or 'webm' for webm files."
      },
      17029: {
        name: "DocTypeReadVersion",
        level: 1,
        type: "u",
        mandatory: true,
        "default": 1,
        minver: 1,
        description: "The minimum DocType version an interpreter has to support to read this file."
      },
      17030: {
        name: "EBMLVersion",
        level: 1,
        type: "u",
        mandatory: true,
        "default": 1,
        minver: 1,
        description: "The version of EBML parser used to create the file."
      },
      17031: {
        name: "DocTypeVersion",
        level: 1,
        type: "u",
        mandatory: true,
        "default": 1,
        minver: 1,
        description: "The version of DocType interpreter used to create the file."
      },
      17476: {
        name: "SegmentFamily",
        level: 2,
        type: "b",
        multiple: true,
        minver: 1,
        webm: false,
        bytesize: 16,
        description: "A randomly generated unique ID that all segments related to each other must use (128 bits)."
      },
      17505: {
        name: "DateUTC",
        level: 2,
        type: "d",
        minver: 1,
        description: "Date of the origin of timestamp (value 0), i.e. production date."
      },
      17540: {
        name: "TagDefault",
        level: 4,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        "default": 1,
        range: "0-1",
        description: "Indication to know if this is the default/original language to use for the given tag. (1 bit)"
      },
      17541: {
        name: "TagBinary",
        level: 4,
        type: "b",
        minver: 1,
        webm: false,
        description: "The values of the Tag if it is binary. Note that this cannot be used in the same SimpleTag as TagString."
      },
      17543: {
        name: "TagString",
        level: 4,
        type: "8",
        minver: 1,
        webm: false,
        description: "The value of the Element."
      },
      17545: {
        name: "Duration",
        level: 2,
        type: "f",
        minver: 1,
        range: "> 0",
        description: "Duration of the segment (based on TimecodeScale)."
      },
      17816: {
        name: "ChapterFlagEnabled",
        level: 4,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        "default": 1,
        range: "0-1",
        description: "Specify wether the chapter is enabled. It can be enabled/disabled by a Control Track. When disabled, the movie should skip all the content between the TimeStart and TimeEnd of this chapter (see flag notes). (1 bit)"
      },
      18016: {
        name: "FileMimeType",
        level: 3,
        type: "s",
        mandatory: true,
        minver: 1,
        webm: false,
        description: "MIME type of the file."
      },
      18017: {
        name: "FileUsedStartTime",
        level: 3,
        type: "u",
        divx: true,
        description: "DivX font extension"
      },
      18018: {
        name: "FileUsedEndTime",
        level: 3,
        type: "u",
        divx: true,
        description: "DivX font extension"
      },
      18037: {
        name: "FileReferral",
        level: 3,
        type: "b",
        webm: false,
        description: "A binary value that a track/codec can refer to when the attachment is needed."
      },
      20529: {
        name: "ContentEncodingOrder",
        level: 5,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        "default": 0,
        description: "Tells when this modification was used during encoding/muxing starting with 0 and counting upwards. The decoder/demuxer has to start with the highest order number it finds and work its way down. This value has to be unique over all ContentEncodingOrder elements in the segment."
      },
      20530: {
        name: "ContentEncodingScope",
        level: 5,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        "default": 1,
        range: "not 0",
        // "br": [ "", "", "" ],
        description: "A bit field that describes which elements have been modified in this way. Values (big endian) can be OR'ed. Possible values: 1 - all frame contents, 2 - the track's private data, 4 - the next ContentEncoding (next ContentEncodingOrder. Either the data inside ContentCompression and/or ContentEncryption)"
      },
      20531: {
        name: "ContentEncodingType",
        level: 5,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        "default": 0,
        // "br": [ "", "" ],
        description: "A value describing what kind of transformation has been done. Possible values: 0 - compression, 1 - encryption"
      },
      20532: {
        name: "ContentCompression",
        level: 5,
        type: "m",
        minver: 1,
        webm: false,
        description: "Settings describing the compression used. Must be present if the value of ContentEncodingType is 0 and absent otherwise. Each block must be decompressable even if no previous block is available in order not to prevent seeking."
      },
      20533: {
        name: "ContentEncryption",
        level: 5,
        type: "m",
        minver: 1,
        webm: false,
        description: "Settings describing the encryption used. Must be present if the value of ContentEncodingType is 1 and absent otherwise."
      },
      21368: {
        name: "CueBlockNumber",
        level: 4,
        type: "u",
        minver: 1,
        "default": 1,
        range: "not 0",
        description: "Number of the Block in the specified Cluster."
      },
      22100: {
        name: "ChapterStringUID",
        level: 4,
        type: "8",
        mandatory: false,
        minver: 3,
        webm: true,
        description: "A unique string ID to identify the Chapter. Use for WebVTT cue identifier storage."
      },
      22337: {
        name: "WritingApp",
        level: 2,
        type: "8",
        mandatory: true,
        minver: 1,
        description: 'Writing application ("mkvmerge-0.3.3").'
      },
      22612: {
        name: "SilentTracks",
        cppname: "ClusterSilentTracks",
        level: 2,
        type: "m",
        minver: 1,
        webm: false,
        description: "The list of tracks that are not used in that part of the stream. It is useful when using overlay tracks on seeking. Then you should decide what track to use."
      },
      25152: {
        name: "ContentEncoding",
        level: 4,
        type: "m",
        mandatory: true,
        multiple: true,
        minver: 1,
        webm: false,
        description: "Settings for one content encoding like compression or encryption."
      },
      25188: {
        name: "BitDepth",
        cppname: "AudioBitDepth",
        level: 4,
        type: "u",
        minver: 1,
        range: "not 0",
        description: "Bits per sample, mostly used for PCM."
      },
      25906: {
        name: "SignedElement",
        level: 3,
        type: "b",
        multiple: true,
        webm: false,
        description: "An element ID whose data will be used to compute the signature."
      },
      26148: {
        name: "TrackTranslate",
        level: 3,
        type: "m",
        multiple: true,
        minver: 1,
        webm: false,
        description: "The track identification for the given Chapter Codec."
      },
      26897: {
        name: "ChapProcessCommand",
        cppname: "ChapterProcessCommand",
        level: 5,
        type: "m",
        multiple: true,
        minver: 1,
        webm: false,
        description: "Contains all the commands associated to the Atom."
      },
      26914: {
        name: "ChapProcessTime",
        cppname: "ChapterProcessTime",
        level: 6,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        description: "Defines when the process command should be handled (0: during the whole chapter, 1: before starting playback, 2: after playback of the chapter)."
      },
      26916: {
        name: "ChapterTranslate",
        level: 2,
        type: "m",
        multiple: true,
        minver: 1,
        webm: false,
        description: "A tuple of corresponding ID used by chapter codecs to represent this segment."
      },
      26931: {
        name: "ChapProcessData",
        cppname: "ChapterProcessData",
        level: 6,
        type: "b",
        mandatory: true,
        minver: 1,
        webm: false,
        description: "Contains the command information. The data should be interpreted depending on the ChapProcessCodecID value. For ChapProcessCodecID = 1, the data correspond to the binary DVD cell pre/post commands."
      },
      26948: {
        name: "ChapProcess",
        cppname: "ChapterProcess",
        level: 4,
        type: "m",
        multiple: true,
        minver: 1,
        webm: false,
        description: "Contains all the commands associated to the Atom."
      },
      26965: {
        name: "ChapProcessCodecID",
        cppname: "ChapterProcessCodecID",
        level: 5,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        "default": 0,
        description: "Contains the type of the codec used for the processing. A value of 0 means native Matroska processing (to be defined), a value of 1 means the DVD command set is used. More codec IDs can be added later."
      },
      29555: {
        name: "Tag",
        level: 2,
        type: "m",
        mandatory: true,
        multiple: true,
        minver: 1,
        webm: false,
        description: "Element containing elements specific to Tracks/Chapters."
      },
      29572: {
        name: "SegmentFilename",
        level: 2,
        type: "8",
        minver: 1,
        webm: false,
        description: "A filename corresponding to this segment."
      },
      29766: {
        name: "AttachmentLink",
        cppname: "TrackAttachmentLink",
        level: 3,
        type: "u",
        minver: 1,
        webm: false,
        range: "not 0",
        description: "The UID of an attachment that is used by this codec."
      },
      2459272: {
        name: "CodecName",
        level: 3,
        type: "8",
        minver: 1,
        description: "A human-readable string specifying the codec."
      },
      408125543: {
        name: "Segment",
        level: "0",
        type: "m",
        mandatory: true,
        multiple: true,
        minver: 1,
        description: "This element contains all other top-level (level 1) elements. Typically a Matroska file is composed of 1 segment."
      },
      17530: {
        name: "TagLanguage",
        level: 4,
        type: "s",
        mandatory: true,
        minver: 1,
        webm: false,
        "default": "und",
        description: "Specifies the language of the tag specified, in the Matroska languages form."
      },
      17827: {
        name: "TagName",
        level: 4,
        type: "8",
        mandatory: true,
        minver: 1,
        webm: false,
        description: "The name of the Tag that is going to be stored."
      },
      26568: {
        name: "SimpleTag",
        cppname: "TagSimple",
        level: 3,
        "recursive": "1",
        type: "m",
        mandatory: true,
        multiple: true,
        minver: 1,
        webm: false,
        description: "Contains general information about the target."
      },
      25542: {
        name: "TagAttachmentUID",
        level: 4,
        type: "u",
        multiple: true,
        minver: 1,
        webm: false,
        "default": 0,
        description: "A unique ID to identify the Attachment(s) the tags belong to. If the value is 0 at this level, the tags apply to all the attachments in the Segment."
      },
      25540: {
        name: "TagChapterUID",
        level: 4,
        type: "u",
        multiple: true,
        minver: 1,
        webm: false,
        "default": 0,
        description: "A unique ID to identify the Chapter(s) the tags belong to. If the value is 0 at this level, the tags apply to all chapters in the Segment."
      },
      25545: {
        name: "TagEditionUID",
        level: 4,
        type: "u",
        multiple: true,
        minver: 1,
        webm: false,
        "default": 0,
        description: "A unique ID to identify the EditionEntry(s) the tags belong to. If the value is 0 at this level, the tags apply to all editions in the Segment."
      },
      25541: {
        name: "TagTrackUID",
        level: 4,
        type: "u",
        multiple: true,
        minver: 1,
        webm: false,
        "default": 0,
        description: "A unique ID to identify the Track(s) the tags belong to. If the value is 0 at this level, the tags apply to all tracks in the Segment."
      },
      25546: {
        name: "TargetType",
        cppname: "TagTargetType",
        level: 4,
        type: "s",
        minver: 1,
        webm: false,
        "strong": "informational",
        description: 'An  string that can be used to display the logical level of the target like "ALBUM", "TRACK", "MOVIE", "CHAPTER", etc (see TargetType).'
      },
      26826: {
        name: "TargetTypeValue",
        cppname: "TagTargetTypeValue",
        level: 4,
        type: "u",
        minver: 1,
        webm: false,
        "default": 50,
        description: "A number to indicate the logical level of the target (see TargetType)."
      },
      25536: {
        name: "Targets",
        cppname: "TagTargets",
        level: 3,
        type: "m",
        mandatory: true,
        minver: 1,
        webm: false,
        description: "Contain all UIDs where the specified meta data apply. It is empty to describe everything in the segment."
      },
      307544935: {
        name: "Tags",
        level: 1,
        type: "m",
        multiple: true,
        minver: 1,
        webm: false,
        description: "Element containing elements specific to Tracks/Chapters. A list of valid tags can be found here."
      },
      17677: {
        name: "ChapProcessPrivate",
        cppname: "ChapterProcessPrivate",
        level: 5,
        type: "b",
        minver: 1,
        webm: false,
        description: 'Some optional data attached to the ChapProcessCodecID information. For ChapProcessCodecID = 1, it is the "DVD level" equivalent.'
      },
      17278: {
        name: "ChapCountry",
        cppname: "ChapterCountry",
        level: 5,
        type: "s",
        multiple: true,
        minver: 1,
        webm: false,
        description: "The countries corresponding to the string, same 2 octets as in Internet domains."
      },
      17276: {
        name: "ChapLanguage",
        cppname: "ChapterLanguage",
        level: 5,
        type: "s",
        mandatory: true,
        multiple: true,
        minver: 1,
        webm: true,
        "default": "eng",
        description: "The languages corresponding to the string, in the bibliographic ISO-639-2 form."
      },
      143: {
        name: "ChapterTrack",
        level: 4,
        type: "m",
        minver: 1,
        webm: false,
        description: "List of tracks on which the chapter applies. If this element is not present, all tracks apply"
      },
      25539: {
        name: "ChapterPhysicalEquiv",
        level: 4,
        type: "u",
        minver: 1,
        webm: false,
        description: 'Specify the physical equivalent of this ChapterAtom like "DVD" (60) or "SIDE" (50), see complete list of values.'
      },
      28348: {
        name: "ChapterSegmentEditionUID",
        level: 4,
        type: "u",
        minver: 1,
        webm: false,
        range: "not 0",
        description: "The EditionUID to play from the segment linked in ChapterSegmentUID."
      },
      28263: {
        name: "ChapterSegmentUID",
        level: 4,
        type: "b",
        minver: 1,
        webm: false,
        range: ">0",
        bytesize: 16,
        description: "A segment to play in place of this chapter. Edition ChapterSegmentEditionUID should be used for this segment, otherwise no edition is used."
      },
      29636: {
        name: "ChapterUID",
        level: 4,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: true,
        range: "not 0",
        description: "A unique ID to identify the Chapter."
      },
      182: {
        name: "ChapterAtom",
        level: 3,
        "recursive": "1",
        type: "m",
        mandatory: true,
        multiple: true,
        minver: 1,
        webm: true,
        description: "Contains the atom information to use as the chapter atom (apply to all tracks)."
      },
      17885: {
        name: "EditionFlagOrdered",
        level: 3,
        type: "u",
        minver: 1,
        webm: false,
        "default": 0,
        range: "0-1",
        description: "Specify if the chapters can be defined multiple times and the order to play them is enforced. (1 bit)"
      },
      17883: {
        name: "EditionFlagDefault",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        "default": 0,
        range: "0-1",
        description: "If a flag is set (1) the edition should be used as the default one. (1 bit)"
      },
      17853: {
        name: "EditionFlagHidden",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        "default": 0,
        range: "0-1",
        description: "If an edition is hidden (1), it should not be available to the user interface (but still to Control Tracks; see flag notes). (1 bit)"
      },
      17852: {
        name: "EditionUID",
        level: 3,
        type: "u",
        minver: 1,
        webm: false,
        range: "not 0",
        description: "A unique ID to identify the edition. It's useful for tagging an edition."
      },
      17849: {
        name: "EditionEntry",
        level: 2,
        type: "m",
        mandatory: true,
        multiple: true,
        minver: 1,
        webm: true,
        description: "Contains all information about a segment edition."
      },
      272869232: {
        name: "Chapters",
        level: 1,
        type: "m",
        minver: 1,
        webm: true,
        description: "A system to define basic menus and partition data. For more detailed information, look at the Chapters Explanation."
      },
      18094: {
        name: "FileUID",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        range: "not 0",
        description: "Unique ID representing the file, as random as possible."
      },
      18012: {
        name: "FileData",
        level: 3,
        type: "b",
        mandatory: true,
        minver: 1,
        webm: false,
        description: "The data of the file."
      },
      18030: {
        name: "FileName",
        level: 3,
        type: "8",
        mandatory: true,
        minver: 1,
        webm: false,
        description: "Filename of the attached file."
      },
      18046: {
        name: "FileDescription",
        level: 3,
        type: "8",
        minver: 1,
        webm: false,
        description: "A human-friendly name for the attached file."
      },
      24999: {
        name: "AttachedFile",
        level: 2,
        type: "m",
        mandatory: true,
        multiple: true,
        minver: 1,
        webm: false,
        description: "An attached file."
      },
      423732329: {
        name: "Attachments",
        level: 1,
        type: "m",
        minver: 1,
        webm: false,
        description: "Contain attached files."
      },
      235: {
        name: "CueRefCodecState",
        level: 5,
        type: "u",
        webm: false,
        "default": 0,
        description: "The position of the Codec State corresponding to this referenced element. 0 means that the data is taken from the initial Track Entry."
      },
      21343: {
        name: "CueRefNumber",
        level: 5,
        type: "u",
        webm: false,
        "default": 1,
        range: "not 0",
        description: "Number of the referenced Block of Track X in the specified Cluster."
      },
      219: {
        name: "CueReference",
        level: 4,
        type: "m",
        multiple: true,
        minver: 2,
        webm: false,
        description: "The Clusters containing the required referenced Blocks."
      },
      234: {
        name: "CueCodecState",
        level: 4,
        type: "u",
        minver: 2,
        webm: false,
        "default": 0,
        description: "The position of the Codec State corresponding to this Cue element. 0 means that the data is taken from the initial Track Entry."
      },
      178: {
        name: "CueDuration",
        level: 4,
        type: "u",
        mandatory: false,
        minver: 4,
        webm: false,
        description: "The duration of the block according to the segment time base. If missing the track's DefaultDuration does not apply and no duration information is available in terms of the cues."
      },
      240: {
        name: "CueRelativePosition",
        level: 4,
        type: "u",
        mandatory: false,
        minver: 4,
        webm: false,
        description: "The relative position of the referenced block inside the cluster with 0 being the first possible position for an element inside that cluster.",
        position: "clusterRelative"
      },
      241: {
        name: "CueClusterPosition",
        level: 4,
        type: "u",
        mandatory: true,
        minver: 1,
        description: "The position of the Cluster containing the required Block.",
        position: "segment"
      },
      247: {
        name: "CueTrack",
        level: 4,
        type: "u",
        mandatory: true,
        minver: 1,
        range: "not 0",
        description: "The track for which a position is given."
      },
      183: {
        name: "CueTrackPositions",
        level: 3,
        type: "m",
        mandatory: true,
        multiple: true,
        minver: 1,
        description: "Contain positions for different tracks corresponding to the timestamp."
      },
      179: {
        name: "CueTime",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 1,
        description: "Absolute timestamp according to the segment time base."
      },
      187: {
        name: "CuePoint",
        level: 2,
        type: "m",
        mandatory: true,
        multiple: true,
        minver: 1,
        description: "Contains all information relative to a seek point in the segment."
      },
      475249515: {
        name: "Cues",
        level: 1,
        type: "m",
        minver: 1,
        description: 'A top-level element to speed seeking access. All entries are local to the segment. Should be mandatory for non "live" streams.'
      },
      18406: {
        name: "ContentSigHashAlgo",
        level: 6,
        type: "u",
        minver: 1,
        webm: false,
        "default": 0,
        // "br": [ "", "" ],
        description: "The hash algorithm used for the signature. A value of '0' means that the contents have not been signed but only encrypted. Predefined values: 1 - SHA1-160 2 - MD5"
      },
      18405: {
        name: "ContentSigAlgo",
        level: 6,
        type: "u",
        minver: 1,
        webm: false,
        "default": 0,
        // "br": "",
        description: "The algorithm used for the signature. A value of '0' means that the contents have not been signed but only encrypted. Predefined values: 1 - RSA"
      },
      18404: {
        name: "ContentSigKeyID",
        level: 6,
        type: "b",
        minver: 1,
        webm: false,
        description: "This is the ID of the private key the data was signed with."
      },
      18403: {
        name: "ContentSignature",
        level: 6,
        type: "b",
        minver: 1,
        webm: false,
        description: "A cryptographic signature of the contents."
      },
      18402: {
        name: "ContentEncKeyID",
        level: 6,
        type: "b",
        minver: 1,
        webm: false,
        description: "For public key algorithms this is the ID of the public key the the data was encrypted with."
      },
      18401: {
        name: "ContentEncAlgo",
        level: 6,
        type: "u",
        minver: 1,
        webm: false,
        "default": 0,
        // "br": "",
        description: "The encryption algorithm used. The value '0' means that the contents have not been encrypted but only signed. Predefined values: 1 - DES, 2 - 3DES, 3 - Twofish, 4 - Blowfish, 5 - AES"
      },
      28032: {
        name: "ContentEncodings",
        level: 3,
        type: "m",
        minver: 1,
        webm: false,
        description: "Settings for several content encoding mechanisms like compression or encryption."
      },
      196: {
        name: "TrickMasterTrackSegmentUID",
        level: 3,
        type: "b",
        divx: true,
        bytesize: 16,
        description: "DivX trick track extenstions"
      },
      199: {
        name: "TrickMasterTrackUID",
        level: 3,
        type: "u",
        divx: true,
        description: "DivX trick track extenstions"
      },
      198: {
        name: "TrickTrackFlag",
        level: 3,
        type: "u",
        divx: true,
        "default": 0,
        description: "DivX trick track extenstions"
      },
      193: {
        name: "TrickTrackSegmentUID",
        level: 3,
        type: "b",
        divx: true,
        bytesize: 16,
        description: "DivX trick track extenstions"
      },
      192: {
        name: "TrickTrackUID",
        level: 3,
        type: "u",
        divx: true,
        description: "DivX trick track extenstions"
      },
      237: {
        name: "TrackJoinUID",
        level: 5,
        type: "u",
        mandatory: true,
        multiple: true,
        minver: 3,
        webm: false,
        range: "not 0",
        description: "The trackUID number of a track whose blocks are used to create this virtual track."
      },
      233: {
        name: "TrackJoinBlocks",
        level: 4,
        type: "m",
        minver: 3,
        webm: false,
        description: "Contains the list of all tracks whose Blocks need to be combined to create this virtual track"
      },
      230: {
        name: "TrackPlaneType",
        level: 6,
        type: "u",
        mandatory: true,
        minver: 3,
        webm: false,
        description: "The kind of plane this track corresponds to (0: left eye, 1: right eye, 2: background)."
      },
      229: {
        name: "TrackPlaneUID",
        level: 6,
        type: "u",
        mandatory: true,
        minver: 3,
        webm: false,
        range: "not 0",
        description: "The trackUID number of the track representing the plane."
      },
      228: {
        name: "TrackPlane",
        level: 5,
        type: "m",
        mandatory: true,
        multiple: true,
        minver: 3,
        webm: false,
        description: "Contains a video plane track that need to be combined to create this 3D track"
      },
      227: {
        name: "TrackCombinePlanes",
        level: 4,
        type: "m",
        minver: 3,
        webm: false,
        description: "Contains the list of all video plane tracks that need to be combined to create this 3D track"
      },
      226: {
        name: "TrackOperation",
        level: 3,
        type: "m",
        minver: 3,
        webm: false,
        description: "Operation that needs to be applied on tracks to create this virtual track. For more details look at the Specification Notes on the subject."
      },
      32123: {
        name: "ChannelPositions",
        cppname: "AudioPosition",
        level: 4,
        type: "b",
        webm: false,
        description: "Table of horizontal angles for each successive channel, see appendix."
      },
      159: {
        name: "Channels",
        cppname: "AudioChannels",
        level: 4,
        type: "u",
        mandatory: true,
        minver: 1,
        "default": 1,
        range: "not 0",
        description: "Numbers of channels in the track."
      },
      30901: {
        name: "OutputSamplingFrequency",
        cppname: "AudioOutputSamplingFreq",
        level: 4,
        type: "f",
        minver: 1,
        "default": "Sampling Frequency",
        range: "> 0",
        description: "Real output sampling frequency in Hz (used for SBR techniques)."
      },
      181: {
        name: "SamplingFrequency",
        cppname: "AudioSamplingFreq",
        level: 4,
        type: "f",
        mandatory: true,
        minver: 1,
        "default": 8e3,
        range: "> 0",
        description: "Sampling frequency in Hz."
      },
      225: {
        name: "Audio",
        cppname: "TrackAudio",
        level: 3,
        type: "m",
        minver: 1,
        description: "Audio settings."
      },
      2327523: {
        name: "FrameRate",
        cppname: "VideoFrameRate",
        level: 4,
        type: "f",
        range: "> 0",
        "strong": "Informational",
        description: "Number of frames per second.  only."
      },
      3126563: {
        name: "GammaValue",
        cppname: "VideoGamma",
        level: 4,
        type: "f",
        webm: false,
        range: "> 0",
        description: "Gamma Value."
      },
      3061028: {
        name: "ColourSpace",
        cppname: "VideoColourSpace",
        level: 4,
        type: "b",
        minver: 1,
        webm: false,
        bytesize: 4,
        description: "Same value as in AVI (32 bits)."
      },
      21683: {
        name: "AspectRatioType",
        cppname: "VideoAspectRatio",
        level: 4,
        type: "u",
        minver: 1,
        "default": 0,
        description: "Specify the possible modifications to the aspect ratio (0: free resizing, 1: keep aspect ratio, 2: fixed)."
      },
      21682: {
        name: "DisplayUnit",
        cppname: "VideoDisplayUnit",
        level: 4,
        type: "u",
        minver: 1,
        "default": 0,
        description: "How DisplayWidth & DisplayHeight should be interpreted (0: pixels, 1: centimeters, 2: inches, 3: Display Aspect Ratio)."
      },
      21690: {
        name: "DisplayHeight",
        cppname: "VideoDisplayHeight",
        level: 4,
        type: "u",
        minver: 1,
        "default": "PixelHeight",
        range: "not 0",
        description: "Height of the video frames to display. The default value is only valid when DisplayUnit is 0."
      },
      21680: {
        name: "DisplayWidth",
        cppname: "VideoDisplayWidth",
        level: 4,
        type: "u",
        minver: 1,
        "default": "PixelWidth",
        range: "not 0",
        description: "Width of the video frames to display. The default value is only valid when DisplayUnit is 0."
      },
      21725: {
        name: "PixelCropRight",
        cppname: "VideoPixelCropRight",
        level: 4,
        type: "u",
        minver: 1,
        "default": 0,
        description: "The number of video pixels to remove on the right of the image."
      },
      21708: {
        name: "PixelCropLeft",
        cppname: "VideoPixelCropLeft",
        level: 4,
        type: "u",
        minver: 1,
        "default": 0,
        description: "The number of video pixels to remove on the left of the image."
      },
      21691: {
        name: "PixelCropTop",
        cppname: "VideoPixelCropTop",
        level: 4,
        type: "u",
        minver: 1,
        "default": 0,
        description: "The number of video pixels to remove at the top of the image."
      },
      21674: {
        name: "PixelCropBottom",
        cppname: "VideoPixelCropBottom",
        level: 4,
        type: "u",
        minver: 1,
        "default": 0,
        description: "The number of video pixels to remove at the bottom of the image (for HDTV content)."
      },
      186: {
        name: "PixelHeight",
        cppname: "VideoPixelHeight",
        level: 4,
        type: "u",
        mandatory: true,
        minver: 1,
        range: "not 0",
        description: "Height of the encoded video frames in pixels."
      },
      176: {
        name: "PixelWidth",
        cppname: "VideoPixelWidth",
        level: 4,
        type: "u",
        mandatory: true,
        minver: 1,
        range: "not 0",
        description: "Width of the encoded video frames in pixels."
      },
      21433: {
        name: "OldStereoMode",
        level: 4,
        type: "u",
        "maxver": "0",
        webm: false,
        divx: false,
        description: "DEPRECATED, DO NOT USE. Bogus StereoMode value used in old versions of libmatroska. (0: mono, 1: right eye, 2: left eye, 3: both eyes)."
      },
      21440: {
        name: "AlphaMode",
        cppname: "VideoAlphaMode",
        level: 4,
        type: "u",
        minver: 3,
        webm: true,
        "default": 0,
        description: "Alpha Video Mode. Presence of this element indicates that the BlockAdditional element could contain Alpha data."
      },
      21432: {
        name: "StereoMode",
        cppname: "VideoStereoMode",
        level: 4,
        type: "u",
        minver: 3,
        webm: true,
        "default": 0,
        description: "Stereo-3D video mode (0: mono, 1: side by side (left eye is first), 2: top-bottom (right eye is first), 3: top-bottom (left eye is first), 4: checkboard (right is first), 5: checkboard (left is first), 6: row interleaved (right is first), 7: row interleaved (left is first), 8: column interleaved (right is first), 9: column interleaved (left is first), 10: anaglyph (cyan/red), 11: side by side (right eye is first), 12: anaglyph (green/magenta), 13 both eyes laced in one Block (left eye is first), 14 both eyes laced in one Block (right eye is first)) . There are some more details on 3D support in the Specification Notes."
      },
      154: {
        name: "FlagInterlaced",
        cppname: "VideoFlagInterlaced",
        level: 4,
        type: "u",
        mandatory: true,
        minver: 2,
        webm: true,
        "default": 0,
        range: "0-1",
        description: "Set if the video is interlaced. (1 bit)"
      },
      224: {
        name: "Video",
        cppname: "TrackVideo",
        level: 3,
        type: "m",
        minver: 1,
        description: "Video settings."
      },
      26277: {
        name: "TrackTranslateTrackID",
        level: 4,
        type: "b",
        mandatory: true,
        minver: 1,
        webm: false,
        description: "The binary value used to represent this track in the chapter codec data. The format depends on the ChapProcessCodecID used."
      },
      26303: {
        name: "TrackTranslateCodec",
        level: 4,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        description: "The chapter codec using this ID (0: Matroska Script, 1: DVD-menu)."
      },
      26364: {
        name: "TrackTranslateEditionUID",
        level: 4,
        type: "u",
        multiple: true,
        minver: 1,
        webm: false,
        description: "Specify an edition UID on which this translation applies. When not specified, it means for all editions found in the segment."
      },
      22203: {
        name: "SeekPreRoll",
        level: 3,
        type: "u",
        mandatory: true,
        multiple: false,
        "default": 0,
        minver: 4,
        webm: true,
        description: "After a discontinuity, SeekPreRoll is the duration in nanoseconds of the data the decoder must decode before the decoded data is valid."
      },
      22186: {
        name: "CodecDelay",
        level: 3,
        type: "u",
        multiple: false,
        "default": 0,
        minver: 4,
        webm: true,
        description: "CodecDelay is The codec-built-in delay in nanoseconds. This value must be subtracted from each block timestamp in order to get the actual timestamp. The value should be small so the muxing of tracks with the same actual timestamp are in the same Cluster."
      },
      28587: {
        name: "TrackOverlay",
        level: 3,
        type: "u",
        multiple: true,
        minver: 1,
        webm: false,
        description: "Specify that this track is an overlay track for the Track specified (in the u-integer). That means when this track has a gap (see SilentTracks) the overlay track should be used instead. The order of multiple TrackOverlay matters, the first one is the one that should be used. If not found it should be the second, etc."
      },
      170: {
        name: "CodecDecodeAll",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 2,
        webm: false,
        "default": 1,
        range: "0-1",
        description: "The codec can decode potentially damaged data (1 bit)."
      },
      2536e3: {
        name: "CodecDownloadURL",
        level: 3,
        type: "s",
        multiple: true,
        webm: false,
        description: "A URL to download about the codec used."
      },
      3883072: {
        name: "CodecInfoURL",
        level: 3,
        type: "s",
        multiple: true,
        webm: false,
        description: "A URL to find information about the codec used."
      },
      3839639: {
        name: "CodecSettings",
        level: 3,
        type: "8",
        webm: false,
        description: "A string describing the encoding setting used."
      },
      25506: {
        name: "CodecPrivate",
        level: 3,
        type: "b",
        minver: 1,
        description: "Private data only known to the codec."
      },
      2274716: {
        name: "Language",
        cppname: "TrackLanguage",
        level: 3,
        type: "s",
        minver: 1,
        "default": "eng",
        description: "Specifies the language of the track in the Matroska languages form."
      },
      21358: {
        name: "Name",
        cppname: "TrackName",
        level: 3,
        type: "8",
        minver: 1,
        description: "A human-readable track name."
      },
      21998: {
        name: "MaxBlockAdditionID",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        "default": 0,
        description: "The maximum value of BlockAdditions for this track."
      },
      21375: {
        name: "TrackOffset",
        level: 3,
        type: "i",
        webm: false,
        "default": 0,
        description: "A value to add to the Block's Timestamp. This can be used to adjust the playback offset of a track."
      },
      2306383: {
        name: "TrackTimecodeScale",
        level: 3,
        type: "f",
        mandatory: true,
        minver: 1,
        "maxver": "3",
        webm: false,
        "default": 1,
        range: "> 0",
        description: "DEPRECATED, DO NOT USE. The scale to apply on this track to work at normal speed in relation with other tracks (mostly used to adjust video speed when the audio length differs)."
      },
      2313850: {
        name: "DefaultDecodedFieldDuration",
        cppname: "TrackDefaultDecodedFieldDuration",
        level: 3,
        type: "u",
        minver: 4,
        range: "not 0",
        description: "The period in nanoseconds (not scaled by TimcodeScale)\nbetween two successive fields at the output of the decoding process (see the notes)"
      },
      2352003: {
        name: "DefaultDuration",
        cppname: "TrackDefaultDuration",
        level: 3,
        type: "u",
        minver: 1,
        range: "not 0",
        description: "Number of nanoseconds (not scaled via TimecodeScale) per frame ('frame' in the Matroska sense -- one element put into a (Simple)Block)."
      },
      28152: {
        name: "MaxCache",
        cppname: "TrackMaxCache",
        level: 3,
        type: "u",
        minver: 1,
        webm: false,
        description: "The maximum cache size required to store referenced frames in and the current frame. 0 means no cache is needed."
      },
      28135: {
        name: "MinCache",
        cppname: "TrackMinCache",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        "default": 0,
        description: "The minimum number of frames a player should be able to cache during playback. If set to 0, the reference pseudo-cache system is not used."
      },
      156: {
        name: "FlagLacing",
        cppname: "TrackFlagLacing",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 1,
        "default": 1,
        range: "0-1",
        description: "Set if the track may contain blocks using lacing. (1 bit)"
      },
      21930: {
        name: "FlagForced",
        cppname: "TrackFlagForced",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 1,
        "default": 0,
        range: "0-1",
        description: "Set if that track MUST be active during playback. There can be many forced track for a kind (audio, video or subs), the player should select the one which language matches the user preference or the default + forced track. Overlay MAY happen between a forced and non-forced track of the same kind. (1 bit)"
      },
      185: {
        name: "FlagEnabled",
        cppname: "TrackFlagEnabled",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 2,
        webm: true,
        "default": 1,
        range: "0-1",
        description: "Set if the track is usable. (1 bit)"
      },
      29637: {
        name: "TrackUID",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 1,
        range: "not 0",
        description: "A unique ID to identify the Track. This should be kept the same when making a direct stream copy of the Track to another file."
      },
      215: {
        name: "TrackNumber",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 1,
        range: "not 0",
        description: "The track number as used in the Block Header (using more than 127 tracks is not encouraged, though the design allows an unlimited number)."
      },
      174: {
        name: "TrackEntry",
        level: 2,
        type: "m",
        mandatory: true,
        multiple: true,
        minver: 1,
        description: "Describes a track with all elements."
      },
      374648427: {
        name: "Tracks",
        level: 1,
        type: "m",
        multiple: true,
        minver: 1,
        description: "A top-level block of information with many tracks described."
      },
      175: {
        name: "EncryptedBlock",
        level: 2,
        type: "b",
        multiple: true,
        webm: false,
        description: "Similar to EncryptedBlock Structure)"
      },
      202: {
        name: "ReferenceTimeCode",
        level: 4,
        type: "u",
        multiple: false,
        mandatory: true,
        minver: 0,
        webm: false,
        divx: true,
        description: "DivX trick track extenstions"
      },
      201: {
        name: "ReferenceOffset",
        level: 4,
        type: "u",
        multiple: false,
        mandatory: true,
        minver: 0,
        webm: false,
        divx: true,
        description: "DivX trick track extenstions"
      },
      200: {
        name: "ReferenceFrame",
        level: 3,
        type: "m",
        multiple: false,
        minver: 0,
        webm: false,
        divx: true,
        description: "DivX trick track extenstions"
      },
      207: {
        name: "SliceDuration",
        level: 5,
        type: "u",
        "default": 0,
        description: "The (scaled) duration to apply to the element."
      },
      206: {
        name: "Delay",
        cppname: "SliceDelay",
        level: 5,
        type: "u",
        "default": 0,
        description: "The (scaled) delay to apply to the element."
      },
      203: {
        name: "BlockAdditionID",
        cppname: "SliceBlockAddID",
        level: 5,
        type: "u",
        "default": 0,
        description: "The ID of the BlockAdditional element (0 is the main Block)."
      },
      205: {
        name: "FrameNumber",
        cppname: "SliceFrameNumber",
        level: 5,
        type: "u",
        "default": 0,
        description: "The number of the frame to generate from this lace with this delay (allow you to generate many frames from the same Block/Frame)."
      },
      204: {
        name: "LaceNumber",
        cppname: "SliceLaceNumber",
        level: 5,
        type: "u",
        minver: 1,
        "default": 0,
        divx: false,
        description: "The reverse number of the frame in the lace (0 is the last frame, 1 is the next to last, etc). While there are a few files in the wild with this element, it is no longer in use and has been deprecated. Being able to interpret this element is not required for playback."
      },
      232: {
        name: "TimeSlice",
        level: 4,
        type: "m",
        multiple: true,
        minver: 1,
        divx: false,
        description: "Contains extra time information about the data contained in the Block. While there are a few files in the wild with this element, it is no longer in use and has been deprecated. Being able to interpret this element is not required for playback."
      },
      142: {
        name: "Slices",
        level: 3,
        type: "m",
        minver: 1,
        divx: false,
        description: "Contains slices description."
      },
      30114: {
        name: "DiscardPadding",
        level: 3,
        type: "i",
        minver: 4,
        webm: true,
        description: "Duration in nanoseconds of the silent data added to the Block (padding at the end of the Block for positive value, at the beginning of the Block for negative value). The duration of DiscardPadding is not calculated in the duration of the TrackEntry and should be discarded during playback."
      },
      164: {
        name: "CodecState",
        level: 3,
        type: "b",
        minver: 2,
        webm: false,
        description: "The new codec state to use. Data interpretation is private to the codec. This information should always be referenced by a seek entry."
      },
      253: {
        name: "ReferenceVirtual",
        level: 3,
        type: "i",
        webm: false,
        description: "Relative position of the data that should be in position of the virtual block."
      },
      251: {
        name: "ReferenceBlock",
        level: 3,
        type: "i",
        multiple: true,
        minver: 1,
        description: "Timestamp of another frame used as a reference (ie: B or P frame). The timestamp is relative to the block it's attached to."
      },
      250: {
        name: "ReferencePriority",
        cppname: "FlagReferenced",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        "default": 0,
        description: "This frame is referenced and has the specified cache priority. In cache only a frame of the same or higher priority can replace this frame. A value of 0 means the frame is not referenced."
      },
      155: {
        name: "BlockDuration",
        level: 3,
        type: "u",
        minver: 1,
        "default": "TrackDuration",
        description: 'The duration of the Block (based on TimecodeScale). This element is mandatory when DefaultDuration is set for the track (but can be omitted as other default values). When not written and with no DefaultDuration, the value is assumed to be the difference between the timestamp of this Block and the timestamp of the next Block in "display" order (not coding order). This element can be useful at the end of a Track (as there is not other Block available), or when there is a break in a track like for subtitle tracks. When set to 0 that means the frame is not a keyframe.'
      },
      165: {
        name: "BlockAdditional",
        level: 5,
        type: "b",
        mandatory: true,
        minver: 1,
        webm: false,
        description: "Interpreted by the codec as it wishes (using the BlockAddID)."
      },
      238: {
        name: "BlockAddID",
        level: 5,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        "default": 1,
        range: "not 0",
        description: "An ID to identify the BlockAdditional level."
      },
      166: {
        name: "BlockMore",
        level: 4,
        type: "m",
        mandatory: true,
        multiple: true,
        minver: 1,
        webm: false,
        description: "Contain the BlockAdditional and some parameters."
      },
      30113: {
        name: "BlockAdditions",
        level: 3,
        type: "m",
        minver: 1,
        webm: false,
        description: "Contain additional blocks to complete the main one. An EBML parser that has no knowledge of the Block structure could still see and use/skip these data."
      },
      162: {
        name: "BlockVirtual",
        level: 3,
        type: "b",
        webm: false,
        description: "A Block with no data. It must be stored in the stream at the place the real Block should be in display order. (see Block Virtual)"
      },
      161: {
        name: "Block",
        level: 3,
        type: "b",
        mandatory: true,
        minver: 1,
        description: "Block containing the actual data to be rendered and a timestamp relative to the Cluster Timecode. (see Block Structure)"
      },
      160: {
        name: "BlockGroup",
        level: 2,
        type: "m",
        multiple: true,
        minver: 1,
        description: "Basic container of information containing a single Block or BlockVirtual, and information specific to that Block/VirtualBlock."
      },
      163: {
        name: "SimpleBlock",
        level: 2,
        type: "b",
        multiple: true,
        minver: 2,
        webm: true,
        divx: true,
        description: "Similar to SimpleBlock Structure"
      },
      171: {
        name: "PrevSize",
        cppname: "ClusterPrevSize",
        level: 2,
        type: "u",
        minver: 1,
        description: "Size of the previous Cluster, in octets. Can be useful for backward playing.",
        position: "prevCluster"
      },
      167: {
        name: "Position",
        cppname: "ClusterPosition",
        level: 2,
        type: "u",
        minver: 1,
        webm: false,
        description: "The Position of the Cluster in the segment (0 in live broadcast streams). It might help to resynchronise offset on damaged streams.",
        position: "segment"
      },
      22743: {
        name: "SilentTrackNumber",
        cppname: "ClusterSilentTrackNumber",
        level: 3,
        type: "u",
        multiple: true,
        minver: 1,
        webm: false,
        description: "One of the track number that are not used from now on in the stream. It could change later if not specified as silent in a further Cluster."
      },
      231: {
        name: "Timecode",
        cppname: "ClusterTimecode",
        level: 2,
        type: "u",
        mandatory: true,
        minver: 1,
        description: "Absolute timestamp of the cluster (based on TimecodeScale)."
      },
      524531317: {
        name: "Cluster",
        level: 1,
        type: "m",
        multiple: true,
        minver: 1,
        description: "The lower level element containing the (monolithic) Block structure."
      },
      19840: {
        name: "MuxingApp",
        level: 2,
        type: "8",
        mandatory: true,
        minver: 1,
        description: 'Muxing application or library ("libmatroska-0.4.3").'
      },
      31657: {
        name: "Title",
        level: 2,
        type: "8",
        minver: 1,
        webm: false,
        description: "General name of the segment."
      },
      2807730: {
        name: "TimecodeScaleDenominator",
        level: 2,
        type: "u",
        mandatory: true,
        minver: 4,
        "default": "1000000000",
        description: "Timestamp scale numerator, see TimecodeScale."
      },
      2807729: {
        name: "TimecodeScale",
        level: 2,
        type: "u",
        mandatory: true,
        minver: 1,
        "default": "1000000",
        description: "Timestamp scale in nanoseconds (1.000.000 means all timestamps in the segment are expressed in milliseconds)."
      },
      27045: {
        name: "ChapterTranslateID",
        level: 3,
        type: "b",
        mandatory: true,
        minver: 1,
        webm: false,
        description: "The binary value used to represent this segment in the chapter codec data. The format depends on the ChapProcessCodecID used."
      },
      27071: {
        name: "ChapterTranslateCodec",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 1,
        webm: false,
        description: "The chapter codec using this ID (0: Matroska Script, 1: DVD-menu)."
      },
      27132: {
        name: "ChapterTranslateEditionUID",
        level: 3,
        type: "u",
        multiple: true,
        minver: 1,
        webm: false,
        description: "Specify an edition UID on which this correspondance applies. When not specified, it means for all editions found in the segment."
      },
      4096955: {
        name: "NextFilename",
        level: 2,
        type: "8",
        minver: 1,
        webm: false,
        description: "An escaped filename corresponding to the next segment."
      },
      4110627: {
        name: "NextUID",
        level: 2,
        type: "b",
        minver: 1,
        webm: false,
        bytesize: 16,
        description: "A unique ID to identify the next chained segment (128 bits)."
      },
      3965867: {
        name: "PrevFilename",
        level: 2,
        type: "8",
        minver: 1,
        webm: false,
        description: "An escaped filename corresponding to the previous segment."
      },
      3979555: {
        name: "PrevUID",
        level: 2,
        type: "b",
        minver: 1,
        webm: false,
        bytesize: 16,
        description: "A unique ID to identify the previous chained segment (128 bits)."
      },
      29604: {
        name: "SegmentUID",
        level: 2,
        type: "b",
        minver: 1,
        webm: false,
        range: "not 0",
        bytesize: 16,
        description: "A randomly generated unique ID to identify the current segment between many others (128 bits)."
      },
      357149030: {
        name: "Info",
        level: 1,
        type: "m",
        mandatory: true,
        multiple: true,
        minver: 1,
        description: "Contains miscellaneous general information and statistics on the file."
      },
      21420: {
        name: "SeekPosition",
        level: 3,
        type: "u",
        mandatory: true,
        minver: 1,
        description: "The position of the element in the segment in octets (0 = first level 1 element).",
        position: "segment"
      },
      21419: {
        name: "SeekID",
        level: 3,
        type: "b",
        mandatory: true,
        minver: 1,
        description: "The binary ID corresponding to the element name.",
        type2: "ebmlID"
      },
      19899: {
        name: "Seek",
        cppname: "SeekPoint",
        level: 2,
        type: "m",
        mandatory: true,
        multiple: true,
        minver: 1,
        description: "Contains a single seek entry to an EBML element."
      },
      290298740: {
        name: "SeekHead",
        cppname: "SeekHeader",
        level: 1,
        type: "m",
        multiple: true,
        minver: 1,
        description: "Contains the position of other level 1 elements."
      },
      32379: {
        name: "SignatureElementList",
        level: 2,
        type: "m",
        multiple: true,
        webm: false,
        i: "Cluster|Block|BlockAdditional",
        description: "A list consists of a number of consecutive elements that represent one case where data is used in signature. Ex:  means that the BlockAdditional of all Blocks in all Clusters is used for encryption."
      },
      32347: {
        name: "SignatureElements",
        level: 1,
        type: "m",
        webm: false,
        description: "Contains elements that will be used to compute the signature."
      },
      32437: {
        name: "Signature",
        level: 1,
        type: "b",
        webm: false,
        description: "The signature of the data (until a new."
      },
      32421: {
        name: "SignaturePublicKey",
        level: 1,
        type: "b",
        webm: false,
        description: "The public key to use with the algorithm (in the case of a PKI-based signature)."
      },
      32410: {
        name: "SignatureHash",
        level: 1,
        type: "u",
        webm: false,
        description: "Hash algorithm used (1=SHA1-160, 2=MD5)."
      },
      32394: {
        name: "SignatureAlgo",
        level: 1,
        type: "u",
        webm: false,
        description: "Signature algorithm used (1=RSA, 2=elliptic)."
      },
      458458727: {
        name: "SignatureSlot",
        level: -1,
        type: "m",
        multiple: true,
        webm: false,
        description: "Contain signature of some (coming) elements in the stream."
      },
      191: {
        name: "CRC-32",
        level: -1,
        type: "b",
        minver: 1,
        webm: false,
        description: "The CRC is computed on all the data of the Master element it's in. The CRC element should be the first in it's parent master for easier reading. All level 1 elements should include a CRC-32. The CRC in use is the IEEE CRC32 Little Endian",
        crc: true
      },
      236: {
        name: "Void",
        level: -1,
        type: "b",
        minver: 1,
        description: "Used to void damaged data, to avoid unexpected behaviors when using damaged data. The content is discarded. Also used to reserve space in a sub-element for later use."
      },
      17139: {
        name: "EBMLMaxSizeLength",
        level: 1,
        type: "u",
        mandatory: true,
        "default": 8,
        minver: 1,
        description: "The maximum length of the sizes you'll find in this file (8 or less in Matroska). This does not override the element size indicated at the beginning of an element. Elements that have an indicated size which is larger than what is allowed by EBMLMaxSizeLength shall be considered invalid."
      },
      17138: {
        name: "EBMLMaxIDLength",
        level: 1,
        type: "u",
        mandatory: true,
        "default": 4,
        minver: 1,
        description: "The maximum length of the IDs you'll find in this file (4 or less in Matroska)."
      },
      17143: {
        name: "EBMLReadVersion",
        level: 1,
        type: "u",
        mandatory: true,
        "default": 1,
        minver: 1,
        description: "The minimum EBML version a parser has to support to read this file."
      },
      440786851: {
        name: "EBML",
        level: "0",
        type: "m",
        mandatory: true,
        multiple: true,
        minver: 1,
        description: "Set the EBML characteristics of the data to follow. Each EBML document has to start with this."
      },
      21936: {
        name: "Colour",
        level: "4",
        type: "m",
        mandatory: true,
        multiple: true,
        description: "Settings describing the colour format."
      },
      21937: {
        name: "MatrixCoefficients",
        level: "5",
        type: "u",
        mandatory: true,
        multiple: true,
        description: "The Matrix Coefficients of the video used to derive luma and chroma values from red, green, and blue color primaries. For clarity, the value and meanings for MatrixCoefficients are adopted from Table 4 of ISO/IEC 23001-8:2016 or ITU-T H.273."
      },
      21945: {
        name: "Range",
        level: "5",
        type: "u",
        mandatory: true,
        multiple: true,
        description: "Clipping of the color ranges."
      },
      21946: {
        name: "TransferCharacteristics",
        level: "5",
        type: "u",
        mandatory: true,
        multiple: true,
        description: "The transfer characteristics of the video."
      },
      21947: {
        name: "Primaries",
        level: "5",
        type: "u",
        mandatory: true,
        multiple: true,
        description: "The colour primaries of the video. For clarity, the value and meanings for Primaries are adopted from Table 2 of ISO/IEC 23091-4 or ITU-T H.273."
      }
    };
    return ebmlID;
  }
  var hasRequiredEBMLEncoder;
  function requireEBMLEncoder() {
    if (hasRequiredEBMLEncoder) return EBMLEncoder;
    hasRequiredEBMLEncoder = 1;
    Object.defineProperty(EBMLEncoder, "__esModule", { value: true });
    var tools2 = requireTools();
    var tools_1 = requireTools();
    var ebmlID_1 = requireEbmlID();
    var EBMLEncoder$1 = (
      /** @class */
      (function() {
        function EBMLEncoder2() {
          this._schema = ebmlID_1.byEbmlID;
          this._buffers = [];
          this._stack = [];
        }
        EBMLEncoder2.prototype.encode = function(elms) {
          var _this = this;
          return tools2.concat(elms.reduce(function(lst, elm) {
            return lst.concat(_this.encodeChunk(elm));
          }, [])).buffer;
        };
        EBMLEncoder2.prototype.encodeChunk = function(elm) {
          if (elm.type === "m") {
            if (!elm.isEnd) {
              this.startTag(elm);
            } else {
              this.endTag(elm);
            }
          } else {
            elm.data = tools_1.Buffer.from(elm.data);
            this.writeTag(elm);
          }
          return this.flush();
        };
        EBMLEncoder2.prototype.flush = function() {
          var ret = this._buffers;
          this._buffers = [];
          return ret;
        };
        EBMLEncoder2.prototype.getSchemaInfo = function(tagName) {
          var tagNums = Object.keys(this._schema).map(Number);
          for (var i = 0; i < tagNums.length; i++) {
            var tagNum = tagNums[i];
            if (this._schema[tagNum].name === tagName) {
              return new tools_1.Buffer(tagNum.toString(16), "hex");
            }
          }
          return null;
        };
        EBMLEncoder2.prototype.writeTag = function(elm) {
          var tagName = elm.name;
          var tagId = this.getSchemaInfo(tagName);
          var tagData = elm.data;
          if (tagId == null) {
            throw new Error("No schema entry found for " + tagName);
          }
          var data = tools2.encodeTag(tagId, tagData);
          if (this._stack.length > 0) {
            var last = this._stack[this._stack.length - 1];
            last.children.push({
              tagId,
              elm,
              children: [],
              data
            });
            return;
          }
          this._buffers = this._buffers.concat(data);
          return;
        };
        EBMLEncoder2.prototype.startTag = function(elm) {
          var tagName = elm.name;
          var tagId = this.getSchemaInfo(tagName);
          if (tagId == null) {
            throw new Error("No schema entry found for " + tagName);
          }
          if (elm.unknownSize) {
            var data = tools2.encodeTag(tagId, new tools_1.Buffer(0), elm.unknownSize);
            this._buffers = this._buffers.concat(data);
            return;
          }
          var tag = {
            tagId,
            elm,
            children: [],
            data: null
          };
          if (this._stack.length > 0) {
            this._stack[this._stack.length - 1].children.push(tag);
          }
          this._stack.push(tag);
        };
        EBMLEncoder2.prototype.endTag = function(elm) {
          elm.name;
          var tag = this._stack.pop();
          if (tag == null) {
            throw new Error("EBML structure is broken");
          }
          if (tag.elm.name !== elm.name) {
            throw new Error("EBML structure is broken");
          }
          var childTagDataBuffers = tag.children.reduce(function(lst, child) {
            if (child.data === null) {
              throw new Error("EBML structure is broken");
            }
            return lst.concat(child.data);
          }, []);
          var childTagDataBuffer = tools2.concat(childTagDataBuffers);
          if (tag.elm.type === "m") {
            tag.data = tools2.encodeTag(tag.tagId, childTagDataBuffer, tag.elm.unknownSize);
          } else {
            tag.data = tools2.encodeTag(tag.tagId, childTagDataBuffer);
          }
          if (this._stack.length < 1) {
            this._buffers = this._buffers.concat(tag.data);
          }
        };
        return EBMLEncoder2;
      })()
    );
    EBMLEncoder.default = EBMLEncoder$1;
    return EBMLEncoder;
  }
  var buffer = {};
  var base64Js = {};
  var hasRequiredBase64Js;
  function requireBase64Js() {
    if (hasRequiredBase64Js) return base64Js;
    hasRequiredBase64Js = 1;
    base64Js.byteLength = byteLength;
    base64Js.toByteArray = toByteArray;
    base64Js.fromByteArray = fromByteArray;
    var lookup = [];
    var revLookup = [];
    var Arr = typeof Uint8Array !== "undefined" ? Uint8Array : Array;
    var code = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (var i = 0, len = code.length; i < len; ++i) {
      lookup[i] = code[i];
      revLookup[code.charCodeAt(i)] = i;
    }
    revLookup["-".charCodeAt(0)] = 62;
    revLookup["_".charCodeAt(0)] = 63;
    function getLens(b64) {
      var len2 = b64.length;
      if (len2 % 4 > 0) {
        throw new Error("Invalid string. Length must be a multiple of 4");
      }
      var validLen = b64.indexOf("=");
      if (validLen === -1) validLen = len2;
      var placeHoldersLen = validLen === len2 ? 0 : 4 - validLen % 4;
      return [validLen, placeHoldersLen];
    }
    function byteLength(b64) {
      var lens = getLens(b64);
      var validLen = lens[0];
      var placeHoldersLen = lens[1];
      return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
    }
    function _byteLength(b64, validLen, placeHoldersLen) {
      return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
    }
    function toByteArray(b64) {
      var tmp;
      var lens = getLens(b64);
      var validLen = lens[0];
      var placeHoldersLen = lens[1];
      var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen));
      var curByte = 0;
      var len2 = placeHoldersLen > 0 ? validLen - 4 : validLen;
      var i2;
      for (i2 = 0; i2 < len2; i2 += 4) {
        tmp = revLookup[b64.charCodeAt(i2)] << 18 | revLookup[b64.charCodeAt(i2 + 1)] << 12 | revLookup[b64.charCodeAt(i2 + 2)] << 6 | revLookup[b64.charCodeAt(i2 + 3)];
        arr[curByte++] = tmp >> 16 & 255;
        arr[curByte++] = tmp >> 8 & 255;
        arr[curByte++] = tmp & 255;
      }
      if (placeHoldersLen === 2) {
        tmp = revLookup[b64.charCodeAt(i2)] << 2 | revLookup[b64.charCodeAt(i2 + 1)] >> 4;
        arr[curByte++] = tmp & 255;
      }
      if (placeHoldersLen === 1) {
        tmp = revLookup[b64.charCodeAt(i2)] << 10 | revLookup[b64.charCodeAt(i2 + 1)] << 4 | revLookup[b64.charCodeAt(i2 + 2)] >> 2;
        arr[curByte++] = tmp >> 8 & 255;
        arr[curByte++] = tmp & 255;
      }
      return arr;
    }
    function tripletToBase64(num) {
      return lookup[num >> 18 & 63] + lookup[num >> 12 & 63] + lookup[num >> 6 & 63] + lookup[num & 63];
    }
    function encodeChunk(uint8, start, end) {
      var tmp;
      var output = [];
      for (var i2 = start; i2 < end; i2 += 3) {
        tmp = (uint8[i2] << 16 & 16711680) + (uint8[i2 + 1] << 8 & 65280) + (uint8[i2 + 2] & 255);
        output.push(tripletToBase64(tmp));
      }
      return output.join("");
    }
    function fromByteArray(uint8) {
      var tmp;
      var len2 = uint8.length;
      var extraBytes = len2 % 3;
      var parts = [];
      var maxChunkLength = 16383;
      for (var i2 = 0, len22 = len2 - extraBytes; i2 < len22; i2 += maxChunkLength) {
        parts.push(encodeChunk(uint8, i2, i2 + maxChunkLength > len22 ? len22 : i2 + maxChunkLength));
      }
      if (extraBytes === 1) {
        tmp = uint8[len2 - 1];
        parts.push(
          lookup[tmp >> 2] + lookup[tmp << 4 & 63] + "=="
        );
      } else if (extraBytes === 2) {
        tmp = (uint8[len2 - 2] << 8) + uint8[len2 - 1];
        parts.push(
          lookup[tmp >> 10] + lookup[tmp >> 4 & 63] + lookup[tmp << 2 & 63] + "="
        );
      }
      return parts.join("");
    }
    return base64Js;
  }
  var ieee754 = {};
  /*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
  var hasRequiredIeee754;
  function requireIeee754() {
    if (hasRequiredIeee754) return ieee754;
    hasRequiredIeee754 = 1;
    ieee754.read = function(buffer2, offset, isLE, mLen, nBytes) {
      var e, m;
      var eLen = nBytes * 8 - mLen - 1;
      var eMax = (1 << eLen) - 1;
      var eBias = eMax >> 1;
      var nBits = -7;
      var i = isLE ? nBytes - 1 : 0;
      var d = isLE ? -1 : 1;
      var s = buffer2[offset + i];
      i += d;
      e = s & (1 << -nBits) - 1;
      s >>= -nBits;
      nBits += eLen;
      for (; nBits > 0; e = e * 256 + buffer2[offset + i], i += d, nBits -= 8) {
      }
      m = e & (1 << -nBits) - 1;
      e >>= -nBits;
      nBits += mLen;
      for (; nBits > 0; m = m * 256 + buffer2[offset + i], i += d, nBits -= 8) {
      }
      if (e === 0) {
        e = 1 - eBias;
      } else if (e === eMax) {
        return m ? NaN : (s ? -1 : 1) * Infinity;
      } else {
        m = m + Math.pow(2, mLen);
        e = e - eBias;
      }
      return (s ? -1 : 1) * m * Math.pow(2, e - mLen);
    };
    ieee754.write = function(buffer2, value, offset, isLE, mLen, nBytes) {
      var e, m, c;
      var eLen = nBytes * 8 - mLen - 1;
      var eMax = (1 << eLen) - 1;
      var eBias = eMax >> 1;
      var rt = mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0;
      var i = isLE ? 0 : nBytes - 1;
      var d = isLE ? 1 : -1;
      var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
      value = Math.abs(value);
      if (isNaN(value) || value === Infinity) {
        m = isNaN(value) ? 1 : 0;
        e = eMax;
      } else {
        e = Math.floor(Math.log(value) / Math.LN2);
        if (value * (c = Math.pow(2, -e)) < 1) {
          e--;
          c *= 2;
        }
        if (e + eBias >= 1) {
          value += rt / c;
        } else {
          value += rt * Math.pow(2, 1 - eBias);
        }
        if (value * c >= 2) {
          e++;
          c /= 2;
        }
        if (e + eBias >= eMax) {
          m = 0;
          e = eMax;
        } else if (e + eBias >= 1) {
          m = (value * c - 1) * Math.pow(2, mLen);
          e = e + eBias;
        } else {
          m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
          e = 0;
        }
      }
      for (; mLen >= 8; buffer2[offset + i] = m & 255, i += d, m /= 256, mLen -= 8) {
      }
      e = e << mLen | m;
      eLen += mLen;
      for (; eLen > 0; buffer2[offset + i] = e & 255, i += d, e /= 256, eLen -= 8) {
      }
      buffer2[offset + i - d] |= s * 128;
    };
    return ieee754;
  }
  /*!
   * The buffer module from node.js, for the browser.
   *
   * @author   Feross Aboukhadijeh <https://feross.org>
   * @license  MIT
   */
  var hasRequiredBuffer;
  function requireBuffer() {
    if (hasRequiredBuffer) return buffer;
    hasRequiredBuffer = 1;
    (function(exports) {
      const base64 = requireBase64Js();
      const ieee7542 = requireIeee754();
      const customInspectSymbol = typeof Symbol === "function" && typeof Symbol["for"] === "function" ? Symbol["for"]("nodejs.util.inspect.custom") : null;
      exports.Buffer = Buffer2;
      exports.SlowBuffer = SlowBuffer;
      exports.INSPECT_MAX_BYTES = 50;
      const K_MAX_LENGTH = 2147483647;
      exports.kMaxLength = K_MAX_LENGTH;
      Buffer2.TYPED_ARRAY_SUPPORT = typedArraySupport();
      if (!Buffer2.TYPED_ARRAY_SUPPORT && typeof console !== "undefined" && typeof console.error === "function") {
        console.error(
          "This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."
        );
      }
      function typedArraySupport() {
        try {
          const arr = new Uint8Array(1);
          const proto = { foo: function() {
            return 42;
          } };
          Object.setPrototypeOf(proto, Uint8Array.prototype);
          Object.setPrototypeOf(arr, proto);
          return arr.foo() === 42;
        } catch (e) {
          return false;
        }
      }
      Object.defineProperty(Buffer2.prototype, "parent", {
        enumerable: true,
        get: function() {
          if (!Buffer2.isBuffer(this)) return void 0;
          return this.buffer;
        }
      });
      Object.defineProperty(Buffer2.prototype, "offset", {
        enumerable: true,
        get: function() {
          if (!Buffer2.isBuffer(this)) return void 0;
          return this.byteOffset;
        }
      });
      function createBuffer(length) {
        if (length > K_MAX_LENGTH) {
          throw new RangeError('The value "' + length + '" is invalid for option "size"');
        }
        const buf = new Uint8Array(length);
        Object.setPrototypeOf(buf, Buffer2.prototype);
        return buf;
      }
      function Buffer2(arg, encodingOrOffset, length) {
        if (typeof arg === "number") {
          if (typeof encodingOrOffset === "string") {
            throw new TypeError(
              'The "string" argument must be of type string. Received type number'
            );
          }
          return allocUnsafe(arg);
        }
        return from(arg, encodingOrOffset, length);
      }
      Buffer2.poolSize = 8192;
      function from(value, encodingOrOffset, length) {
        if (typeof value === "string") {
          return fromString(value, encodingOrOffset);
        }
        if (ArrayBuffer.isView(value)) {
          return fromArrayView(value);
        }
        if (value == null) {
          throw new TypeError(
            "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value
          );
        }
        if (isInstance(value, ArrayBuffer) || value && isInstance(value.buffer, ArrayBuffer)) {
          return fromArrayBuffer(value, encodingOrOffset, length);
        }
        if (typeof SharedArrayBuffer !== "undefined" && (isInstance(value, SharedArrayBuffer) || value && isInstance(value.buffer, SharedArrayBuffer))) {
          return fromArrayBuffer(value, encodingOrOffset, length);
        }
        if (typeof value === "number") {
          throw new TypeError(
            'The "value" argument must not be of type number. Received type number'
          );
        }
        const valueOf = value.valueOf && value.valueOf();
        if (valueOf != null && valueOf !== value) {
          return Buffer2.from(valueOf, encodingOrOffset, length);
        }
        const b = fromObject(value);
        if (b) return b;
        if (typeof Symbol !== "undefined" && Symbol.toPrimitive != null && typeof value[Symbol.toPrimitive] === "function") {
          return Buffer2.from(value[Symbol.toPrimitive]("string"), encodingOrOffset, length);
        }
        throw new TypeError(
          "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value
        );
      }
      Buffer2.from = function(value, encodingOrOffset, length) {
        return from(value, encodingOrOffset, length);
      };
      Object.setPrototypeOf(Buffer2.prototype, Uint8Array.prototype);
      Object.setPrototypeOf(Buffer2, Uint8Array);
      function assertSize(size) {
        if (typeof size !== "number") {
          throw new TypeError('"size" argument must be of type number');
        } else if (size < 0) {
          throw new RangeError('The value "' + size + '" is invalid for option "size"');
        }
      }
      function alloc(size, fill, encoding) {
        assertSize(size);
        if (size <= 0) {
          return createBuffer(size);
        }
        if (fill !== void 0) {
          return typeof encoding === "string" ? createBuffer(size).fill(fill, encoding) : createBuffer(size).fill(fill);
        }
        return createBuffer(size);
      }
      Buffer2.alloc = function(size, fill, encoding) {
        return alloc(size, fill, encoding);
      };
      function allocUnsafe(size) {
        assertSize(size);
        return createBuffer(size < 0 ? 0 : checked(size) | 0);
      }
      Buffer2.allocUnsafe = function(size) {
        return allocUnsafe(size);
      };
      Buffer2.allocUnsafeSlow = function(size) {
        return allocUnsafe(size);
      };
      function fromString(string, encoding) {
        if (typeof encoding !== "string" || encoding === "") {
          encoding = "utf8";
        }
        if (!Buffer2.isEncoding(encoding)) {
          throw new TypeError("Unknown encoding: " + encoding);
        }
        const length = byteLength(string, encoding) | 0;
        let buf = createBuffer(length);
        const actual = buf.write(string, encoding);
        if (actual !== length) {
          buf = buf.slice(0, actual);
        }
        return buf;
      }
      function fromArrayLike(array) {
        const length = array.length < 0 ? 0 : checked(array.length) | 0;
        const buf = createBuffer(length);
        for (let i = 0; i < length; i += 1) {
          buf[i] = array[i] & 255;
        }
        return buf;
      }
      function fromArrayView(arrayView) {
        if (isInstance(arrayView, Uint8Array)) {
          const copy = new Uint8Array(arrayView);
          return fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength);
        }
        return fromArrayLike(arrayView);
      }
      function fromArrayBuffer(array, byteOffset, length) {
        if (byteOffset < 0 || array.byteLength < byteOffset) {
          throw new RangeError('"offset" is outside of buffer bounds');
        }
        if (array.byteLength < byteOffset + (length || 0)) {
          throw new RangeError('"length" is outside of buffer bounds');
        }
        let buf;
        if (byteOffset === void 0 && length === void 0) {
          buf = new Uint8Array(array);
        } else if (length === void 0) {
          buf = new Uint8Array(array, byteOffset);
        } else {
          buf = new Uint8Array(array, byteOffset, length);
        }
        Object.setPrototypeOf(buf, Buffer2.prototype);
        return buf;
      }
      function fromObject(obj) {
        if (Buffer2.isBuffer(obj)) {
          const len = checked(obj.length) | 0;
          const buf = createBuffer(len);
          if (buf.length === 0) {
            return buf;
          }
          obj.copy(buf, 0, 0, len);
          return buf;
        }
        if (obj.length !== void 0) {
          if (typeof obj.length !== "number" || numberIsNaN(obj.length)) {
            return createBuffer(0);
          }
          return fromArrayLike(obj);
        }
        if (obj.type === "Buffer" && Array.isArray(obj.data)) {
          return fromArrayLike(obj.data);
        }
      }
      function checked(length) {
        if (length >= K_MAX_LENGTH) {
          throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + K_MAX_LENGTH.toString(16) + " bytes");
        }
        return length | 0;
      }
      function SlowBuffer(length) {
        if (+length != length) {
          length = 0;
        }
        return Buffer2.alloc(+length);
      }
      Buffer2.isBuffer = function isBuffer(b) {
        return b != null && b._isBuffer === true && b !== Buffer2.prototype;
      };
      Buffer2.compare = function compare(a, b) {
        if (isInstance(a, Uint8Array)) a = Buffer2.from(a, a.offset, a.byteLength);
        if (isInstance(b, Uint8Array)) b = Buffer2.from(b, b.offset, b.byteLength);
        if (!Buffer2.isBuffer(a) || !Buffer2.isBuffer(b)) {
          throw new TypeError(
            'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
          );
        }
        if (a === b) return 0;
        let x = a.length;
        let y = b.length;
        for (let i = 0, len = Math.min(x, y); i < len; ++i) {
          if (a[i] !== b[i]) {
            x = a[i];
            y = b[i];
            break;
          }
        }
        if (x < y) return -1;
        if (y < x) return 1;
        return 0;
      };
      Buffer2.isEncoding = function isEncoding(encoding) {
        switch (String(encoding).toLowerCase()) {
          case "hex":
          case "utf8":
          case "utf-8":
          case "ascii":
          case "latin1":
          case "binary":
          case "base64":
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return true;
          default:
            return false;
        }
      };
      Buffer2.concat = function concat(list, length) {
        if (!Array.isArray(list)) {
          throw new TypeError('"list" argument must be an Array of Buffers');
        }
        if (list.length === 0) {
          return Buffer2.alloc(0);
        }
        let i;
        if (length === void 0) {
          length = 0;
          for (i = 0; i < list.length; ++i) {
            length += list[i].length;
          }
        }
        const buffer2 = Buffer2.allocUnsafe(length);
        let pos = 0;
        for (i = 0; i < list.length; ++i) {
          let buf = list[i];
          if (isInstance(buf, Uint8Array)) {
            if (pos + buf.length > buffer2.length) {
              if (!Buffer2.isBuffer(buf)) buf = Buffer2.from(buf);
              buf.copy(buffer2, pos);
            } else {
              Uint8Array.prototype.set.call(
                buffer2,
                buf,
                pos
              );
            }
          } else if (!Buffer2.isBuffer(buf)) {
            throw new TypeError('"list" argument must be an Array of Buffers');
          } else {
            buf.copy(buffer2, pos);
          }
          pos += buf.length;
        }
        return buffer2;
      };
      function byteLength(string, encoding) {
        if (Buffer2.isBuffer(string)) {
          return string.length;
        }
        if (ArrayBuffer.isView(string) || isInstance(string, ArrayBuffer)) {
          return string.byteLength;
        }
        if (typeof string !== "string") {
          throw new TypeError(
            'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof string
          );
        }
        const len = string.length;
        const mustMatch = arguments.length > 2 && arguments[2] === true;
        if (!mustMatch && len === 0) return 0;
        let loweredCase = false;
        for (; ; ) {
          switch (encoding) {
            case "ascii":
            case "latin1":
            case "binary":
              return len;
            case "utf8":
            case "utf-8":
              return utf8ToBytes(string).length;
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return len * 2;
            case "hex":
              return len >>> 1;
            case "base64":
              return base64ToBytes(string).length;
            default:
              if (loweredCase) {
                return mustMatch ? -1 : utf8ToBytes(string).length;
              }
              encoding = ("" + encoding).toLowerCase();
              loweredCase = true;
          }
        }
      }
      Buffer2.byteLength = byteLength;
      function slowToString(encoding, start, end) {
        let loweredCase = false;
        if (start === void 0 || start < 0) {
          start = 0;
        }
        if (start > this.length) {
          return "";
        }
        if (end === void 0 || end > this.length) {
          end = this.length;
        }
        if (end <= 0) {
          return "";
        }
        end >>>= 0;
        start >>>= 0;
        if (end <= start) {
          return "";
        }
        if (!encoding) encoding = "utf8";
        while (true) {
          switch (encoding) {
            case "hex":
              return hexSlice(this, start, end);
            case "utf8":
            case "utf-8":
              return utf8Slice(this, start, end);
            case "ascii":
              return asciiSlice(this, start, end);
            case "latin1":
            case "binary":
              return latin1Slice(this, start, end);
            case "base64":
              return base64Slice(this, start, end);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return utf16leSlice(this, start, end);
            default:
              if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
              encoding = (encoding + "").toLowerCase();
              loweredCase = true;
          }
        }
      }
      Buffer2.prototype._isBuffer = true;
      function swap(b, n, m) {
        const i = b[n];
        b[n] = b[m];
        b[m] = i;
      }
      Buffer2.prototype.swap16 = function swap16() {
        const len = this.length;
        if (len % 2 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 16-bits");
        }
        for (let i = 0; i < len; i += 2) {
          swap(this, i, i + 1);
        }
        return this;
      };
      Buffer2.prototype.swap32 = function swap32() {
        const len = this.length;
        if (len % 4 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 32-bits");
        }
        for (let i = 0; i < len; i += 4) {
          swap(this, i, i + 3);
          swap(this, i + 1, i + 2);
        }
        return this;
      };
      Buffer2.prototype.swap64 = function swap64() {
        const len = this.length;
        if (len % 8 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 64-bits");
        }
        for (let i = 0; i < len; i += 8) {
          swap(this, i, i + 7);
          swap(this, i + 1, i + 6);
          swap(this, i + 2, i + 5);
          swap(this, i + 3, i + 4);
        }
        return this;
      };
      Buffer2.prototype.toString = function toString() {
        const length = this.length;
        if (length === 0) return "";
        if (arguments.length === 0) return utf8Slice(this, 0, length);
        return slowToString.apply(this, arguments);
      };
      Buffer2.prototype.toLocaleString = Buffer2.prototype.toString;
      Buffer2.prototype.equals = function equals(b) {
        if (!Buffer2.isBuffer(b)) throw new TypeError("Argument must be a Buffer");
        if (this === b) return true;
        return Buffer2.compare(this, b) === 0;
      };
      Buffer2.prototype.inspect = function inspect() {
        let str = "";
        const max = exports.INSPECT_MAX_BYTES;
        str = this.toString("hex", 0, max).replace(/(.{2})/g, "$1 ").trim();
        if (this.length > max) str += " ... ";
        return "<Buffer " + str + ">";
      };
      if (customInspectSymbol) {
        Buffer2.prototype[customInspectSymbol] = Buffer2.prototype.inspect;
      }
      Buffer2.prototype.compare = function compare(target, start, end, thisStart, thisEnd) {
        if (isInstance(target, Uint8Array)) {
          target = Buffer2.from(target, target.offset, target.byteLength);
        }
        if (!Buffer2.isBuffer(target)) {
          throw new TypeError(
            'The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof target
          );
        }
        if (start === void 0) {
          start = 0;
        }
        if (end === void 0) {
          end = target ? target.length : 0;
        }
        if (thisStart === void 0) {
          thisStart = 0;
        }
        if (thisEnd === void 0) {
          thisEnd = this.length;
        }
        if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
          throw new RangeError("out of range index");
        }
        if (thisStart >= thisEnd && start >= end) {
          return 0;
        }
        if (thisStart >= thisEnd) {
          return -1;
        }
        if (start >= end) {
          return 1;
        }
        start >>>= 0;
        end >>>= 0;
        thisStart >>>= 0;
        thisEnd >>>= 0;
        if (this === target) return 0;
        let x = thisEnd - thisStart;
        let y = end - start;
        const len = Math.min(x, y);
        const thisCopy = this.slice(thisStart, thisEnd);
        const targetCopy = target.slice(start, end);
        for (let i = 0; i < len; ++i) {
          if (thisCopy[i] !== targetCopy[i]) {
            x = thisCopy[i];
            y = targetCopy[i];
            break;
          }
        }
        if (x < y) return -1;
        if (y < x) return 1;
        return 0;
      };
      function bidirectionalIndexOf(buffer2, val, byteOffset, encoding, dir) {
        if (buffer2.length === 0) return -1;
        if (typeof byteOffset === "string") {
          encoding = byteOffset;
          byteOffset = 0;
        } else if (byteOffset > 2147483647) {
          byteOffset = 2147483647;
        } else if (byteOffset < -2147483648) {
          byteOffset = -2147483648;
        }
        byteOffset = +byteOffset;
        if (numberIsNaN(byteOffset)) {
          byteOffset = dir ? 0 : buffer2.length - 1;
        }
        if (byteOffset < 0) byteOffset = buffer2.length + byteOffset;
        if (byteOffset >= buffer2.length) {
          if (dir) return -1;
          else byteOffset = buffer2.length - 1;
        } else if (byteOffset < 0) {
          if (dir) byteOffset = 0;
          else return -1;
        }
        if (typeof val === "string") {
          val = Buffer2.from(val, encoding);
        }
        if (Buffer2.isBuffer(val)) {
          if (val.length === 0) {
            return -1;
          }
          return arrayIndexOf(buffer2, val, byteOffset, encoding, dir);
        } else if (typeof val === "number") {
          val = val & 255;
          if (typeof Uint8Array.prototype.indexOf === "function") {
            if (dir) {
              return Uint8Array.prototype.indexOf.call(buffer2, val, byteOffset);
            } else {
              return Uint8Array.prototype.lastIndexOf.call(buffer2, val, byteOffset);
            }
          }
          return arrayIndexOf(buffer2, [val], byteOffset, encoding, dir);
        }
        throw new TypeError("val must be string, number or Buffer");
      }
      function arrayIndexOf(arr, val, byteOffset, encoding, dir) {
        let indexSize = 1;
        let arrLength = arr.length;
        let valLength = val.length;
        if (encoding !== void 0) {
          encoding = String(encoding).toLowerCase();
          if (encoding === "ucs2" || encoding === "ucs-2" || encoding === "utf16le" || encoding === "utf-16le") {
            if (arr.length < 2 || val.length < 2) {
              return -1;
            }
            indexSize = 2;
            arrLength /= 2;
            valLength /= 2;
            byteOffset /= 2;
          }
        }
        function read(buf, i2) {
          if (indexSize === 1) {
            return buf[i2];
          } else {
            return buf.readUInt16BE(i2 * indexSize);
          }
        }
        let i;
        if (dir) {
          let foundIndex = -1;
          for (i = byteOffset; i < arrLength; i++) {
            if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
              if (foundIndex === -1) foundIndex = i;
              if (i - foundIndex + 1 === valLength) return foundIndex * indexSize;
            } else {
              if (foundIndex !== -1) i -= i - foundIndex;
              foundIndex = -1;
            }
          }
        } else {
          if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength;
          for (i = byteOffset; i >= 0; i--) {
            let found = true;
            for (let j = 0; j < valLength; j++) {
              if (read(arr, i + j) !== read(val, j)) {
                found = false;
                break;
              }
            }
            if (found) return i;
          }
        }
        return -1;
      }
      Buffer2.prototype.includes = function includes(val, byteOffset, encoding) {
        return this.indexOf(val, byteOffset, encoding) !== -1;
      };
      Buffer2.prototype.indexOf = function indexOf(val, byteOffset, encoding) {
        return bidirectionalIndexOf(this, val, byteOffset, encoding, true);
      };
      Buffer2.prototype.lastIndexOf = function lastIndexOf(val, byteOffset, encoding) {
        return bidirectionalIndexOf(this, val, byteOffset, encoding, false);
      };
      function hexWrite(buf, string, offset, length) {
        offset = Number(offset) || 0;
        const remaining = buf.length - offset;
        if (!length) {
          length = remaining;
        } else {
          length = Number(length);
          if (length > remaining) {
            length = remaining;
          }
        }
        const strLen = string.length;
        if (length > strLen / 2) {
          length = strLen / 2;
        }
        let i;
        for (i = 0; i < length; ++i) {
          const parsed = parseInt(string.substr(i * 2, 2), 16);
          if (numberIsNaN(parsed)) return i;
          buf[offset + i] = parsed;
        }
        return i;
      }
      function utf8Write(buf, string, offset, length) {
        return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length);
      }
      function asciiWrite(buf, string, offset, length) {
        return blitBuffer(asciiToBytes(string), buf, offset, length);
      }
      function base64Write(buf, string, offset, length) {
        return blitBuffer(base64ToBytes(string), buf, offset, length);
      }
      function ucs2Write(buf, string, offset, length) {
        return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length);
      }
      Buffer2.prototype.write = function write(string, offset, length, encoding) {
        if (offset === void 0) {
          encoding = "utf8";
          length = this.length;
          offset = 0;
        } else if (length === void 0 && typeof offset === "string") {
          encoding = offset;
          length = this.length;
          offset = 0;
        } else if (isFinite(offset)) {
          offset = offset >>> 0;
          if (isFinite(length)) {
            length = length >>> 0;
            if (encoding === void 0) encoding = "utf8";
          } else {
            encoding = length;
            length = void 0;
          }
        } else {
          throw new Error(
            "Buffer.write(string, encoding, offset[, length]) is no longer supported"
          );
        }
        const remaining = this.length - offset;
        if (length === void 0 || length > remaining) length = remaining;
        if (string.length > 0 && (length < 0 || offset < 0) || offset > this.length) {
          throw new RangeError("Attempt to write outside buffer bounds");
        }
        if (!encoding) encoding = "utf8";
        let loweredCase = false;
        for (; ; ) {
          switch (encoding) {
            case "hex":
              return hexWrite(this, string, offset, length);
            case "utf8":
            case "utf-8":
              return utf8Write(this, string, offset, length);
            case "ascii":
            case "latin1":
            case "binary":
              return asciiWrite(this, string, offset, length);
            case "base64":
              return base64Write(this, string, offset, length);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return ucs2Write(this, string, offset, length);
            default:
              if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
              encoding = ("" + encoding).toLowerCase();
              loweredCase = true;
          }
        }
      };
      Buffer2.prototype.toJSON = function toJSON() {
        return {
          type: "Buffer",
          data: Array.prototype.slice.call(this._arr || this, 0)
        };
      };
      function base64Slice(buf, start, end) {
        if (start === 0 && end === buf.length) {
          return base64.fromByteArray(buf);
        } else {
          return base64.fromByteArray(buf.slice(start, end));
        }
      }
      function utf8Slice(buf, start, end) {
        end = Math.min(buf.length, end);
        const res = [];
        let i = start;
        while (i < end) {
          const firstByte = buf[i];
          let codePoint = null;
          let bytesPerSequence = firstByte > 239 ? 4 : firstByte > 223 ? 3 : firstByte > 191 ? 2 : 1;
          if (i + bytesPerSequence <= end) {
            let secondByte, thirdByte, fourthByte, tempCodePoint;
            switch (bytesPerSequence) {
              case 1:
                if (firstByte < 128) {
                  codePoint = firstByte;
                }
                break;
              case 2:
                secondByte = buf[i + 1];
                if ((secondByte & 192) === 128) {
                  tempCodePoint = (firstByte & 31) << 6 | secondByte & 63;
                  if (tempCodePoint > 127) {
                    codePoint = tempCodePoint;
                  }
                }
                break;
              case 3:
                secondByte = buf[i + 1];
                thirdByte = buf[i + 2];
                if ((secondByte & 192) === 128 && (thirdByte & 192) === 128) {
                  tempCodePoint = (firstByte & 15) << 12 | (secondByte & 63) << 6 | thirdByte & 63;
                  if (tempCodePoint > 2047 && (tempCodePoint < 55296 || tempCodePoint > 57343)) {
                    codePoint = tempCodePoint;
                  }
                }
                break;
              case 4:
                secondByte = buf[i + 1];
                thirdByte = buf[i + 2];
                fourthByte = buf[i + 3];
                if ((secondByte & 192) === 128 && (thirdByte & 192) === 128 && (fourthByte & 192) === 128) {
                  tempCodePoint = (firstByte & 15) << 18 | (secondByte & 63) << 12 | (thirdByte & 63) << 6 | fourthByte & 63;
                  if (tempCodePoint > 65535 && tempCodePoint < 1114112) {
                    codePoint = tempCodePoint;
                  }
                }
            }
          }
          if (codePoint === null) {
            codePoint = 65533;
            bytesPerSequence = 1;
          } else if (codePoint > 65535) {
            codePoint -= 65536;
            res.push(codePoint >>> 10 & 1023 | 55296);
            codePoint = 56320 | codePoint & 1023;
          }
          res.push(codePoint);
          i += bytesPerSequence;
        }
        return decodeCodePointsArray(res);
      }
      const MAX_ARGUMENTS_LENGTH = 4096;
      function decodeCodePointsArray(codePoints) {
        const len = codePoints.length;
        if (len <= MAX_ARGUMENTS_LENGTH) {
          return String.fromCharCode.apply(String, codePoints);
        }
        let res = "";
        let i = 0;
        while (i < len) {
          res += String.fromCharCode.apply(
            String,
            codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
          );
        }
        return res;
      }
      function asciiSlice(buf, start, end) {
        let ret = "";
        end = Math.min(buf.length, end);
        for (let i = start; i < end; ++i) {
          ret += String.fromCharCode(buf[i] & 127);
        }
        return ret;
      }
      function latin1Slice(buf, start, end) {
        let ret = "";
        end = Math.min(buf.length, end);
        for (let i = start; i < end; ++i) {
          ret += String.fromCharCode(buf[i]);
        }
        return ret;
      }
      function hexSlice(buf, start, end) {
        const len = buf.length;
        if (!start || start < 0) start = 0;
        if (!end || end < 0 || end > len) end = len;
        let out = "";
        for (let i = start; i < end; ++i) {
          out += hexSliceLookupTable[buf[i]];
        }
        return out;
      }
      function utf16leSlice(buf, start, end) {
        const bytes = buf.slice(start, end);
        let res = "";
        for (let i = 0; i < bytes.length - 1; i += 2) {
          res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256);
        }
        return res;
      }
      Buffer2.prototype.slice = function slice(start, end) {
        const len = this.length;
        start = ~~start;
        end = end === void 0 ? len : ~~end;
        if (start < 0) {
          start += len;
          if (start < 0) start = 0;
        } else if (start > len) {
          start = len;
        }
        if (end < 0) {
          end += len;
          if (end < 0) end = 0;
        } else if (end > len) {
          end = len;
        }
        if (end < start) end = start;
        const newBuf = this.subarray(start, end);
        Object.setPrototypeOf(newBuf, Buffer2.prototype);
        return newBuf;
      };
      function checkOffset(offset, ext, length) {
        if (offset % 1 !== 0 || offset < 0) throw new RangeError("offset is not uint");
        if (offset + ext > length) throw new RangeError("Trying to access beyond buffer length");
      }
      Buffer2.prototype.readUintLE = Buffer2.prototype.readUIntLE = function readUIntLE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) checkOffset(offset, byteLength2, this.length);
        let val = this[offset];
        let mul = 1;
        let i = 0;
        while (++i < byteLength2 && (mul *= 256)) {
          val += this[offset + i] * mul;
        }
        return val;
      };
      Buffer2.prototype.readUintBE = Buffer2.prototype.readUIntBE = function readUIntBE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          checkOffset(offset, byteLength2, this.length);
        }
        let val = this[offset + --byteLength2];
        let mul = 1;
        while (byteLength2 > 0 && (mul *= 256)) {
          val += this[offset + --byteLength2] * mul;
        }
        return val;
      };
      Buffer2.prototype.readUint8 = Buffer2.prototype.readUInt8 = function readUInt8(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 1, this.length);
        return this[offset];
      };
      Buffer2.prototype.readUint16LE = Buffer2.prototype.readUInt16LE = function readUInt16LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        return this[offset] | this[offset + 1] << 8;
      };
      Buffer2.prototype.readUint16BE = Buffer2.prototype.readUInt16BE = function readUInt16BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        return this[offset] << 8 | this[offset + 1];
      };
      Buffer2.prototype.readUint32LE = Buffer2.prototype.readUInt32LE = function readUInt32LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return (this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16) + this[offset + 3] * 16777216;
      };
      Buffer2.prototype.readUint32BE = Buffer2.prototype.readUInt32BE = function readUInt32BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return this[offset] * 16777216 + (this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3]);
      };
      Buffer2.prototype.readBigUInt64LE = defineBigIntMethod(function readBigUInt64LE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const lo = first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24;
        const hi = this[++offset] + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + last * 2 ** 24;
        return BigInt(lo) + (BigInt(hi) << BigInt(32));
      });
      Buffer2.prototype.readBigUInt64BE = defineBigIntMethod(function readBigUInt64BE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const hi = first * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
        const lo = this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last;
        return (BigInt(hi) << BigInt(32)) + BigInt(lo);
      });
      Buffer2.prototype.readIntLE = function readIntLE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) checkOffset(offset, byteLength2, this.length);
        let val = this[offset];
        let mul = 1;
        let i = 0;
        while (++i < byteLength2 && (mul *= 256)) {
          val += this[offset + i] * mul;
        }
        mul *= 128;
        if (val >= mul) val -= Math.pow(2, 8 * byteLength2);
        return val;
      };
      Buffer2.prototype.readIntBE = function readIntBE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) checkOffset(offset, byteLength2, this.length);
        let i = byteLength2;
        let mul = 1;
        let val = this[offset + --i];
        while (i > 0 && (mul *= 256)) {
          val += this[offset + --i] * mul;
        }
        mul *= 128;
        if (val >= mul) val -= Math.pow(2, 8 * byteLength2);
        return val;
      };
      Buffer2.prototype.readInt8 = function readInt8(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 1, this.length);
        if (!(this[offset] & 128)) return this[offset];
        return (255 - this[offset] + 1) * -1;
      };
      Buffer2.prototype.readInt16LE = function readInt16LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        const val = this[offset] | this[offset + 1] << 8;
        return val & 32768 ? val | 4294901760 : val;
      };
      Buffer2.prototype.readInt16BE = function readInt16BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        const val = this[offset + 1] | this[offset] << 8;
        return val & 32768 ? val | 4294901760 : val;
      };
      Buffer2.prototype.readInt32LE = function readInt32LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16 | this[offset + 3] << 24;
      };
      Buffer2.prototype.readInt32BE = function readInt32BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return this[offset] << 24 | this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3];
      };
      Buffer2.prototype.readBigInt64LE = defineBigIntMethod(function readBigInt64LE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const val = this[offset + 4] + this[offset + 5] * 2 ** 8 + this[offset + 6] * 2 ** 16 + (last << 24);
        return (BigInt(val) << BigInt(32)) + BigInt(first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24);
      });
      Buffer2.prototype.readBigInt64BE = defineBigIntMethod(function readBigInt64BE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const val = (first << 24) + // Overflow
        this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
        return (BigInt(val) << BigInt(32)) + BigInt(this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last);
      });
      Buffer2.prototype.readFloatLE = function readFloatLE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return ieee7542.read(this, offset, true, 23, 4);
      };
      Buffer2.prototype.readFloatBE = function readFloatBE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return ieee7542.read(this, offset, false, 23, 4);
      };
      Buffer2.prototype.readDoubleLE = function readDoubleLE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 8, this.length);
        return ieee7542.read(this, offset, true, 52, 8);
      };
      Buffer2.prototype.readDoubleBE = function readDoubleBE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 8, this.length);
        return ieee7542.read(this, offset, false, 52, 8);
      };
      function checkInt(buf, value, offset, ext, max, min) {
        if (!Buffer2.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance');
        if (value > max || value < min) throw new RangeError('"value" argument is out of bounds');
        if (offset + ext > buf.length) throw new RangeError("Index out of range");
      }
      Buffer2.prototype.writeUintLE = Buffer2.prototype.writeUIntLE = function writeUIntLE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          const maxBytes = Math.pow(2, 8 * byteLength2) - 1;
          checkInt(this, value, offset, byteLength2, maxBytes, 0);
        }
        let mul = 1;
        let i = 0;
        this[offset] = value & 255;
        while (++i < byteLength2 && (mul *= 256)) {
          this[offset + i] = value / mul & 255;
        }
        return offset + byteLength2;
      };
      Buffer2.prototype.writeUintBE = Buffer2.prototype.writeUIntBE = function writeUIntBE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          const maxBytes = Math.pow(2, 8 * byteLength2) - 1;
          checkInt(this, value, offset, byteLength2, maxBytes, 0);
        }
        let i = byteLength2 - 1;
        let mul = 1;
        this[offset + i] = value & 255;
        while (--i >= 0 && (mul *= 256)) {
          this[offset + i] = value / mul & 255;
        }
        return offset + byteLength2;
      };
      Buffer2.prototype.writeUint8 = Buffer2.prototype.writeUInt8 = function writeUInt8(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 1, 255, 0);
        this[offset] = value & 255;
        return offset + 1;
      };
      Buffer2.prototype.writeUint16LE = Buffer2.prototype.writeUInt16LE = function writeUInt16LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        return offset + 2;
      };
      Buffer2.prototype.writeUint16BE = Buffer2.prototype.writeUInt16BE = function writeUInt16BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
        this[offset] = value >>> 8;
        this[offset + 1] = value & 255;
        return offset + 2;
      };
      Buffer2.prototype.writeUint32LE = Buffer2.prototype.writeUInt32LE = function writeUInt32LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
        this[offset + 3] = value >>> 24;
        this[offset + 2] = value >>> 16;
        this[offset + 1] = value >>> 8;
        this[offset] = value & 255;
        return offset + 4;
      };
      Buffer2.prototype.writeUint32BE = Buffer2.prototype.writeUInt32BE = function writeUInt32BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
        this[offset] = value >>> 24;
        this[offset + 1] = value >>> 16;
        this[offset + 2] = value >>> 8;
        this[offset + 3] = value & 255;
        return offset + 4;
      };
      function wrtBigUInt64LE(buf, value, offset, min, max) {
        checkIntBI(value, min, max, buf, offset, 7);
        let lo = Number(value & BigInt(4294967295));
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        let hi = Number(value >> BigInt(32) & BigInt(4294967295));
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        return offset;
      }
      function wrtBigUInt64BE(buf, value, offset, min, max) {
        checkIntBI(value, min, max, buf, offset, 7);
        let lo = Number(value & BigInt(4294967295));
        buf[offset + 7] = lo;
        lo = lo >> 8;
        buf[offset + 6] = lo;
        lo = lo >> 8;
        buf[offset + 5] = lo;
        lo = lo >> 8;
        buf[offset + 4] = lo;
        let hi = Number(value >> BigInt(32) & BigInt(4294967295));
        buf[offset + 3] = hi;
        hi = hi >> 8;
        buf[offset + 2] = hi;
        hi = hi >> 8;
        buf[offset + 1] = hi;
        hi = hi >> 8;
        buf[offset] = hi;
        return offset + 8;
      }
      Buffer2.prototype.writeBigUInt64LE = defineBigIntMethod(function writeBigUInt64LE(value, offset = 0) {
        return wrtBigUInt64LE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
      });
      Buffer2.prototype.writeBigUInt64BE = defineBigIntMethod(function writeBigUInt64BE(value, offset = 0) {
        return wrtBigUInt64BE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
      });
      Buffer2.prototype.writeIntLE = function writeIntLE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          const limit = Math.pow(2, 8 * byteLength2 - 1);
          checkInt(this, value, offset, byteLength2, limit - 1, -limit);
        }
        let i = 0;
        let mul = 1;
        let sub = 0;
        this[offset] = value & 255;
        while (++i < byteLength2 && (mul *= 256)) {
          if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
            sub = 1;
          }
          this[offset + i] = (value / mul >> 0) - sub & 255;
        }
        return offset + byteLength2;
      };
      Buffer2.prototype.writeIntBE = function writeIntBE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          const limit = Math.pow(2, 8 * byteLength2 - 1);
          checkInt(this, value, offset, byteLength2, limit - 1, -limit);
        }
        let i = byteLength2 - 1;
        let mul = 1;
        let sub = 0;
        this[offset + i] = value & 255;
        while (--i >= 0 && (mul *= 256)) {
          if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
            sub = 1;
          }
          this[offset + i] = (value / mul >> 0) - sub & 255;
        }
        return offset + byteLength2;
      };
      Buffer2.prototype.writeInt8 = function writeInt8(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 1, 127, -128);
        if (value < 0) value = 255 + value + 1;
        this[offset] = value & 255;
        return offset + 1;
      };
      Buffer2.prototype.writeInt16LE = function writeInt16LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        return offset + 2;
      };
      Buffer2.prototype.writeInt16BE = function writeInt16BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
        this[offset] = value >>> 8;
        this[offset + 1] = value & 255;
        return offset + 2;
      };
      Buffer2.prototype.writeInt32LE = function writeInt32LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        this[offset + 2] = value >>> 16;
        this[offset + 3] = value >>> 24;
        return offset + 4;
      };
      Buffer2.prototype.writeInt32BE = function writeInt32BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
        if (value < 0) value = 4294967295 + value + 1;
        this[offset] = value >>> 24;
        this[offset + 1] = value >>> 16;
        this[offset + 2] = value >>> 8;
        this[offset + 3] = value & 255;
        return offset + 4;
      };
      Buffer2.prototype.writeBigInt64LE = defineBigIntMethod(function writeBigInt64LE(value, offset = 0) {
        return wrtBigUInt64LE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
      });
      Buffer2.prototype.writeBigInt64BE = defineBigIntMethod(function writeBigInt64BE(value, offset = 0) {
        return wrtBigUInt64BE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
      });
      function checkIEEE754(buf, value, offset, ext, max, min) {
        if (offset + ext > buf.length) throw new RangeError("Index out of range");
        if (offset < 0) throw new RangeError("Index out of range");
      }
      function writeFloat(buf, value, offset, littleEndian, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          checkIEEE754(buf, value, offset, 4);
        }
        ieee7542.write(buf, value, offset, littleEndian, 23, 4);
        return offset + 4;
      }
      Buffer2.prototype.writeFloatLE = function writeFloatLE(value, offset, noAssert) {
        return writeFloat(this, value, offset, true, noAssert);
      };
      Buffer2.prototype.writeFloatBE = function writeFloatBE(value, offset, noAssert) {
        return writeFloat(this, value, offset, false, noAssert);
      };
      function writeDouble(buf, value, offset, littleEndian, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          checkIEEE754(buf, value, offset, 8);
        }
        ieee7542.write(buf, value, offset, littleEndian, 52, 8);
        return offset + 8;
      }
      Buffer2.prototype.writeDoubleLE = function writeDoubleLE(value, offset, noAssert) {
        return writeDouble(this, value, offset, true, noAssert);
      };
      Buffer2.prototype.writeDoubleBE = function writeDoubleBE(value, offset, noAssert) {
        return writeDouble(this, value, offset, false, noAssert);
      };
      Buffer2.prototype.copy = function copy(target, targetStart, start, end) {
        if (!Buffer2.isBuffer(target)) throw new TypeError("argument should be a Buffer");
        if (!start) start = 0;
        if (!end && end !== 0) end = this.length;
        if (targetStart >= target.length) targetStart = target.length;
        if (!targetStart) targetStart = 0;
        if (end > 0 && end < start) end = start;
        if (end === start) return 0;
        if (target.length === 0 || this.length === 0) return 0;
        if (targetStart < 0) {
          throw new RangeError("targetStart out of bounds");
        }
        if (start < 0 || start >= this.length) throw new RangeError("Index out of range");
        if (end < 0) throw new RangeError("sourceEnd out of bounds");
        if (end > this.length) end = this.length;
        if (target.length - targetStart < end - start) {
          end = target.length - targetStart + start;
        }
        const len = end - start;
        if (this === target && typeof Uint8Array.prototype.copyWithin === "function") {
          this.copyWithin(targetStart, start, end);
        } else {
          Uint8Array.prototype.set.call(
            target,
            this.subarray(start, end),
            targetStart
          );
        }
        return len;
      };
      Buffer2.prototype.fill = function fill(val, start, end, encoding) {
        if (typeof val === "string") {
          if (typeof start === "string") {
            encoding = start;
            start = 0;
            end = this.length;
          } else if (typeof end === "string") {
            encoding = end;
            end = this.length;
          }
          if (encoding !== void 0 && typeof encoding !== "string") {
            throw new TypeError("encoding must be a string");
          }
          if (typeof encoding === "string" && !Buffer2.isEncoding(encoding)) {
            throw new TypeError("Unknown encoding: " + encoding);
          }
          if (val.length === 1) {
            const code = val.charCodeAt(0);
            if (encoding === "utf8" && code < 128 || encoding === "latin1") {
              val = code;
            }
          }
        } else if (typeof val === "number") {
          val = val & 255;
        } else if (typeof val === "boolean") {
          val = Number(val);
        }
        if (start < 0 || this.length < start || this.length < end) {
          throw new RangeError("Out of range index");
        }
        if (end <= start) {
          return this;
        }
        start = start >>> 0;
        end = end === void 0 ? this.length : end >>> 0;
        if (!val) val = 0;
        let i;
        if (typeof val === "number") {
          for (i = start; i < end; ++i) {
            this[i] = val;
          }
        } else {
          const bytes = Buffer2.isBuffer(val) ? val : Buffer2.from(val, encoding);
          const len = bytes.length;
          if (len === 0) {
            throw new TypeError('The value "' + val + '" is invalid for argument "value"');
          }
          for (i = 0; i < end - start; ++i) {
            this[i + start] = bytes[i % len];
          }
        }
        return this;
      };
      const errors = {};
      function E(sym, getMessage, Base) {
        errors[sym] = class NodeError extends Base {
          constructor() {
            super();
            Object.defineProperty(this, "message", {
              value: getMessage.apply(this, arguments),
              writable: true,
              configurable: true
            });
            this.name = `${this.name} [${sym}]`;
            this.stack;
            delete this.name;
          }
          get code() {
            return sym;
          }
          set code(value) {
            Object.defineProperty(this, "code", {
              configurable: true,
              enumerable: true,
              value,
              writable: true
            });
          }
          toString() {
            return `${this.name} [${sym}]: ${this.message}`;
          }
        };
      }
      E(
        "ERR_BUFFER_OUT_OF_BOUNDS",
        function(name) {
          if (name) {
            return `${name} is outside of buffer bounds`;
          }
          return "Attempt to access memory outside buffer bounds";
        },
        RangeError
      );
      E(
        "ERR_INVALID_ARG_TYPE",
        function(name, actual) {
          return `The "${name}" argument must be of type number. Received type ${typeof actual}`;
        },
        TypeError
      );
      E(
        "ERR_OUT_OF_RANGE",
        function(str, range, input) {
          let msg = `The value of "${str}" is out of range.`;
          let received = input;
          if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) {
            received = addNumericalSeparator(String(input));
          } else if (typeof input === "bigint") {
            received = String(input);
            if (input > BigInt(2) ** BigInt(32) || input < -(BigInt(2) ** BigInt(32))) {
              received = addNumericalSeparator(received);
            }
            received += "n";
          }
          msg += ` It must be ${range}. Received ${received}`;
          return msg;
        },
        RangeError
      );
      function addNumericalSeparator(val) {
        let res = "";
        let i = val.length;
        const start = val[0] === "-" ? 1 : 0;
        for (; i >= start + 4; i -= 3) {
          res = `_${val.slice(i - 3, i)}${res}`;
        }
        return `${val.slice(0, i)}${res}`;
      }
      function checkBounds(buf, offset, byteLength2) {
        validateNumber(offset, "offset");
        if (buf[offset] === void 0 || buf[offset + byteLength2] === void 0) {
          boundsError(offset, buf.length - (byteLength2 + 1));
        }
      }
      function checkIntBI(value, min, max, buf, offset, byteLength2) {
        if (value > max || value < min) {
          const n = typeof min === "bigint" ? "n" : "";
          let range;
          {
            if (min === 0 || min === BigInt(0)) {
              range = `>= 0${n} and < 2${n} ** ${(byteLength2 + 1) * 8}${n}`;
            } else {
              range = `>= -(2${n} ** ${(byteLength2 + 1) * 8 - 1}${n}) and < 2 ** ${(byteLength2 + 1) * 8 - 1}${n}`;
            }
          }
          throw new errors.ERR_OUT_OF_RANGE("value", range, value);
        }
        checkBounds(buf, offset, byteLength2);
      }
      function validateNumber(value, name) {
        if (typeof value !== "number") {
          throw new errors.ERR_INVALID_ARG_TYPE(name, "number", value);
        }
      }
      function boundsError(value, length, type) {
        if (Math.floor(value) !== value) {
          validateNumber(value, type);
          throw new errors.ERR_OUT_OF_RANGE("offset", "an integer", value);
        }
        if (length < 0) {
          throw new errors.ERR_BUFFER_OUT_OF_BOUNDS();
        }
        throw new errors.ERR_OUT_OF_RANGE(
          "offset",
          `>= ${0} and <= ${length}`,
          value
        );
      }
      const INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g;
      function base64clean(str) {
        str = str.split("=")[0];
        str = str.trim().replace(INVALID_BASE64_RE, "");
        if (str.length < 2) return "";
        while (str.length % 4 !== 0) {
          str = str + "=";
        }
        return str;
      }
      function utf8ToBytes(string, units) {
        units = units || Infinity;
        let codePoint;
        const length = string.length;
        let leadSurrogate = null;
        const bytes = [];
        for (let i = 0; i < length; ++i) {
          codePoint = string.charCodeAt(i);
          if (codePoint > 55295 && codePoint < 57344) {
            if (!leadSurrogate) {
              if (codePoint > 56319) {
                if ((units -= 3) > -1) bytes.push(239, 191, 189);
                continue;
              } else if (i + 1 === length) {
                if ((units -= 3) > -1) bytes.push(239, 191, 189);
                continue;
              }
              leadSurrogate = codePoint;
              continue;
            }
            if (codePoint < 56320) {
              if ((units -= 3) > -1) bytes.push(239, 191, 189);
              leadSurrogate = codePoint;
              continue;
            }
            codePoint = (leadSurrogate - 55296 << 10 | codePoint - 56320) + 65536;
          } else if (leadSurrogate) {
            if ((units -= 3) > -1) bytes.push(239, 191, 189);
          }
          leadSurrogate = null;
          if (codePoint < 128) {
            if ((units -= 1) < 0) break;
            bytes.push(codePoint);
          } else if (codePoint < 2048) {
            if ((units -= 2) < 0) break;
            bytes.push(
              codePoint >> 6 | 192,
              codePoint & 63 | 128
            );
          } else if (codePoint < 65536) {
            if ((units -= 3) < 0) break;
            bytes.push(
              codePoint >> 12 | 224,
              codePoint >> 6 & 63 | 128,
              codePoint & 63 | 128
            );
          } else if (codePoint < 1114112) {
            if ((units -= 4) < 0) break;
            bytes.push(
              codePoint >> 18 | 240,
              codePoint >> 12 & 63 | 128,
              codePoint >> 6 & 63 | 128,
              codePoint & 63 | 128
            );
          } else {
            throw new Error("Invalid code point");
          }
        }
        return bytes;
      }
      function asciiToBytes(str) {
        const byteArray = [];
        for (let i = 0; i < str.length; ++i) {
          byteArray.push(str.charCodeAt(i) & 255);
        }
        return byteArray;
      }
      function utf16leToBytes(str, units) {
        let c, hi, lo;
        const byteArray = [];
        for (let i = 0; i < str.length; ++i) {
          if ((units -= 2) < 0) break;
          c = str.charCodeAt(i);
          hi = c >> 8;
          lo = c % 256;
          byteArray.push(lo);
          byteArray.push(hi);
        }
        return byteArray;
      }
      function base64ToBytes(str) {
        return base64.toByteArray(base64clean(str));
      }
      function blitBuffer(src, dst, offset, length) {
        let i;
        for (i = 0; i < length; ++i) {
          if (i + offset >= dst.length || i >= src.length) break;
          dst[i + offset] = src[i];
        }
        return i;
      }
      function isInstance(obj, type) {
        return obj instanceof type || obj != null && obj.constructor != null && obj.constructor.name != null && obj.constructor.name === type.name;
      }
      function numberIsNaN(obj) {
        return obj !== obj;
      }
      const hexSliceLookupTable = (function() {
        const alphabet = "0123456789abcdef";
        const table = new Array(256);
        for (let i = 0; i < 16; ++i) {
          const i16 = i * 16;
          for (let j = 0; j < 16; ++j) {
            table[i16 + j] = alphabet[i] + alphabet[j];
          }
        }
        return table;
      })();
      function defineBigIntMethod(fn) {
        return typeof BigInt === "undefined" ? BufferBigIntNotDefined : fn;
      }
      function BufferBigIntNotDefined() {
        throw new Error("BigInt not supported");
      }
    })(buffer);
    return buffer;
  }
  var toolsEbml = {};
  var hasRequiredToolsEbml;
  function requireToolsEbml() {
    if (hasRequiredToolsEbml) return toolsEbml;
    hasRequiredToolsEbml = 1;
    var __assign = toolsEbml && toolsEbml.__assign || function() {
      __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
        }
        return t;
      };
      return __assign.apply(this, arguments);
    };
    var __spreadArray = toolsEbml && toolsEbml.__spreadArray || function(to, from, pack) {
      if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
        }
      }
      return to.concat(ar || Array.prototype.slice.call(from));
    };
    Object.defineProperty(toolsEbml, "__esModule", { value: true });
    var tools_1 = requireTools();
    var Tools = (
      /** @class */
      (function() {
        function Tools2() {
        }
        Tools2.readVint = function(buffer2, start) {
          if (start === void 0) {
            start = 0;
          }
          var length = 8 - Math.floor(Math.log2(buffer2[start]));
          if (length > 8) {
            var number = Tools2.readHexString(buffer2, start, start + length);
            throw new Error("Unrepresentable length: ".concat(length, " ").concat(number));
          }
          if (start + length > buffer2.length) {
            return null;
          }
          var value = buffer2[start] & (1 << 8 - length) - 1;
          for (var i = 1; i < length; i += 1) {
            if (i === 7) {
              if (value >= Math.pow(2, 8) && buffer2[start + 7] > 0) {
                return { length, value: -1 };
              }
            }
            value *= Math.pow(2, 8);
            value += buffer2[start + i];
          }
          return { length, value };
        };
        Tools2.writeVint = function(value) {
          if (value < 0 || value > Math.pow(2, 53)) {
            throw new Error("Unrepresentable value: ".concat(value));
          }
          var length = 1;
          for (length = 1; length <= 8; length += 1) {
            if (value < Math.pow(2, 7 * length) - 1) {
              break;
            }
          }
          var buffer2 = tools_1.Buffer.alloc(length);
          var val = value;
          for (var i = 1; i <= length; i += 1) {
            var b = val & 255;
            buffer2[length - i] = b;
            val -= b;
            val /= Math.pow(2, 8);
          }
          buffer2[0] |= 1 << 8 - length;
          return buffer2;
        };
        Tools2.concatenate = function(a1, a2) {
          if (!a1 && !a2) {
            return tools_1.Buffer.from([]);
          }
          if (!a1 || a1.byteLength === 0) {
            return a2;
          }
          if (!a2 || a2.byteLength === 0) {
            return a1;
          }
          return tools_1.Buffer.from(__spreadArray(__spreadArray([], a1, true), a2, true));
        };
        Tools2.readHexString = function(buff, start, end) {
          if (start === void 0) {
            start = 0;
          }
          if (end === void 0) {
            end = buff.byteLength;
          }
          return Array.from(buff.slice(start, end)).map(function(q) {
            return Number(q).toString(16);
          }).reduce(function(acc, current) {
            return "".concat(acc).concat(current.padStart(2, "0"));
          }, "");
        };
        Tools2.readUtf8 = function(buff) {
          try {
            return tools_1.Buffer.from(buff).toString("utf8");
          } catch (exception) {
            return null;
          }
        };
        Tools2.readUnsigned = function(buff) {
          var b = new DataView(buff.buffer, buff.byteOffset, buff.byteLength);
          switch (buff.byteLength) {
            case 1:
              return b.getUint8(0);
            case 2:
              return b.getUint16(0);
            case 4:
              return b.getUint32(0);
          }
          if (buff.byteLength <= 6) {
            return buff.reduce(function(acc, current) {
              return acc * 256 + current;
            }, 0);
          }
          return Tools2.readHexString(buff, 0, buff.byteLength);
        };
        Tools2.readSigned = function(buff) {
          var b = new DataView(buff.buffer, buff.byteOffset, buff.byteLength);
          switch (buff.byteLength) {
            case 1:
              return b.getInt8(0);
            case 2:
              return b.getInt16(0);
            case 4:
              return b.getInt32(0);
            default:
              return NaN;
          }
        };
        Tools2.readFloat = function(buff) {
          var b = new DataView(buff.buffer, buff.byteOffset, buff.byteLength);
          switch (buff.byteLength) {
            case 4:
              return b.getFloat32(0);
            case 8:
              return b.getFloat64(0);
            default:
              return NaN;
          }
        };
        Tools2.readDate = function(buff) {
          var b = new DataView(buff.buffer, buff.byteOffset, buff.byteLength);
          switch (buff.byteLength) {
            case 1:
              return new Date(b.getUint8(0));
            case 2:
              return new Date(b.getUint16(0));
            case 4:
              return new Date(b.getUint32(0));
            case 8:
              return new Date(Number.parseInt(Tools2.readHexString(buff), 16));
            default:
              return /* @__PURE__ */ new Date(0);
          }
        };
        Tools2.readDataFromTag = function(tagObj, data) {
          var type = tagObj.type, name = tagObj.name;
          var track = tagObj.track;
          var discardable = tagObj.discardable || false;
          var keyframe = tagObj.keyframe || false;
          var payload = null;
          var value;
          switch (type) {
            case "u":
              value = Tools2.readUnsigned(data);
              break;
            case "f":
              value = Tools2.readFloat(data);
              break;
            case "i":
              value = Tools2.readSigned(data);
              break;
            case "s":
              value = String.fromCharCode.apply(String, data);
              break;
            case "8":
              value = Tools2.readUtf8(data);
              break;
            case "d":
              value = Tools2.readDate(data);
              break;
          }
          if (name === "SimpleBlock" || name === "Block") {
            var p = 0;
            var _a = Tools2.readVint(data, p), length_1 = _a.length, trak = _a.value;
            p += length_1;
            track = trak;
            value = Tools2.readSigned(data.subarray(p, p + 2));
            p += 2;
            if (name === "SimpleBlock") {
              keyframe = Boolean(data[length_1 + 2] & 128);
              discardable = Boolean(data[length_1 + 2] & 1);
            }
            p += 1;
            payload = data.subarray(p);
          }
          return __assign(__assign({}, tagObj), { data, discardable, keyframe, payload, track, value });
        };
        return Tools2;
      })()
    );
    toolsEbml.default = Tools;
    return toolsEbml;
  }
  var vint;
  var hasRequiredVint;
  function requireVint() {
    if (hasRequiredVint) return vint;
    hasRequiredVint = 1;
    vint = function(buffer2, start, signed) {
      start = start || 0;
      for (var length = 1; length <= 8; length++) {
        if (buffer2[start] >= Math.pow(2, 8 - length)) {
          break;
        }
      }
      if (length > 8) {
        throw new Error("Unrepresentable length: " + length + " " + buffer2.toString("hex", start, start + length));
      }
      if (start + length > buffer2.length) {
        return null;
      }
      var i;
      var value = buffer2[start] & (1 << 8 - length) - 1;
      for (i = 1; i < length; i++) {
        if (i === 7) {
          if (value >= Math.pow(2, 53 - 8) && buffer2[start + 7] > 0) {
            return {
              length,
              value: -1
            };
          }
        }
        value *= Math.pow(2, 8);
        value += buffer2[start + i];
      }
      if (signed) {
        value -= Math.pow(2, length * 7 - 1) - 1;
      }
      return {
        length,
        value
      };
    };
    return vint;
  }
  var bufferReader;
  var hasRequiredBufferReader;
  function requireBufferReader() {
    if (hasRequiredBufferReader) return bufferReader;
    hasRequiredBufferReader = 1;
    var vint2 = requireVint();
    function BufferReader(buffer2) {
      this.buffer = buffer2;
      this.offset = 0;
    }
    BufferReader.prototype.nextInt16BE = function() {
      var value = this.buffer.readInt16BE(this.offset);
      this.offset += 2;
      return value;
    };
    BufferReader.prototype.nextUInt8 = function() {
      var value = this.buffer.readUInt8(this.offset);
      this.offset += 1;
      return value;
    };
    BufferReader.prototype.nextUIntV = function() {
      var v = vint2(this.buffer, this.offset);
      this.offset += v.length;
      return v.value;
    };
    BufferReader.prototype.nextIntV = function() {
      var v = vint2(this.buffer, this.offset, true);
      this.offset += v.length;
      return v.value;
    };
    BufferReader.prototype.nextBuffer = function(length) {
      var buffer2 = length ? this.buffer.slice(this.offset, this.offset + length) : this.buffer.slice(this.offset);
      this.offset += length || this.length;
      return buffer2;
    };
    Object.defineProperty(BufferReader.prototype, "length", {
      get: function() {
        return this.buffer.length - this.offset;
      }
    });
    bufferReader = BufferReader;
    return bufferReader;
  }
  var ebmlBlock;
  var hasRequiredEbmlBlock;
  function requireEbmlBlock() {
    if (hasRequiredEbmlBlock) return ebmlBlock;
    hasRequiredEbmlBlock = 1;
    var BufferReader = requireBufferReader();
    var XIPH_LACING = 1;
    var EBML_LACING = 3;
    var FIXED_SIZE_LACING = 2;
    ebmlBlock = function(buffer2) {
      var block = {};
      var reader = new BufferReader(buffer2);
      block.trackNumber = reader.nextUIntV();
      block.timecode = reader.nextInt16BE();
      var flags = reader.nextUInt8();
      block.invisible = !!(flags & 8);
      block.keyframe = !!(flags & 128);
      block.discardable = !!(flags & 1);
      var lacing = (flags & 6) >> 1;
      block.frames = readLacedData(reader, lacing);
      return block;
    };
    function readLacedData(reader, lacing) {
      if (!lacing) return [reader.nextBuffer()];
      var i, frameSize;
      var frames = [];
      var framesNum = reader.nextUInt8() + 1;
      if (lacing === FIXED_SIZE_LACING) {
        if (reader.length % framesNum !== 0) throw new Error("Fixed-Size Lacing Error");
        frameSize = reader.length / framesNum;
        for (i = 0; i < framesNum; i++) {
          frames.push(reader.nextBuffer(frameSize));
        }
        return frames;
      }
      var frameSizes = [];
      if (lacing === XIPH_LACING) {
        for (i = 0; i < framesNum - 1; i++) {
          var val;
          frameSize = 0;
          do {
            val = reader.nextUInt8();
            frameSize += val;
          } while (val === 255);
          frameSizes.push(frameSize);
        }
      } else if (lacing === EBML_LACING) {
        frameSize = reader.nextUIntV();
        frameSizes.push(frameSize);
        for (i = 1; i < framesNum - 1; i++) {
          frameSize += reader.nextIntV();
          frameSizes.push(frameSize);
        }
      }
      for (i = 0; i < framesNum - 1; i++) {
        frames.push(reader.nextBuffer(frameSizes[i]));
      }
      frames.push(reader.nextBuffer());
      return frames;
    }
    return ebmlBlock;
  }
  var hasRequiredTools;
  function requireTools() {
    if (hasRequiredTools) return tools;
    hasRequiredTools = 1;
    (function(exports) {
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.convertEBMLDateToJSDate = exports.createFloatBuffer = exports.createIntBuffer = exports.createUIntBuffer = exports.encodeValueToBuffer = exports.concat = exports.putRefinedMetaData = exports.extractElement = exports.removeElement = exports.makeMetadataSeekable = exports.createRIFFChunk = exports.VP8BitStreamToRiffWebPBuffer = exports.WebPBlockFilter = exports.encodeTag = exports.readBlock = exports.ebmlBlock = exports.writeVint = exports.readVint = exports.Buffer = void 0;
      var int64_buffer_1 = requireInt64Buffer();
      var EBMLEncoder_1 = requireEBMLEncoder();
      var _Buffer = requireBuffer();
      var tools_ebml_1 = requireToolsEbml();
      var _block = requireEbmlBlock();
      exports.Buffer = _Buffer.Buffer;
      exports.readVint = tools_ebml_1.default.readVint;
      exports.writeVint = tools_ebml_1.default.writeVint;
      exports.ebmlBlock = _block;
      function readBlock(buf) {
        return (0, exports.ebmlBlock)(new exports.Buffer(buf));
      }
      exports.readBlock = readBlock;
      function encodeTag(tagId, tagData, unknownSize) {
        if (unknownSize === void 0) {
          unknownSize = false;
        }
        return concat([
          tagId,
          unknownSize ? new exports.Buffer("01ffffffffffffff", "hex") : (0, exports.writeVint)(tagData.length),
          tagData
        ]);
      }
      exports.encodeTag = encodeTag;
      function WebPBlockFilter(elms) {
        return elms.reduce(function(lst, elm) {
          if (elm.type !== "b") {
            return lst;
          }
          if (elm.name !== "SimpleBlock") {
            return lst;
          }
          var o = (0, exports.ebmlBlock)(elm.data);
          var hasWebP = o.frames.some(function(frame) {
            var startcode = frame.slice(3, 6).toString("hex");
            return startcode === "9d012a";
          });
          if (!hasWebP) {
            return lst;
          }
          return lst.concat(elm);
        }, []);
      }
      exports.WebPBlockFilter = WebPBlockFilter;
      function VP8BitStreamToRiffWebPBuffer(frame) {
        var VP8Chunk = createRIFFChunk("VP8 ", frame);
        var WebPChunk = concat([
          new exports.Buffer("WEBP", "ascii"),
          VP8Chunk
        ]);
        return createRIFFChunk("RIFF", WebPChunk);
      }
      exports.VP8BitStreamToRiffWebPBuffer = VP8BitStreamToRiffWebPBuffer;
      function createRIFFChunk(FourCC, chunk) {
        var chunkSize = new exports.Buffer(4);
        chunkSize.writeUInt32LE(chunk.byteLength, 0);
        return concat([
          new exports.Buffer(FourCC.substr(0, 4), "ascii"),
          chunkSize,
          chunk,
          new exports.Buffer(chunk.byteLength % 2 === 0 ? 0 : 1)
          // padding
        ]);
      }
      exports.createRIFFChunk = createRIFFChunk;
      function makeMetadataSeekable(originalMetadata, duration, cuesInfo) {
        var header = extractElement("EBML", originalMetadata);
        var headerSize = encodedSizeOfEbml(header);
        var segmentContentStartPos = headerSize + 12;
        var originalMetadataSize = originalMetadata[originalMetadata.length - 1].dataEnd - segmentContentStartPos;
        var info = extractElement("Info", originalMetadata);
        removeElement("Duration", info);
        info.splice(1, 0, { name: "Duration", type: "f", data: createFloatBuffer(duration, 8) });
        var infoSize = encodedSizeOfEbml(info);
        var tracks = extractElement("Tracks", originalMetadata);
        var tracksSize = encodedSizeOfEbml(tracks);
        var seekHeadSize = 47;
        var seekHead = [];
        var cuesSize = 5 + cuesInfo.length * 15;
        var cues = [];
        var lastSizeDifference = -1;
        var maxIterations = 10;
        var _loop_1 = function(i2) {
          var infoStart = seekHeadSize;
          var tracksStart = infoStart + infoSize;
          var cuesStart = tracksStart + tracksSize;
          var newMetadataSize = cuesStart + cuesSize;
          var sizeDifference = newMetadataSize - originalMetadataSize;
          seekHead = [];
          seekHead.push({ name: "SeekHead", type: "m", isEnd: false });
          seekHead.push({ name: "Seek", type: "m", isEnd: false });
          seekHead.push({ name: "SeekID", type: "b", data: new exports.Buffer([21, 73, 169, 102]) });
          seekHead.push({ name: "SeekPosition", type: "u", data: createUIntBuffer(infoStart) });
          seekHead.push({ name: "Seek", type: "m", isEnd: true });
          seekHead.push({ name: "Seek", type: "m", isEnd: false });
          seekHead.push({ name: "SeekID", type: "b", data: new exports.Buffer([22, 84, 174, 107]) });
          seekHead.push({ name: "SeekPosition", type: "u", data: createUIntBuffer(tracksStart) });
          seekHead.push({ name: "Seek", type: "m", isEnd: true });
          seekHead.push({ name: "Seek", type: "m", isEnd: false });
          seekHead.push({ name: "SeekID", type: "b", data: new exports.Buffer([28, 83, 187, 107]) });
          seekHead.push({ name: "SeekPosition", type: "u", data: createUIntBuffer(cuesStart) });
          seekHead.push({ name: "Seek", type: "m", isEnd: true });
          seekHead.push({ name: "SeekHead", type: "m", isEnd: true });
          seekHeadSize = encodedSizeOfEbml(seekHead);
          cues = [];
          cues.push({ name: "Cues", type: "m", isEnd: false });
          cuesInfo.forEach(function(_a) {
            var CueTrack = _a.CueTrack, CueClusterPosition = _a.CueClusterPosition, CueTime = _a.CueTime;
            cues.push({ name: "CuePoint", type: "m", isEnd: false });
            cues.push({ name: "CueTime", type: "u", data: createUIntBuffer(CueTime) });
            cues.push({ name: "CueTrackPositions", type: "m", isEnd: false });
            cues.push({ name: "CueTrack", type: "u", data: createUIntBuffer(CueTrack) });
            CueClusterPosition -= segmentContentStartPos;
            CueClusterPosition += sizeDifference;
            cues.push({ name: "CueClusterPosition", type: "u", data: createUIntBuffer(CueClusterPosition) });
            cues.push({ name: "CueTrackPositions", type: "m", isEnd: true });
            cues.push({ name: "CuePoint", type: "m", isEnd: true });
          });
          cues.push({ name: "Cues", type: "m", isEnd: true });
          cuesSize = encodedSizeOfEbml(cues);
          if (lastSizeDifference !== sizeDifference) {
            lastSizeDifference = sizeDifference;
            if (i2 === maxIterations - 1) {
              throw new Error("Failed to converge to a stable metadata size");
            }
          } else {
            return "break";
          }
        };
        for (var i = 0; i < maxIterations; i++) {
          var state_1 = _loop_1(i);
          if (state_1 === "break")
            break;
        }
        var finalMetadata = [].concat.apply([], [
          header,
          { name: "Segment", type: "m", isEnd: false, unknownSize: true },
          seekHead,
          info,
          tracks,
          cues
        ]);
        var result = new EBMLEncoder_1.default().encode(finalMetadata);
        return result;
      }
      exports.makeMetadataSeekable = makeMetadataSeekable;
      function removeElement(idName, metadata) {
        var start = -1;
        for (var i = 0; i < metadata.length; i++) {
          var element = metadata[i];
          if (element.name === idName) {
            if (element.type === "m") {
              if (!element.isEnd) {
                start = i;
              } else {
                if (start == -1)
                  throw new Error("Detected ".concat(idName, " closing element before finding the start"));
                metadata.splice(start, i - start + 1);
                return;
              }
            } else {
              metadata.splice(i, 1);
              return;
            }
          }
        }
      }
      exports.removeElement = removeElement;
      function extractElement(idName, metadata) {
        var result = [];
        var start = -1;
        for (var i = 0; i < metadata.length; i++) {
          var element = metadata[i];
          if (element.name === idName) {
            if (element.type === "m") {
              if (!element.isEnd) {
                start = i;
              } else {
                if (start == -1)
                  throw new Error("Detected ".concat(idName, " closing element before finding the start"));
                result = metadata.slice(start, i + 1);
                break;
              }
            } else {
              result.push(metadata[i]);
              break;
            }
          }
        }
        return result;
      }
      exports.extractElement = extractElement;
      function putRefinedMetaData(metadata, info) {
        if (Array.isArray(info.cueInfos) && !Array.isArray(info.cues)) {
          console.warn("putRefinedMetaData: info.cueInfos property is deprecated. please use info.cues");
          info.cues = info.cueInfos;
        }
        var ebml2 = [];
        var payload = [];
        for (var i_1 = 0; i_1 < metadata.length; i_1++) {
          var elm = metadata[i_1];
          if (elm.type === "m" && elm.name === "Segment") {
            ebml2 = metadata.slice(0, i_1);
            payload = metadata.slice(i_1);
            if (elm.unknownSize) {
              payload.shift();
              break;
            }
            throw new Error("this metadata is not streaming webm file");
          }
        }
        if (!(payload[payload.length - 1].dataEnd > 0)) {
          throw new Error("metadata dataEnd has wrong number");
        }
        var originalPayloadOffsetEnd = payload[payload.length - 1].dataEnd;
        var ebmlSize = ebml2[ebml2.length - 1].dataEnd;
        var refinedEBMLSize = new EBMLEncoder_1.default().encode(ebml2).byteLength;
        var offsetDiff = refinedEBMLSize - ebmlSize;
        var payloadSize = originalPayloadOffsetEnd - payload[0].tagStart;
        payload[0].tagStart - ebmlSize;
        payload[0].tagStart;
        var segmentTagBuf = new exports.Buffer([24, 83, 128, 103]);
        var segmentSizeBuf = new exports.Buffer("01ffffffffffffff", "hex");
        var _segmentSize = segmentTagBuf.byteLength + segmentSizeBuf.byteLength;
        var newPayloadSize = payloadSize;
        var i;
        for (i = 1; i < 20; i++) {
          var newPayloadOffsetEnd = ebmlSize + _segmentSize + newPayloadSize;
          var offsetEndDiff = newPayloadOffsetEnd - originalPayloadOffsetEnd;
          var sizeDiff = offsetDiff + offsetEndDiff;
          var refined = refineMetadata(payload, sizeDiff, info);
          var newNewRefinedSize = new EBMLEncoder_1.default().encode(refined).byteLength;
          if (newNewRefinedSize === newPayloadSize) {
            return new EBMLEncoder_1.default().encode([].concat(ebml2, [{ type: "m", name: "Segment", isEnd: false, unknownSize: true }], refined));
          }
          newPayloadSize = newNewRefinedSize;
        }
        throw new Error("unable to refine metadata, stable size could not be found in " + i + " iterations!");
      }
      exports.putRefinedMetaData = putRefinedMetaData;
      function encodedSizeOfEbml(refinedMetaData) {
        var encorder = new EBMLEncoder_1.default();
        return refinedMetaData.reduce(function(lst, elm) {
          return lst.concat(encorder.encode([elm]));
        }, []).reduce(function(o, buf) {
          return o + buf.byteLength;
        }, 0);
      }
      function refineMetadata(mesetadata, sizeDiff, info) {
        var duration = info.duration, clusterPtrs = info.clusterPtrs, cues = info.cues;
        var _metadata = mesetadata.slice(0);
        if (typeof duration === "number") {
          var overwrited_1 = false;
          _metadata.forEach(function(elm) {
            if (elm.type === "f" && elm.name === "Duration") {
              overwrited_1 = true;
              elm.data = createFloatBuffer(duration, 8);
            }
          });
          if (!overwrited_1) {
            insertTag(_metadata, "Info", [{ name: "Duration", type: "f", data: createFloatBuffer(duration, 8) }]);
          }
        }
        if (Array.isArray(cues)) {
          insertTag(_metadata, "Cues", create_cue(cues, sizeDiff));
        }
        var seekhead_children = [];
        if (Array.isArray(clusterPtrs)) {
          console.warn("append cluster pointers to seekhead is deprecated. please use cues");
          seekhead_children = create_seek_from_clusters(clusterPtrs, sizeDiff);
        }
        insertTag(_metadata, "SeekHead", seekhead_children, true);
        return _metadata;
      }
      function create_seek_from_clusters(clusterPtrs, sizeDiff) {
        var seeks = [];
        clusterPtrs.forEach(function(start) {
          seeks.push({ name: "Seek", type: "m", isEnd: false });
          seeks.push({ name: "SeekID", type: "b", data: new exports.Buffer([31, 67, 182, 117]) });
          seeks.push({ name: "SeekPosition", type: "u", data: createUIntBuffer(start + sizeDiff) });
          seeks.push({ name: "Seek", type: "m", isEnd: true });
        });
        return seeks;
      }
      function create_cue(cueInfos, sizeDiff) {
        var cues = [];
        cueInfos.forEach(function(_a) {
          var CueTrack = _a.CueTrack, CueClusterPosition = _a.CueClusterPosition, CueTime = _a.CueTime;
          cues.push({ name: "CuePoint", type: "m", isEnd: false });
          cues.push({ name: "CueTime", type: "u", data: createUIntBuffer(CueTime) });
          cues.push({ name: "CueTrackPositions", type: "m", isEnd: false });
          cues.push({ name: "CueTrack", type: "u", data: createUIntBuffer(CueTrack) });
          cues.push({ name: "CueClusterPosition", type: "u", data: createUIntBuffer(CueClusterPosition + sizeDiff) });
          cues.push({ name: "CueTrackPositions", type: "m", isEnd: true });
          cues.push({ name: "CuePoint", type: "m", isEnd: true });
        });
        return cues;
      }
      function insertTag(_metadata, tagName, children, insertHead) {
        if (insertHead === void 0) {
          insertHead = false;
        }
        var idx = -1;
        for (var i = 0; i < _metadata.length; i++) {
          var elm = _metadata[i];
          if (elm.type === "m" && elm.name === tagName && elm.isEnd === false) {
            idx = i;
            break;
          }
        }
        if (idx >= 0) {
          Array.prototype.splice.apply(_metadata, [idx + 1, 0].concat(children));
        } else if (insertHead) {
          [].concat([{ name: tagName, type: "m", isEnd: false }], children, [{ name: tagName, type: "m", isEnd: true }]).reverse().forEach(function(elm2) {
            _metadata.unshift(elm2);
          });
        } else {
          _metadata.push({ name: tagName, type: "m", isEnd: false });
          children.forEach(function(elm2) {
            _metadata.push(elm2);
          });
          _metadata.push({ name: tagName, type: "m", isEnd: true });
        }
      }
      function concat(list) {
        return exports.Buffer.concat(list);
      }
      exports.concat = concat;
      function encodeValueToBuffer(elm) {
        var data = new exports.Buffer(0);
        if (elm.type === "m") {
          return elm;
        }
        switch (elm.type) {
          case "u":
            data = createUIntBuffer(elm.value);
            break;
          case "i":
            data = createIntBuffer(elm.value);
            break;
          case "f":
            data = createFloatBuffer(elm.value);
            break;
          case "s":
            data = new exports.Buffer(elm.value, "ascii");
            break;
          case "8":
            data = new exports.Buffer(elm.value, "utf8");
            break;
          case "b":
            data = elm.value;
            break;
          case "d":
            data = new int64_buffer_1.Int64BE(elm.value.getTime().toString()).toBuffer();
            break;
        }
        return Object.assign({}, elm, { data });
      }
      exports.encodeValueToBuffer = encodeValueToBuffer;
      function createUIntBuffer(value) {
        var bytes = 1;
        for (; value >= Math.pow(2, 8 * bytes); bytes++) {
        }
        if (bytes >= 7) {
          console.warn("7bit or more bigger uint not supported.");
          return new int64_buffer_1.Uint64BE(value).toBuffer();
        }
        var data = new exports.Buffer(bytes);
        data.writeUIntBE(value, 0, bytes);
        return data;
      }
      exports.createUIntBuffer = createUIntBuffer;
      function createIntBuffer(value) {
        var bytes = 1;
        for (; value >= Math.pow(2, 8 * bytes); bytes++) {
        }
        if (bytes >= 7) {
          console.warn("7bit or more bigger uint not supported.");
          return new int64_buffer_1.Int64BE(value).toBuffer();
        }
        var data = new exports.Buffer(bytes);
        data.writeIntBE(value, 0, bytes);
        return data;
      }
      exports.createIntBuffer = createIntBuffer;
      function createFloatBuffer(value, bytes) {
        if (bytes === void 0) {
          bytes = 8;
        }
        if (bytes === 8) {
          var data = new exports.Buffer(8);
          data.writeDoubleBE(value, 0);
          return data;
        } else if (bytes === 4) {
          var data = new exports.Buffer(4);
          data.writeFloatBE(value, 0);
          return data;
        } else {
          throw new Error("float type bits must 4bytes or 8bytes");
        }
      }
      exports.createFloatBuffer = createFloatBuffer;
      function convertEBMLDateToJSDate(int64str) {
        if (int64str instanceof Date) {
          return int64str;
        }
        return new Date((/* @__PURE__ */ new Date("2001-01-01T00:00:00.000Z")).getTime() + Number(int64str) / 1e3 / 1e3);
      }
      exports.convertEBMLDateToJSDate = convertEBMLDateToJSDate;
    })(tools);
    return tools;
  }
  var hasRequiredEBMLDecoder;
  function requireEBMLDecoder() {
    if (hasRequiredEBMLDecoder) return EBMLDecoder;
    hasRequiredEBMLDecoder = 1;
    Object.defineProperty(EBMLDecoder, "__esModule", { value: true });
    var int64_buffer_1 = requireInt64Buffer();
    var tools_1 = requireTools();
    var tools2 = requireTools();
    var ebmlID_1 = requireEbmlID();
    var State;
    (function(State2) {
      State2[State2["STATE_TAG"] = 1] = "STATE_TAG";
      State2[State2["STATE_SIZE"] = 2] = "STATE_SIZE";
      State2[State2["STATE_CONTENT"] = 3] = "STATE_CONTENT";
    })(State || (State = {}));
    var EBMLDecoder$1 = (
      /** @class */
      (function() {
        function EBMLDecoder2() {
          this._buffer = new tools_1.Buffer(0);
          this._tag_stack = [];
          this._state = State.STATE_TAG;
          this._cursor = 0;
          this._total = 0;
          this._schema = ebmlID_1.byEbmlID;
          this._result = [];
        }
        EBMLDecoder2.prototype.decode = function(chunk) {
          this.readChunk(chunk);
          var diff = this._result;
          this._result = [];
          return diff;
        };
        EBMLDecoder2.prototype.readChunk = function(chunk) {
          this._buffer = tools2.concat([this._buffer, new tools_1.Buffer(chunk)]);
          while (this._cursor < this._buffer.length) {
            if (this._state === State.STATE_TAG && !this.readTag()) {
              break;
            }
            if (this._state === State.STATE_SIZE && !this.readSize()) {
              break;
            }
            if (this._state === State.STATE_CONTENT && !this.readContent()) {
              break;
            }
          }
        };
        EBMLDecoder2.prototype.getSchemaInfo = function(tagNum) {
          return this._schema[tagNum] || {
            name: "unknown",
            level: -1,
            type: "unknown",
            description: "unknown"
          };
        };
        EBMLDecoder2.prototype.readTag = function() {
          if (this._cursor >= this._buffer.length) {
            return false;
          }
          var tag = (0, tools_1.readVint)(this._buffer, this._cursor);
          if (tag == null) {
            return false;
          }
          var buf = this._buffer.slice(this._cursor, this._cursor + tag.length);
          var tagNum = buf.reduce(function(o, v, i, arr) {
            return o + v * Math.pow(16, 2 * (arr.length - 1 - i));
          }, 0);
          var schema = this.getSchemaInfo(tagNum);
          var tagObj = {
            EBML_ID: tagNum.toString(16),
            schema,
            type: schema.type,
            name: schema.name,
            level: schema.level,
            tagStart: this._total,
            tagEnd: this._total + tag.length,
            sizeStart: this._total + tag.length,
            sizeEnd: null,
            dataStart: null,
            dataEnd: null,
            dataSize: null,
            data: null
          };
          this._tag_stack.push(tagObj);
          this._cursor += tag.length;
          this._total += tag.length;
          this._state = State.STATE_SIZE;
          return true;
        };
        EBMLDecoder2.prototype.readSize = function() {
          if (this._cursor >= this._buffer.length) {
            return false;
          }
          var size = (0, tools_1.readVint)(this._buffer, this._cursor);
          if (size == null) {
            return false;
          }
          var tagObj = this._tag_stack[this._tag_stack.length - 1];
          tagObj.sizeEnd = tagObj.sizeStart + size.length;
          tagObj.dataStart = tagObj.sizeEnd;
          tagObj.dataSize = size.value;
          if (size.value === -1) {
            tagObj.dataEnd = -1;
            if (tagObj.type === "m") {
              tagObj.unknownSize = true;
            }
          } else {
            tagObj.dataEnd = tagObj.sizeEnd + size.value;
          }
          this._cursor += size.length;
          this._total += size.length;
          this._state = State.STATE_CONTENT;
          return true;
        };
        EBMLDecoder2.prototype.readContent = function() {
          var tagObj = this._tag_stack[this._tag_stack.length - 1];
          if (tagObj.type === "m") {
            tagObj.isEnd = false;
            this._result.push(tagObj);
            this._state = State.STATE_TAG;
            if (tagObj.dataSize === 0) {
              var elm = Object.assign({}, tagObj, { isEnd: true });
              this._result.push(elm);
              this._tag_stack.pop();
            }
            return true;
          }
          if (this._buffer.length < this._cursor + tagObj.dataSize) {
            return false;
          }
          var data = this._buffer.slice(this._cursor, this._cursor + tagObj.dataSize);
          this._buffer = this._buffer.slice(this._cursor + tagObj.dataSize);
          tagObj.data = data;
          switch (tagObj.type) {
            //case "m": break;
            // Master-Element - contains other EBML sub-elements of the next lower level
            case "u":
              tagObj.value = data.readUIntBE(0, data.length);
              break;
            // Unsigned Integer - Big-endian, any size from 1 to 8 octets
            case "i":
              tagObj.value = data.readIntBE(0, data.length);
              break;
            // Signed Integer - Big-endian, any size from 1 to 8 octets
            case "f":
              tagObj.value = tagObj.dataSize === 4 ? data.readFloatBE(0) : tagObj.dataSize === 8 ? data.readDoubleBE(0) : (console.warn("cannot read ".concat(tagObj.dataSize, " octets float. failback to 0")), 0);
              break;
            // Float - Big-endian, defined for 4 and 8 octets (32, 64 bits)
            case "s":
              tagObj.value = data.toString("ascii");
              break;
            // ascii
            //  Printable ASCII (0x20 to 0x7E), zero-padded when needed
            case "8":
              tagObj.value = data.toString("utf8");
              break;
            //  Unicode string, zero padded when needed (RFC 2279)
            case "b":
              tagObj.value = data;
              break;
            // Binary - not interpreted by the parser
            case "d":
              tagObj.value = (0, tools_1.convertEBMLDateToJSDate)(new int64_buffer_1.Int64BE(data).toNumber());
              break;
          }
          if (tagObj.value === null) {
            throw new Error("unknown tag type:" + tagObj.type);
          }
          this._result.push(tagObj);
          this._total += tagObj.dataSize;
          this._state = State.STATE_TAG;
          this._cursor = 0;
          this._tag_stack.pop();
          while (this._tag_stack.length > 0) {
            var topEle = this._tag_stack[this._tag_stack.length - 1];
            if (topEle.dataEnd < 0) {
              this._tag_stack.pop();
              return true;
            }
            if (this._total < topEle.dataEnd) {
              break;
            }
            if (topEle.type !== "m") {
              throw new Error("parent element is not master element");
            }
            var elm = Object.assign({}, topEle, { isEnd: true });
            this._result.push(elm);
            this._tag_stack.pop();
          }
          return true;
        };
        return EBMLDecoder2;
      })()
    );
    EBMLDecoder.default = EBMLDecoder$1;
    return EBMLDecoder;
  }
  var EBMLReader = {};
  var events = { exports: {} };
  var hasRequiredEvents;
  function requireEvents() {
    if (hasRequiredEvents) return events.exports;
    hasRequiredEvents = 1;
    var R = typeof Reflect === "object" ? Reflect : null;
    var ReflectApply = R && typeof R.apply === "function" ? R.apply : function ReflectApply2(target, receiver, args) {
      return Function.prototype.apply.call(target, receiver, args);
    };
    var ReflectOwnKeys;
    if (R && typeof R.ownKeys === "function") {
      ReflectOwnKeys = R.ownKeys;
    } else if (Object.getOwnPropertySymbols) {
      ReflectOwnKeys = function ReflectOwnKeys2(target) {
        return Object.getOwnPropertyNames(target).concat(Object.getOwnPropertySymbols(target));
      };
    } else {
      ReflectOwnKeys = function ReflectOwnKeys2(target) {
        return Object.getOwnPropertyNames(target);
      };
    }
    function ProcessEmitWarning(warning) {
      if (console && console.warn) console.warn(warning);
    }
    var NumberIsNaN = Number.isNaN || function NumberIsNaN2(value) {
      return value !== value;
    };
    function EventEmitter() {
      EventEmitter.init.call(this);
    }
    events.exports = EventEmitter;
    events.exports.once = once;
    EventEmitter.EventEmitter = EventEmitter;
    EventEmitter.prototype._events = void 0;
    EventEmitter.prototype._eventsCount = 0;
    EventEmitter.prototype._maxListeners = void 0;
    var defaultMaxListeners = 10;
    function checkListener(listener) {
      if (typeof listener !== "function") {
        throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof listener);
      }
    }
    Object.defineProperty(EventEmitter, "defaultMaxListeners", {
      enumerable: true,
      get: function() {
        return defaultMaxListeners;
      },
      set: function(arg) {
        if (typeof arg !== "number" || arg < 0 || NumberIsNaN(arg)) {
          throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + arg + ".");
        }
        defaultMaxListeners = arg;
      }
    });
    EventEmitter.init = function() {
      if (this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) {
        this._events = /* @__PURE__ */ Object.create(null);
        this._eventsCount = 0;
      }
      this._maxListeners = this._maxListeners || void 0;
    };
    EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
      if (typeof n !== "number" || n < 0 || NumberIsNaN(n)) {
        throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + n + ".");
      }
      this._maxListeners = n;
      return this;
    };
    function _getMaxListeners(that) {
      if (that._maxListeners === void 0)
        return EventEmitter.defaultMaxListeners;
      return that._maxListeners;
    }
    EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
      return _getMaxListeners(this);
    };
    EventEmitter.prototype.emit = function emit(type) {
      var args = [];
      for (var i = 1; i < arguments.length; i++) args.push(arguments[i]);
      var doError = type === "error";
      var events2 = this._events;
      if (events2 !== void 0)
        doError = doError && events2.error === void 0;
      else if (!doError)
        return false;
      if (doError) {
        var er;
        if (args.length > 0)
          er = args[0];
        if (er instanceof Error) {
          throw er;
        }
        var err = new Error("Unhandled error." + (er ? " (" + er.message + ")" : ""));
        err.context = er;
        throw err;
      }
      var handler = events2[type];
      if (handler === void 0)
        return false;
      if (typeof handler === "function") {
        ReflectApply(handler, this, args);
      } else {
        var len = handler.length;
        var listeners = arrayClone(handler, len);
        for (var i = 0; i < len; ++i)
          ReflectApply(listeners[i], this, args);
      }
      return true;
    };
    function _addListener(target, type, listener, prepend) {
      var m;
      var events2;
      var existing;
      checkListener(listener);
      events2 = target._events;
      if (events2 === void 0) {
        events2 = target._events = /* @__PURE__ */ Object.create(null);
        target._eventsCount = 0;
      } else {
        if (events2.newListener !== void 0) {
          target.emit(
            "newListener",
            type,
            listener.listener ? listener.listener : listener
          );
          events2 = target._events;
        }
        existing = events2[type];
      }
      if (existing === void 0) {
        existing = events2[type] = listener;
        ++target._eventsCount;
      } else {
        if (typeof existing === "function") {
          existing = events2[type] = prepend ? [listener, existing] : [existing, listener];
        } else if (prepend) {
          existing.unshift(listener);
        } else {
          existing.push(listener);
        }
        m = _getMaxListeners(target);
        if (m > 0 && existing.length > m && !existing.warned) {
          existing.warned = true;
          var w = new Error("Possible EventEmitter memory leak detected. " + existing.length + " " + String(type) + " listeners added. Use emitter.setMaxListeners() to increase limit");
          w.name = "MaxListenersExceededWarning";
          w.emitter = target;
          w.type = type;
          w.count = existing.length;
          ProcessEmitWarning(w);
        }
      }
      return target;
    }
    EventEmitter.prototype.addListener = function addListener(type, listener) {
      return _addListener(this, type, listener, false);
    };
    EventEmitter.prototype.on = EventEmitter.prototype.addListener;
    EventEmitter.prototype.prependListener = function prependListener(type, listener) {
      return _addListener(this, type, listener, true);
    };
    function onceWrapper() {
      if (!this.fired) {
        this.target.removeListener(this.type, this.wrapFn);
        this.fired = true;
        if (arguments.length === 0)
          return this.listener.call(this.target);
        return this.listener.apply(this.target, arguments);
      }
    }
    function _onceWrap(target, type, listener) {
      var state = { fired: false, wrapFn: void 0, target, type, listener };
      var wrapped = onceWrapper.bind(state);
      wrapped.listener = listener;
      state.wrapFn = wrapped;
      return wrapped;
    }
    EventEmitter.prototype.once = function once2(type, listener) {
      checkListener(listener);
      this.on(type, _onceWrap(this, type, listener));
      return this;
    };
    EventEmitter.prototype.prependOnceListener = function prependOnceListener(type, listener) {
      checkListener(listener);
      this.prependListener(type, _onceWrap(this, type, listener));
      return this;
    };
    EventEmitter.prototype.removeListener = function removeListener(type, listener) {
      var list, events2, position, i, originalListener;
      checkListener(listener);
      events2 = this._events;
      if (events2 === void 0)
        return this;
      list = events2[type];
      if (list === void 0)
        return this;
      if (list === listener || list.listener === listener) {
        if (--this._eventsCount === 0)
          this._events = /* @__PURE__ */ Object.create(null);
        else {
          delete events2[type];
          if (events2.removeListener)
            this.emit("removeListener", type, list.listener || listener);
        }
      } else if (typeof list !== "function") {
        position = -1;
        for (i = list.length - 1; i >= 0; i--) {
          if (list[i] === listener || list[i].listener === listener) {
            originalListener = list[i].listener;
            position = i;
            break;
          }
        }
        if (position < 0)
          return this;
        if (position === 0)
          list.shift();
        else {
          spliceOne(list, position);
        }
        if (list.length === 1)
          events2[type] = list[0];
        if (events2.removeListener !== void 0)
          this.emit("removeListener", type, originalListener || listener);
      }
      return this;
    };
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(type) {
      var listeners, events2, i;
      events2 = this._events;
      if (events2 === void 0)
        return this;
      if (events2.removeListener === void 0) {
        if (arguments.length === 0) {
          this._events = /* @__PURE__ */ Object.create(null);
          this._eventsCount = 0;
        } else if (events2[type] !== void 0) {
          if (--this._eventsCount === 0)
            this._events = /* @__PURE__ */ Object.create(null);
          else
            delete events2[type];
        }
        return this;
      }
      if (arguments.length === 0) {
        var keys = Object.keys(events2);
        var key;
        for (i = 0; i < keys.length; ++i) {
          key = keys[i];
          if (key === "removeListener") continue;
          this.removeAllListeners(key);
        }
        this.removeAllListeners("removeListener");
        this._events = /* @__PURE__ */ Object.create(null);
        this._eventsCount = 0;
        return this;
      }
      listeners = events2[type];
      if (typeof listeners === "function") {
        this.removeListener(type, listeners);
      } else if (listeners !== void 0) {
        for (i = listeners.length - 1; i >= 0; i--) {
          this.removeListener(type, listeners[i]);
        }
      }
      return this;
    };
    function _listeners(target, type, unwrap) {
      var events2 = target._events;
      if (events2 === void 0)
        return [];
      var evlistener = events2[type];
      if (evlistener === void 0)
        return [];
      if (typeof evlistener === "function")
        return unwrap ? [evlistener.listener || evlistener] : [evlistener];
      return unwrap ? unwrapListeners(evlistener) : arrayClone(evlistener, evlistener.length);
    }
    EventEmitter.prototype.listeners = function listeners(type) {
      return _listeners(this, type, true);
    };
    EventEmitter.prototype.rawListeners = function rawListeners(type) {
      return _listeners(this, type, false);
    };
    EventEmitter.listenerCount = function(emitter, type) {
      if (typeof emitter.listenerCount === "function") {
        return emitter.listenerCount(type);
      } else {
        return listenerCount.call(emitter, type);
      }
    };
    EventEmitter.prototype.listenerCount = listenerCount;
    function listenerCount(type) {
      var events2 = this._events;
      if (events2 !== void 0) {
        var evlistener = events2[type];
        if (typeof evlistener === "function") {
          return 1;
        } else if (evlistener !== void 0) {
          return evlistener.length;
        }
      }
      return 0;
    }
    EventEmitter.prototype.eventNames = function eventNames() {
      return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
    };
    function arrayClone(arr, n) {
      var copy = new Array(n);
      for (var i = 0; i < n; ++i)
        copy[i] = arr[i];
      return copy;
    }
    function spliceOne(list, index) {
      for (; index + 1 < list.length; index++)
        list[index] = list[index + 1];
      list.pop();
    }
    function unwrapListeners(arr) {
      var ret = new Array(arr.length);
      for (var i = 0; i < ret.length; ++i) {
        ret[i] = arr[i].listener || arr[i];
      }
      return ret;
    }
    function once(emitter, name) {
      return new Promise(function(resolve, reject) {
        function errorListener(err) {
          emitter.removeListener(name, resolver);
          reject(err);
        }
        function resolver() {
          if (typeof emitter.removeListener === "function") {
            emitter.removeListener("error", errorListener);
          }
          resolve([].slice.call(arguments));
        }
        eventTargetAgnosticAddListener(emitter, name, resolver, { once: true });
        if (name !== "error") {
          addErrorHandlerIfEventEmitter(emitter, errorListener, { once: true });
        }
      });
    }
    function addErrorHandlerIfEventEmitter(emitter, handler, flags) {
      if (typeof emitter.on === "function") {
        eventTargetAgnosticAddListener(emitter, "error", handler, flags);
      }
    }
    function eventTargetAgnosticAddListener(emitter, name, listener, flags) {
      if (typeof emitter.on === "function") {
        if (flags.once) {
          emitter.once(name, listener);
        } else {
          emitter.on(name, listener);
        }
      } else if (typeof emitter.addEventListener === "function") {
        emitter.addEventListener(name, function wrapListener(arg) {
          if (flags.once) {
            emitter.removeEventListener(name, wrapListener);
          }
          listener(arg);
        });
      } else {
        throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof emitter);
      }
    }
    return events.exports;
  }
  var hasRequiredEBMLReader;
  function requireEBMLReader() {
    if (hasRequiredEBMLReader) return EBMLReader;
    hasRequiredEBMLReader = 1;
    var __extends = EBMLReader && EBMLReader.__extends || /* @__PURE__ */ (function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
          d2.__proto__ = b2;
        } || function(d2, b2) {
          for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        if (typeof b !== "function" && b !== null)
          throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    })();
    Object.defineProperty(EBMLReader, "__esModule", { value: true });
    var events_1 = requireEvents();
    var tools2 = requireTools();
    var EBMLReader$1 = (
      /** @class */
      (function(_super) {
        __extends(EBMLReader2, _super);
        function EBMLReader2() {
          var _this = _super.call(this) || this;
          _this.logGroup = "";
          _this.hasLoggingStarted = false;
          _this.metadataloaded = false;
          _this.chunks = [];
          _this.stack = [];
          _this.segmentOffset = 0;
          _this.last2SimpleBlockVideoTrackTimecode = [0, 0];
          _this.last2SimpleBlockAudioTrackTimecode = [0, 0];
          _this.lastClusterTimecode = 0;
          _this.lastClusterPosition = 0;
          _this.timecodeScale = 1e6;
          _this.metadataSize = 0;
          _this.metadatas = [];
          _this.cues = [];
          _this.firstVideoBlockRead = false;
          _this.firstAudioBlockRead = false;
          _this.currentTrack = { TrackNumber: -1, TrackType: -1, DefaultDuration: null, CodecDelay: null };
          _this.trackTypes = [];
          _this.trackDefaultDuration = [];
          _this.trackCodecDelay = [];
          _this.trackInfo = { type: "nothing" };
          _this.ended = false;
          _this.logging = false;
          _this.use_duration_every_simpleblock = false;
          _this.use_webp = false;
          _this.use_segment_info = true;
          _this.drop_default_duration = true;
          return _this;
        }
        EBMLReader2.prototype.stop = function() {
          this.ended = true;
          this.emit_segment_info();
          while (this.stack.length) {
            this.stack.pop();
            if (this.logging) {
              console.groupEnd();
            }
          }
          if (this.logging && this.hasLoggingStarted && this.logGroup) {
            console.groupEnd();
          }
        };
        EBMLReader2.prototype.emit_segment_info = function() {
          var data = this.chunks;
          this.chunks = [];
          if (!this.metadataloaded) {
            this.metadataloaded = true;
            this.metadatas = data;
            var videoTrackNum = this.trackTypes.indexOf(1);
            var audioTrackNum = this.trackTypes.indexOf(2);
            this.trackInfo = videoTrackNum >= 0 && audioTrackNum >= 0 ? { type: "both", trackNumber: videoTrackNum } : videoTrackNum >= 0 ? { type: "video", trackNumber: videoTrackNum } : audioTrackNum >= 0 ? { type: "audio", trackNumber: audioTrackNum } : { type: "nothing" };
            if (!this.use_segment_info) {
              return;
            }
            this.emit("metadata", { data, metadataSize: this.metadataSize });
          } else {
            if (!this.use_segment_info) {
              return;
            }
            var timecode = this.lastClusterTimecode;
            var duration = this.duration;
            var timecodeScale = this.timecodeScale;
            this.emit("cluster", { timecode, data });
            this.emit("duration", { timecodeScale, duration });
          }
        };
        EBMLReader2.prototype.read = function(elm) {
          var _this = this;
          var drop = false;
          if (this.ended) {
            return;
          }
          if (elm.type === "m") {
            if (elm.isEnd) {
              this.stack.pop();
            } else {
              var parent_1 = this.stack[this.stack.length - 1];
              if (parent_1 != null && parent_1.level >= elm.level) {
                this.stack.pop();
                if (this.logging) {
                  console.groupEnd();
                }
                parent_1.dataEnd = elm.dataEnd;
                parent_1.dataSize = elm.dataEnd - parent_1.dataStart;
                parent_1.unknownSize = false;
                var o = Object.assign({}, parent_1, { name: parent_1.name, type: parent_1.type, isEnd: true });
                this.chunks.push(o);
              }
              this.stack.push(elm);
            }
          }
          if (elm.type === "m" && elm.name == "Segment") {
            if (this.segmentOffset != 0) {
              console.warn("Multiple segments detected!");
            }
            this.segmentOffset = elm.dataStart;
            this.emit("segment_offset", this.segmentOffset);
          } else if (elm.type === "b" && elm.name === "SimpleBlock") {
            var _a = tools2.ebmlBlock(elm.data), timecode = _a.timecode, trackNumber = _a.trackNumber, frames_1 = _a.frames;
            if (this.trackTypes[trackNumber] === 1) {
              if (!this.firstVideoBlockRead) {
                this.firstVideoBlockRead = true;
                if (this.trackInfo.type === "both" || this.trackInfo.type === "video") {
                  var CueTime = this.lastClusterTimecode + timecode;
                  this.cues.push({ CueTrack: trackNumber, CueClusterPosition: this.lastClusterPosition, CueTime });
                  this.emit("cue_info", { CueTrack: trackNumber, CueClusterPosition: this.lastClusterPosition, CueTime: this.lastClusterTimecode });
                  this.emit("cue", { CueTrack: trackNumber, CueClusterPosition: this.lastClusterPosition, CueTime });
                }
              }
              this.last2SimpleBlockVideoTrackTimecode = [this.last2SimpleBlockVideoTrackTimecode[1], timecode];
            } else if (this.trackTypes[trackNumber] === 2) {
              if (!this.firstAudioBlockRead) {
                this.firstAudioBlockRead = true;
                if (this.trackInfo.type === "audio") {
                  var CueTime = this.lastClusterTimecode + timecode;
                  this.cues.push({ CueTrack: trackNumber, CueClusterPosition: this.lastClusterPosition, CueTime });
                  this.emit("cue_info", { CueTrack: trackNumber, CueClusterPosition: this.lastClusterPosition, CueTime: this.lastClusterTimecode });
                  this.emit("cue", { CueTrack: trackNumber, CueClusterPosition: this.lastClusterPosition, CueTime });
                }
              }
              this.last2SimpleBlockAudioTrackTimecode = [this.last2SimpleBlockAudioTrackTimecode[1], timecode];
            }
            if (this.use_duration_every_simpleblock) {
              this.emit("duration", { timecodeScale: this.timecodeScale, duration: this.duration });
            }
            if (this.use_webp) {
              frames_1.forEach(function(frame) {
                var startcode = frame.slice(3, 6).toString("hex");
                if (startcode !== "9d012a") {
                  return;
                }
                var webpBuf = tools2.VP8BitStreamToRiffWebPBuffer(frame);
                var webp = new Blob([webpBuf], { type: "image/webp" });
                var currentTime = _this.duration;
                _this.emit("webp", { currentTime, webp });
              });
            }
          } else if (elm.type === "m" && elm.name === "Cluster" && elm.isEnd === false) {
            this.firstVideoBlockRead = false;
            this.firstAudioBlockRead = false;
            this.emit_segment_info();
            this.emit("cluster_ptr", elm.tagStart);
            this.lastClusterPosition = elm.tagStart;
          } else if (elm.type === "u" && elm.name === "Timecode") {
            this.lastClusterTimecode = elm.value;
          } else if (elm.type === "u" && elm.name === "TimecodeScale") {
            this.timecodeScale = elm.value;
          } else if (elm.type === "m" && elm.name === "TrackEntry") {
            if (elm.isEnd) {
              this.trackTypes[this.currentTrack.TrackNumber] = this.currentTrack.TrackType;
              this.trackDefaultDuration[this.currentTrack.TrackNumber] = this.currentTrack.DefaultDuration;
              this.trackCodecDelay[this.currentTrack.TrackNumber] = this.currentTrack.CodecDelay;
            } else {
              this.currentTrack = { TrackNumber: -1, TrackType: -1, DefaultDuration: null, CodecDelay: null };
            }
          } else if (elm.type === "u" && elm.name === "TrackType") {
            this.currentTrack.TrackType = elm.value;
          } else if (elm.type === "u" && elm.name === "TrackNumber") {
            this.currentTrack.TrackNumber = elm.value;
          } else if (elm.type === "u" && elm.name === "CodecDelay") {
            this.currentTrack.CodecDelay = elm.value;
          } else if (elm.type === "u" && elm.name === "DefaultDuration") {
            if (this.drop_default_duration) {
              console.warn("DefaultDuration detected!, remove it");
              drop = true;
            } else {
              this.currentTrack.DefaultDuration = elm.value;
            }
          } else if (elm.name === "unknown") {
            console.warn(elm);
          }
          if (!this.metadataloaded && elm.dataEnd > 0) {
            this.metadataSize = elm.dataEnd;
          }
          if (!drop) {
            this.chunks.push(elm);
          }
          if (this.logging) {
            this.put(elm);
          }
        };
        Object.defineProperty(EBMLReader2.prototype, "duration", {
          /**
           * DefaultDuration が定義されている場合は最後のフレームのdurationも考慮する
           * 単位 timecodeScale
           *
           * !!! if you need duration with seconds !!!
           * ```js
           * const nanosec = reader.duration * reader.timecodeScale;
           * const sec = nanosec / 1000 / 1000 / 1000;
           * ```
           */
          get: function() {
            if (this.trackInfo.type === "nothing") {
              console.warn("no video, no audio track");
              return 0;
            }
            var defaultDuration = 0;
            var codecDelay = 0;
            var lastTimecode = 0;
            var _defaultDuration = this.trackDefaultDuration[this.trackInfo.trackNumber];
            if (typeof _defaultDuration === "number") {
              defaultDuration = _defaultDuration;
            } else {
              if (this.trackInfo.type === "both") {
                if (this.last2SimpleBlockAudioTrackTimecode[1] > this.last2SimpleBlockVideoTrackTimecode[1]) {
                  defaultDuration = (this.last2SimpleBlockAudioTrackTimecode[1] - this.last2SimpleBlockAudioTrackTimecode[0]) * this.timecodeScale;
                  var delay = this.trackCodecDelay[this.trackTypes.indexOf(2)];
                  if (typeof delay === "number") {
                    codecDelay = delay;
                  }
                  lastTimecode = this.last2SimpleBlockAudioTrackTimecode[1];
                } else {
                  defaultDuration = (this.last2SimpleBlockVideoTrackTimecode[1] - this.last2SimpleBlockVideoTrackTimecode[0]) * this.timecodeScale;
                  var delay = this.trackCodecDelay[this.trackTypes.indexOf(1)];
                  if (typeof delay === "number") {
                    codecDelay = delay;
                  }
                  lastTimecode = this.last2SimpleBlockVideoTrackTimecode[1];
                }
              } else if (this.trackInfo.type === "video") {
                defaultDuration = (this.last2SimpleBlockVideoTrackTimecode[1] - this.last2SimpleBlockVideoTrackTimecode[0]) * this.timecodeScale;
                var delay = this.trackCodecDelay[this.trackInfo.trackNumber];
                if (typeof delay === "number") {
                  codecDelay = delay;
                }
                lastTimecode = this.last2SimpleBlockVideoTrackTimecode[1];
              } else if (this.trackInfo.type === "audio") {
                defaultDuration = (this.last2SimpleBlockAudioTrackTimecode[1] - this.last2SimpleBlockAudioTrackTimecode[0]) * this.timecodeScale;
                var delay = this.trackCodecDelay[this.trackInfo.trackNumber];
                if (typeof delay === "number") {
                  codecDelay = delay;
                }
                lastTimecode = this.last2SimpleBlockAudioTrackTimecode[1];
              }
            }
            var duration_nanosec = (this.lastClusterTimecode + lastTimecode) * this.timecodeScale + defaultDuration - codecDelay;
            var duration = duration_nanosec / this.timecodeScale;
            return Math.floor(duration);
          },
          enumerable: false,
          configurable: true
        });
        EBMLReader2.prototype.addListener = function(event, listener) {
          return _super.prototype.addListener.call(this, event, listener);
        };
        EBMLReader2.prototype.put = function(elm) {
          if (!this.hasLoggingStarted) {
            this.hasLoggingStarted = true;
            if (this.logging && this.logGroup) {
              console.groupCollapsed(this.logGroup);
            }
          }
          if (elm.type === "m") {
            if (elm.isEnd) {
              console.groupEnd();
            } else {
              console.group(elm.name + ":" + elm.tagStart);
            }
          } else if (elm.type === "b") {
            console.log(elm.name, elm.type);
          } else {
            console.log(elm.name, elm.tagStart, elm.type, elm.value);
          }
        };
        return EBMLReader2;
      })(events_1.EventEmitter)
    );
    EBMLReader.default = EBMLReader$1;
    return EBMLReader;
  }
  var hasRequiredEbml;
  function requireEbml() {
    if (hasRequiredEbml) return ebml;
    hasRequiredEbml = 1;
    (function(exports) {
      var __createBinding = ebml && ebml.__createBinding || (Object.create ? (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        Object.defineProperty(o, k2, { enumerable: true, get: function() {
          return m[k];
        } });
      }) : (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        o[k2] = m[k];
      }));
      var __exportStar = ebml && ebml.__exportStar || function(m, exports2) {
        for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
      };
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.tools = exports.Reader = exports.Encoder = exports.Decoder = void 0;
      __exportStar(requireEBML(), exports);
      var EBMLDecoder_1 = requireEBMLDecoder();
      exports.Decoder = EBMLDecoder_1.default;
      var EBMLEncoder_1 = requireEBMLEncoder();
      exports.Encoder = EBMLEncoder_1.default;
      var EBMLReader_1 = requireEBMLReader();
      exports.Reader = EBMLReader_1.default;
      var tools2 = requireTools();
      exports.tools = tools2;
    })(ebml);
    return ebml;
  }
  var hasRequiredLib;
  function requireLib() {
    if (hasRequiredLib) return lib;
    hasRequiredLib = 1;
    var __awaiter = lib && lib.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = lib && lib.__generator || function(thisArg, body) {
      var _ = { label: 0, sent: function() {
        if (t[0] & 1) throw t[1];
        return t[1];
      }, trys: [], ops: [] }, f, y, t, g;
      return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([n, v]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          if (y = 0, t) op = [op[0] & 2, t.value];
          switch (op[0]) {
            case 0:
            case 1:
              t = op;
              break;
            case 4:
              _.label++;
              return { value: op[1], done: false };
            case 5:
              _.label++;
              y = op[1];
              op = [0];
              continue;
            case 7:
              op = _.ops.pop();
              _.trys.pop();
              continue;
            default:
              if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                _ = 0;
                continue;
              }
              if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                _.label = op[1];
                break;
              }
              if (op[0] === 6 && _.label < t[1]) {
                _.label = t[1];
                t = op;
                break;
              }
              if (t && _.label < t[2]) {
                _.label = t[2];
                _.ops.push(op);
                break;
              }
              if (t[2]) _.ops.pop();
              _.trys.pop();
              continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [6, e];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return { value: op[0] ? op[1] : void 0, done: true };
      }
    };
    Object.defineProperty(lib, "__esModule", { value: true });
    var ebml_1 = requireEbml();
    function fixWebmDuration2(blob) {
      return __awaiter(this, void 0, void 0, function() {
        var decoder, reader, readstream, readerBlob, _a, done, value, elms, refinedMetadataBuf, refinedMetadataBlob, firstPartBlobWithoutMetadata, finalBlob;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              if (!blob) {
                throw Error("call to fixWebmDuration requires a blob");
              }
              decoder = new ebml_1.Decoder();
              reader = new ebml_1.Reader();
              readstream = blob.stream();
              readerBlob = readstream.getReader();
              _b.label = 1;
            case 1:
              return [4, readerBlob.read()];
            case 2:
              _a = _b.sent(), done = _a.done, value = _a.value;
              if (done) {
                reader.stop();
                return [3, 3];
              }
              elms = decoder.decode(value);
              elms = elms === null || elms === void 0 ? void 0 : elms.filter(function(elm) {
                return elm.type !== "unknown";
              });
              elms.forEach(function(elm) {
                reader.read(elm);
              });
              value = null;
              return [3, 1];
            case 3:
              refinedMetadataBuf = ebml_1.tools.makeMetadataSeekable(reader.metadatas, reader.duration, reader.cues);
              refinedMetadataBlob = new Blob([refinedMetadataBuf], { type: blob.type });
              firstPartBlobWithoutMetadata = blob.slice(reader.metadataSize);
              finalBlob = new Blob([refinedMetadataBlob, firstPartBlobWithoutMetadata], { type: blob.type });
              return [2, finalBlob];
          }
        });
      });
    }
    lib.default = fixWebmDuration2;
    return lib;
  }
  var libExports = requireLib();
  const fixWebmDuration = /* @__PURE__ */ getDefaultExportFromCjs(libExports);
  const DOWNLOAD_RESTRICTED_DOMAINS = [
    "youtube.com",
    "youtu.be",
    "youtube-nocookie.com"
  ];
  function isDownloadRestricted(urlOrHostname) {
    try {
      let hostname = "";
      const target = urlOrHostname !== void 0 ? urlOrHostname : typeof window !== "undefined" && window.location ? window.location : "";
      if (typeof target === "string") {
        try {
          hostname = new URL(target).hostname;
        } catch {
          hostname = target;
        }
      } else if (target && typeof target === "object" && "hostname" in target) {
        hostname = target.hostname || "";
      }
      if (!hostname) return false;
      return DOWNLOAD_RESTRICTED_DOMAINS.some((domain) => domainMatches(hostname, domain));
    } catch {
      return false;
    }
  }
  class RecordingManager {
    video;
    callbacks;
    mediaRecorder = null;
    isRecordingStream = false;
    recordedChunks = [];
    recordingTimer = null;
    recordingSeconds = 0;
    endedHandler = null;
    constructor(video, callbacks) {
      this.video = video;
      this.callbacks = callbacks;
    }
    get isRecording() {
      return this.isRecordingStream;
    }
    get seconds() {
      return this.recordingSeconds;
    }
    /**
     * Entry point.
     *  - If currently recording → acts as "Stop & Save"
     *  - Else → tries direct download; only records as last resort
     */
    async download() {
      if (isDownloadRestricted()) {
        this.callbacks.onFeedback("⚠️ Download disabled on this site");
        return;
      }
      if (this.isRecordingStream) {
        this.stop(true);
        return;
      }
      const src = getBestVideoSource(this.video);
      if (!src) {
        console.warn("[UFVC] No video source found to download.");
        this.callbacks.onFeedback("⚠️ Video source not found");
        return;
      }
      const filename = deriveFilename(src);
      if (src.startsWith("blob:")) {
        try {
          const res = await fetch(src);
          if (res.ok) {
            const blob = await res.blob();
            if (blob.size > 0) {
              const url = URL.createObjectURL(blob);
              this.triggerDirectDownload(url, filename);
              setTimeout(() => URL.revokeObjectURL(url), 15e3);
              return;
            }
          }
        } catch (error) {
          console.log("[Video] blob fetch failed:", error);
        }
        this.startStreamRecording(filename);
        return;
      }
      this.downloadViaChrome(src, filename);
    }
    stop(shouldSave = true) {
      if (!this.isRecordingStream || !this.mediaRecorder) return;
      this.isRecordingStream = false;
      if (!shouldSave) {
        this.recordedChunks = [];
      }
      try {
        if (this.mediaRecorder.state !== "inactive") {
          this.mediaRecorder.stop();
        }
      } catch (err) {
        console.error("[UFVC] Error stopping recorder:", err);
      }
      if (!shouldSave) this.cleanup();
    }
    destroy() {
      if (this.isRecordingStream) this.stop(false);
      else this.cleanup();
    }
    // ─── Internals ────────────────────────────────────────────────────────
    startStreamRecording(defaultFilename) {
      const stream = this.video.captureStream?.() ?? this.video.mozCaptureStream?.();
      if (!stream || typeof MediaRecorder === "undefined") {
        console.warn("[UFVC] Media captureStream is not supported.");
        this.callbacks.onFeedback("⚠️ Direct stream unavailable");
        return;
      }
      const mimeType = this.pickWebmMimeType();
      try {
        this.recordedChunks = [];
        this.mediaRecorder = new MediaRecorder(stream, { mimeType });
      } catch (err) {
        console.warn("[UFVC] Failed to init MediaRecorder:", err);
        this.callbacks.onFeedback("⚠️ Stream protected (CORS)");
        return;
      }
      this.isRecordingStream = true;
      this.recordingSeconds = 0;
      this.callbacks.onRecordingStart();
      this.mediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) this.recordedChunks.push(e.data);
      };
      this.mediaRecorder.onstop = () => {
        void this.finalizeRecording(mimeType, defaultFilename);
      };
      this.endedHandler = () => {
        if (this.isRecordingStream) this.stop(true);
      };
      this.video.addEventListener("ended", this.endedHandler, { once: true });
      if (this.video.paused) {
        try {
          const p = this.video.play();
          if (p && typeof p.catch === "function") p.catch(() => {
          });
        } catch {
        }
      }
      this.mediaRecorder.start(250);
      this.recordingTimer = setInterval(() => {
        this.recordingSeconds++;
        this.callbacks.onRecordingTick(this.recordingSeconds);
      }, 1e3);
    }
    async finalizeRecording(mimeType, defaultFilename) {
      if (this.recordedChunks.length === 0) {
        this.cleanup();
        return;
      }
      const recFilename = `${defaultFilename.replace(/\.[^/.]+$/, "")}.webm`;
      let blob = new Blob(this.recordedChunks, { type: mimeType });
      try {
        blob = await fixWebmDuration(blob);
      } catch (err) {
        console.warn("[UFVC] WebM duration patch failed:", err);
      }
      const url = URL.createObjectURL(blob);
      this.triggerDirectDownload(url, recFilename);
      setTimeout(() => URL.revokeObjectURL(url), 2e4);
      this.callbacks.onFeedback("✅ Video Saved!");
      this.cleanup();
    }
    /**
     * WebM-only MIME selection.
     * Prefers VP9 for smaller files; falls back to VP8 then generic WebM.
     *
     * TODO(settings): expose format preference in extension settings and
     * allow falling back to MP4 + remux when the user enables it.
     */
    pickWebmMimeType() {
      if (MediaRecorder.isTypeSupported("video/webm;codecs=vp9,opus")) {
        return "video/webm;codecs=vp9,opus";
      }
      if (MediaRecorder.isTypeSupported("video/webm;codecs=vp8,opus")) {
        return "video/webm;codecs=vp8,opus";
      }
      return "video/webm";
    }
    cleanup() {
      this.isRecordingStream = false;
      if (this.recordingTimer) {
        clearInterval(this.recordingTimer);
        this.recordingTimer = null;
      }
      if (this.endedHandler) {
        this.video.removeEventListener("ended", this.endedHandler);
        this.endedHandler = null;
      }
      this.mediaRecorder = null;
      this.callbacks.onRecordingEnd();
    }
    downloadViaChrome(url, filename) {
      try {
        if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
          chrome.runtime.sendMessage(
            { type: "DOWNLOAD_VIDEO", url, filename },
            (response) => {
              if (chrome.runtime.lastError || !response?.success) {
                this.triggerDirectDownload(url, filename);
              }
            }
          );
        } else {
          this.triggerDirectDownload(url, filename);
        }
      } catch {
        this.triggerDirectDownload(url, filename);
      }
    }
    triggerDirectDownload(url, filename) {
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        if (a.parentNode) a.parentNode.removeChild(a);
      }, 100);
    }
  }
  const CLASS = {
    IDLE: "idle",
    OPEN: "open",
    DRAGGING: "dragging",
    ACTIVE: "active",
    MINIMAL_MODE: "minimal-mode",
    SPEED_ITEM: "ufvc-speed-item",
    POPUPS_DOWN: "popups-down"
  };
  const SELECTOR = {
    SPEED_ITEM: `.${CLASS.SPEED_ITEM}`
  };
  const ATTR = {
    SPEED: "data-speed"
  };
  class VideoController {
    id;
    video;
    ui;
    positionManager;
    config;
    isDestroyed = false;
    isDraggingScrub = false;
    autoHideTimeout = null;
    cleanupFns = [];
    recording;
    onHoverCallback;
    constructor(id, video, config, onHover) {
      this.id = id;
      this.video = video;
      this.config = config;
      this.onHoverCallback = onHover;
      this.ui = createShadowUI();
      this.applyTheme(config.theme);
      (document.documentElement || document.body).appendChild(this.ui.host);
      this.positionManager = new PositionManager(video, this.ui.host, this.ui.container, this.config);
      this.recording = new RecordingManager(video, {
        onRecordingStart: () => this.handleRecordingStart(),
        onRecordingTick: (s) => this.handleRecordingTick(s),
        onRecordingEnd: () => this.handleRecordingEnd(),
        onFeedback: (msg) => this.showDownloadFeedback(msg)
      });
      this.bindVideoEvents();
      this.bindUIEvents();
      this.syncInitialState();
      this.resetAutoHideTimer();
    }
    applyTheme(themeId) {
      this.config.theme = themeId;
      themeEngine.applyTheme(this.ui.container, themeId);
    }
    updateConfig(newConfig) {
      this.config = newConfig;
      this.applyTheme(newConfig.theme);
      this.setMinimalMode(newConfig.controlsLayout === "minimal");
      this.positionManager.updateConfig(newConfig);
    }
    reposition() {
      this.positionManager.updatePosition();
    }
    syncInitialState() {
      this.setMinimalMode(this.config.controlsLayout === "minimal");
      if (isDownloadRestricted()) {
        this.ui.contextMenu.style.display = "none";
        this.ui.contextDownloadBtn.disabled = true;
      }
      this.updatePlayState();
      this.updateTimeDisplay();
      this.updateVolumeUI();
      this.updateSpeedUI();
    }
    // ─── UI state helpers (CSS class toggles) ─────────────────────────────
    /** Show the controls bar (removes the idle state). */
    showControls() {
      this.ui.container.classList.remove(CLASS.IDLE);
    }
    /** Hide the controls bar (adds the idle state). */
    hideControls() {
      this.ui.container.classList.add(CLASS.IDLE);
    }
    setMinimalMode(enabled) {
      this.ui.container.classList.toggle(CLASS.MINIMAL_MODE, enabled);
    }
    setScrubbing(isScrubbing) {
      this.isDraggingScrub = isScrubbing;
      this.ui.progressContainer.classList.toggle(CLASS.DRAGGING, isScrubbing);
    }
    // Speed menu
    isSpeedMenuOpen() {
      return this.ui.speedMenu.classList.contains(CLASS.OPEN);
    }
    openSpeedMenu() {
      this.ui.speedMenu.classList.add(CLASS.OPEN);
    }
    closeSpeedMenu() {
      this.ui.speedMenu.classList.remove(CLASS.OPEN);
    }
    toggleSpeedMenu() {
      if (!this.isSpeedMenuOpen()) {
        const barRect = this.ui.container.getBoundingClientRect();
        this.ui.container.classList.toggle(CLASS.POPUPS_DOWN, barRect.top < 250);
      }
      this.ui.speedMenu.classList.toggle(CLASS.OPEN);
    }
    // Context menu
    isContextMenuOpen() {
      return this.ui.contextMenu.classList.contains(CLASS.OPEN);
    }
    openContextMenu() {
      this.ui.contextMenu.classList.add(CLASS.OPEN);
    }
    closeContextMenu() {
      this.ui.contextMenu.classList.remove(CLASS.OPEN);
    }
    // Both menus
    isAnyMenuOpen() {
      return this.isSpeedMenuOpen() || this.isContextMenuOpen();
    }
    closeAllMenus() {
      this.closeSpeedMenu();
      this.closeContextMenu();
    }
    // Speed items
    getSpeedItems() {
      return this.ui.speedMenu.querySelectorAll(SELECTOR.SPEED_ITEM);
    }
    setSpeedItemActive(item, isActive) {
      item.classList.toggle(CLASS.ACTIVE, isActive);
    }
    // ─── Video events ─────────────────────────────────────────────────────
    bindVideoEvents() {
      const onPlayPause = () => {
        this.updatePlayState();
        this.resetAutoHideTimer();
      };
      const onTimeUpdate = () => {
        if (!this.isDraggingScrub) this.updateTimeDisplay();
      };
      const onVolumeChange = () => {
        this.updateVolumeUI();
        this.resetAutoHideTimer();
      };
      const onProgress = () => this.updateBufferProgress();
      const onRateChange = () => this.updateSpeedUI();
      this.video.addEventListener("play", onPlayPause);
      this.video.addEventListener("pause", onPlayPause);
      this.video.addEventListener("timeupdate", onTimeUpdate);
      this.video.addEventListener("volumechange", onVolumeChange);
      this.video.addEventListener("progress", onProgress);
      this.video.addEventListener("ratechange", onRateChange);
      this.cleanupFns.push(() => {
        this.video.removeEventListener("play", onPlayPause);
        this.video.removeEventListener("pause", onPlayPause);
        this.video.removeEventListener("timeupdate", onTimeUpdate);
        this.video.removeEventListener("volumechange", onVolumeChange);
        this.video.removeEventListener("progress", onProgress);
        this.video.removeEventListener("ratechange", onRateChange);
      });
    }
    // ─── UI events ────────────────────────────────────────────────────────
    bindUIEvents() {
      const handlePlayPauseClick = (e) => {
        e.stopPropagation();
        e.preventDefault();
        if (this.video.paused) this.video.play().catch(() => {
        });
        else this.video.pause();
      };
      this.ui.playPauseBtn.addEventListener("click", handlePlayPauseClick);
      this.cleanupFns.push(
        () => this.ui.playPauseBtn.removeEventListener("click", handlePlayPauseClick)
      );
      const handleSeekBackClick = (e) => {
        e.stopPropagation();
        e.preventDefault();
        const interval = this.config.seekInterval || 5;
        this.video.currentTime = Math.max(0, this.video.currentTime - interval);
        this.updateTimeDisplay();
        this.resetAutoHideTimer();
      };
      this.ui.seekBackBtn.addEventListener("click", handleSeekBackClick);
      this.cleanupFns.push(
        () => this.ui.seekBackBtn.removeEventListener("click", handleSeekBackClick)
      );
      const handleSeekForwardClick = (e) => {
        e.stopPropagation();
        e.preventDefault();
        const interval = this.config.seekInterval || 5;
        const dur = isFinite(this.video.duration) ? this.video.duration : Infinity;
        this.video.currentTime = Math.min(dur, this.video.currentTime + interval);
        this.updateTimeDisplay();
        this.resetAutoHideTimer();
      };
      this.ui.seekForwardBtn.addEventListener("click", handleSeekForwardClick);
      this.cleanupFns.push(
        () => this.ui.seekForwardBtn.removeEventListener("click", handleSeekForwardClick)
      );
      const handleVolumeMouseEnter = () => {
        const barRect = this.ui.container.getBoundingClientRect();
        this.ui.container.classList.toggle(CLASS.POPUPS_DOWN, barRect.top < 250);
      };
      this.ui.volumeBtn.addEventListener("mouseenter", handleVolumeMouseEnter);
      this.ui.volumeSliderContainer.addEventListener("mouseenter", handleVolumeMouseEnter);
      this.cleanupFns.push(() => {
        this.ui.volumeBtn.removeEventListener("mouseenter", handleVolumeMouseEnter);
        this.ui.volumeSliderContainer.removeEventListener("mouseenter", handleVolumeMouseEnter);
      });
      const handleVolumeBtnClick = (e) => {
        e.stopPropagation();
        const barRect = this.ui.container.getBoundingClientRect();
        this.ui.container.classList.toggle(CLASS.POPUPS_DOWN, barRect.top < 250);
        this.toggleMute();
      };
      this.ui.volumeBtn.addEventListener("click", handleVolumeBtnClick);
      this.cleanupFns.push(
        () => this.ui.volumeBtn.removeEventListener("click", handleVolumeBtnClick)
      );
      const handleVolumeInput = (e) => {
        e.stopPropagation();
        const val = parseFloat(this.ui.volumeSlider.value);
        this.video.volume = val;
        this.video.muted = val === 0;
      };
      this.ui.volumeSlider.addEventListener("input", handleVolumeInput);
      this.cleanupFns.push(
        () => this.ui.volumeSlider.removeEventListener("input", handleVolumeInput)
      );
      const getProgressRatioFromEvent = (e) => {
        const rect = this.ui.progressContainer.getBoundingClientRect();
        const offsetX = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
        return rect.width > 0 ? offsetX / rect.width : 0;
      };
      const handleProgressMouseMove = (e) => {
        const ratio = getProgressRatioFromEvent(e);
        const duration = isFinite(this.video.duration) ? this.video.duration : 0;
        const hoverTime = ratio * duration;
        this.ui.timeTooltip.textContent = formatTime(hoverTime);
        this.ui.timeTooltip.style.left = `${Math.round(ratio * 100)}%`;
        if (this.isDraggingScrub) {
          this.ui.progressBar.style.width = `${ratio * 100}%`;
          this.ui.scrubThumb.style.left = `${ratio * 100}%`;
          this.ui.currentTimeSpan.textContent = formatTime(hoverTime);
        }
      };
      const handleProgressMouseDown = (e) => {
        e.stopPropagation();
        e.preventDefault();
        this.setScrubbing(true);
        this.resetAutoHideTimer();
        const ratio = getProgressRatioFromEvent(e);
        const duration = isFinite(this.video.duration) ? this.video.duration : 0;
        this.video.currentTime = ratio * duration;
        this.updateTimeDisplay();
        const onWindowMouseMove = (moveEvent) => handleProgressMouseMove(moveEvent);
        const onWindowMouseUp = (upEvent) => {
          this.setScrubbing(false);
          const endRatio = getProgressRatioFromEvent(upEvent);
          const finalDuration = isFinite(this.video.duration) ? this.video.duration : 0;
          this.video.currentTime = endRatio * finalDuration;
          this.updateTimeDisplay();
          this.resetAutoHideTimer();
          window.removeEventListener("mousemove", onWindowMouseMove);
          window.removeEventListener("mouseup", onWindowMouseUp);
        };
        window.addEventListener("mousemove", onWindowMouseMove);
        window.addEventListener("mouseup", onWindowMouseUp);
      };
      this.ui.progressContainer.addEventListener("mousemove", handleProgressMouseMove);
      this.ui.progressContainer.addEventListener("mousedown", handleProgressMouseDown);
      this.cleanupFns.push(() => {
        this.ui.progressContainer.removeEventListener("mousemove", handleProgressMouseMove);
        this.ui.progressContainer.removeEventListener("mousedown", handleProgressMouseDown);
      });
      const handleSpeedBtnClick = (e) => {
        e.stopPropagation();
        this.toggleSpeedMenu();
      };
      this.ui.speedBtn.addEventListener("click", handleSpeedBtnClick);
      this.cleanupFns.push(
        () => this.ui.speedBtn.removeEventListener("click", handleSpeedBtnClick)
      );
      const speedItems = this.getSpeedItems();
      speedItems.forEach((item) => {
        const handleSpeedItemClick = (e) => {
          e.stopPropagation();
          const speed = parseFloat(item.getAttribute(ATTR.SPEED) || "1");
          this.video.playbackRate = speed;
          this.closeSpeedMenu();
        };
        item.addEventListener("click", handleSpeedItemClick);
        this.cleanupFns.push(() => item.removeEventListener("click", handleSpeedItemClick));
      });
      const handleDocumentClick = () => {
        this.closeAllMenus();
      };
      document.addEventListener("click", handleDocumentClick);
      this.cleanupFns.push(() => document.removeEventListener("click", handleDocumentClick));
      const handleContainerClick = () => {
        this.closeContextMenu();
      };
      this.ui.container.addEventListener("click", handleContainerClick);
      this.cleanupFns.push(() => this.ui.container.removeEventListener("click", handleContainerClick));
      const handleContextMenu = (e) => {
        if (isDownloadRestricted()) {
          return;
        }
        e.preventDefault();
        e.stopPropagation();
        this.showContextMenu(e);
      };
      this.ui.container.addEventListener("contextmenu", handleContextMenu);
      this.cleanupFns.push(() => this.ui.container.removeEventListener("contextmenu", handleContextMenu));
      const handleDownloadClick = (e) => {
        e.stopPropagation();
        e.preventDefault();
        this.closeContextMenu();
        if (isDownloadRestricted()) {
          this.showDownloadFeedback("⚠️ Not available on this site");
          return;
        }
        void this.recording.download();
      };
      this.ui.contextDownloadBtn.addEventListener("click", handleDownloadClick);
      this.cleanupFns.push(
        () => this.ui.contextDownloadBtn.removeEventListener("click", handleDownloadClick)
      );
      const handleWindowContextMenu = (e) => {
        if (!this.ui.host.contains(e.target)) {
          this.closeContextMenu();
        }
      };
      window.addEventListener("contextmenu", handleWindowContextMenu);
      this.cleanupFns.push(
        () => window.removeEventListener("contextmenu", handleWindowContextMenu)
      );
      const handleKeyDown = (e) => {
        if (e.key === "Escape") {
          this.closeAllMenus();
        }
      };
      window.addEventListener("keydown", handleKeyDown);
      this.cleanupFns.push(() => window.removeEventListener("keydown", handleKeyDown));
      const handleFullscreenClick = (e) => {
        e.stopPropagation();
        if (!document.fullscreenElement) {
          if (this.video.requestFullscreen) this.video.requestFullscreen().catch(() => {
          });
          else if (this.video.webkitRequestFullscreen) {
            this.video.webkitRequestFullscreen();
          }
        } else {
          if (document.exitFullscreen) document.exitFullscreen().catch(() => {
          });
        }
      };
      this.ui.fullscreenBtn.addEventListener("click", handleFullscreenClick);
      this.cleanupFns.push(
        () => this.ui.fullscreenBtn.removeEventListener("click", handleFullscreenClick)
      );
      const handleMouseEnter = () => {
        this.resetAutoHideTimer();
        this.onHoverCallback?.(this.video, true, this.ui.host);
      };
      const handleMouseLeave = () => {
        this.resetAutoHideTimer();
        this.onHoverCallback?.(this.video, false, this.ui.host);
      };
      const handleActivity = () => this.resetAutoHideTimer();
      this.ui.container.addEventListener("mouseenter", handleMouseEnter);
      this.ui.container.addEventListener("mouseleave", handleMouseLeave);
      this.ui.container.addEventListener("mousemove", handleActivity);
      this.video.addEventListener("mousemove", handleActivity);
      this.cleanupFns.push(() => {
        this.ui.container.removeEventListener("mouseenter", handleMouseEnter);
        this.ui.container.removeEventListener("mouseleave", handleMouseLeave);
        this.ui.container.removeEventListener("mousemove", handleActivity);
        this.video.removeEventListener("mousemove", handleActivity);
      });
    }
    // ─── UI state updates ─────────────────────────────────────────────────
    updatePlayState() {
      if (this.video.paused || this.video.ended) {
        this.ui.playIcon.style.display = "inline-block";
        this.ui.pauseIcon.style.display = "none";
        this.showControls();
      } else {
        this.ui.playIcon.style.display = "none";
        this.ui.pauseIcon.style.display = "inline-block";
      }
    }
    updateTimeDisplay() {
      const cur = this.video.currentTime || 0;
      const dur = isFinite(this.video.duration) ? this.video.duration : 0;
      this.ui.currentTimeSpan.textContent = formatTime(cur);
      this.ui.durationSpan.textContent = formatTime(dur);
      const ratio = dur > 0 ? Math.min(1, Math.max(0, cur / dur)) : 0;
      const percent = `${ratio * 100}%`;
      this.ui.progressBar.style.width = percent;
      this.ui.scrubThumb.style.left = percent;
      if (this.ui.miniProgressBar) this.ui.miniProgressBar.style.width = percent;
    }
    updateBufferProgress() {
      const dur = isFinite(this.video.duration) ? this.video.duration : 0;
      if (dur <= 0 || !this.video.buffered.length) {
        this.ui.bufferBar.style.width = "0%";
        return;
      }
      const cur = this.video.currentTime;
      for (let i = 0; i < this.video.buffered.length; i++) {
        if (this.video.buffered.start(i) <= cur && cur <= this.video.buffered.end(i)) {
          const bufferedEnd = this.video.buffered.end(i);
          this.ui.bufferBar.style.width = `${Math.min(100, bufferedEnd / dur * 100)}%`;
          break;
        }
      }
    }
    updateVolumeUI() {
      const isMuted = this.video.muted || this.video.volume === 0;
      this.ui.volumeSlider.value = isMuted ? "0" : String(this.video.volume);
      this.ui.volumeHighIcon.style.display = "none";
      this.ui.volumeLowIcon.style.display = "none";
      this.ui.volumeMuteIcon.style.display = "none";
      if (isMuted) this.ui.volumeMuteIcon.style.display = "inline-block";
      else if (this.video.volume < 0.5) this.ui.volumeLowIcon.style.display = "inline-block";
      else this.ui.volumeHighIcon.style.display = "inline-block";
    }
    updateSpeedUI() {
      const rate = this.video.playbackRate || 1;
      this.ui.speedBtn.textContent = `${rate}x`;
      const items = this.getSpeedItems();
      items.forEach((item) => {
        const speed = parseFloat(item.getAttribute(ATTR.SPEED) || "1");
        this.setSpeedItemActive(item, speed === rate);
      });
    }
    resetAutoHideTimer() {
      if (this.autoHideTimeout) clearTimeout(this.autoHideTimeout);
      this.showControls();
      if (this.video.paused || this.video.ended || this.isDraggingScrub || this.isAnyMenuOpen()) {
        return;
      }
      this.autoHideTimeout = setTimeout(() => {
        if (!this.video.paused && !this.isDraggingScrub && !this.isDestroyed) {
          this.hideControls();
        }
      }, this.config.autoHideDelay);
    }
    showContextMenu(e) {
      if (isDownloadRestricted()) {
        return;
      }
      this.closeSpeedMenu();
      this.resetAutoHideTimer();
      const barRect = this.ui.container.getBoundingClientRect();
      const relX = e.clientX - barRect.left;
      const relY = e.clientY - barRect.top;
      const menuWidth = 145;
      const maxLeft = Math.max(0, barRect.width - menuWidth);
      const clampedLeft = Math.max(0, Math.min(relX - 10, maxLeft));
      this.ui.contextMenu.style.left = `${clampedLeft}px`;
      if (barRect.top < 65) {
        this.ui.contextMenu.style.top = `${relY + 4}px`;
        this.ui.contextMenu.style.bottom = "auto";
      } else {
        this.ui.contextMenu.style.bottom = `${barRect.height - relY + 4}px`;
        this.ui.contextMenu.style.top = "auto";
      }
      this.openContextMenu();
    }
    // ─── Recording UI bridge ──────────────────────────────────────────────
    handleRecordingStart() {
      this.ui.recIndicator.style.display = "inline-flex";
      this.ui.recTime.textContent = "0:00";
      this.updateDownloadBtnRecording(true, 0);
    }
    handleRecordingTick(seconds) {
      this.ui.recTime.textContent = formatTime(seconds);
      this.updateDownloadBtnRecording(true, seconds);
    }
    handleRecordingEnd() {
      this.ui.recIndicator.style.display = "none";
      this.updateDownloadBtnRecording(false, 0);
    }
    updateDownloadBtnRecording(isRec, seconds) {
      if (isRec) {
        this.ui.contextDownloadBtn.innerHTML = `
        <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><rect x="6" y="6" width="12" height="12" rx="2" fill="#ef4444"/></svg>
        <span>Stop & Save (${formatTime(seconds)})</span>
      `;
      } else {
        this.ui.contextDownloadBtn.innerHTML = `
        ${ICONS.download}
        <span>Download Video</span>
      `;
      }
    }
    showDownloadFeedback(message) {
      this.ui.contextDownloadBtn.innerHTML = `<span>${message}</span>`;
      setTimeout(() => {
        this.updateDownloadBtnRecording(this.recording.isRecording, this.recording.seconds);
      }, 2500);
    }
    // ─── Lifecycle ────────────────────────────────────────────────────────
    destroy() {
      if (this.isDestroyed) return;
      this.isDestroyed = true;
      this.recording.destroy();
      if (this.autoHideTimeout) {
        clearTimeout(this.autoHideTimeout);
        this.autoHideTimeout = null;
      }
      this.cleanupFns.forEach((fn) => {
        try {
          fn();
        } catch (err) {
          console.error("[UFVC Controller] Cleanup error:", err);
        }
      });
      this.cleanupFns = [];
      this.positionManager.destroy();
      if (this.ui.host.parentNode) {
        this.ui.host.parentNode.removeChild(this.ui.host);
      }
    }
    toggleMute() {
      this.video.muted = !this.video.muted;
      if (!this.video.muted && this.video.volume === 0) {
        this.video.volume = 0.5;
      }
    }
  }
  class ControllerManager {
    controllers = /* @__PURE__ */ new Map();
    currentConfig;
    onHoverCallback;
    constructor(initialConfig, onHover) {
      this.currentConfig = initialConfig;
      this.onHoverCallback = onHover;
    }
    /**
     * Syncs active controllers with the newly selected active candidates.
     * Creates new controllers for newly active videos, and tears down
     * controllers for videos that are no longer active.
     */
    syncActiveVideos(activeVideos, config) {
      this.currentConfig = config;
      if (!config.enabled) {
        this.destroyAll();
        return;
      }
      const activeSet = /* @__PURE__ */ new Set();
      activeVideos.forEach((c) => activeSet.add(c.element));
      for (const [video, controller] of Array.from(this.controllers.entries())) {
        if (!activeSet.has(video) || !video.isConnected) {
          controller.destroy();
          this.controllers.delete(video);
        }
      }
      for (const candidate of activeVideos) {
        if (!this.controllers.has(candidate.element) && candidate.element.isConnected) {
          const controller = new VideoController(
            candidate.id,
            candidate.element,
            config,
            this.onHoverCallback
          );
          this.controllers.set(candidate.element, controller);
        }
      }
    }
    /**
     * Updates configuration across all active controllers
     */
    updateConfig(newConfig) {
      this.currentConfig = newConfig;
      if (!newConfig.enabled) {
        this.destroyAll();
        return;
      }
      for (const controller of this.controllers.values()) {
        controller.updateConfig(newConfig);
      }
    }
    /**
     * Removes and destroys a specific video controller
     */
    removeController(video) {
      const controller = this.controllers.get(video);
      if (controller) {
        controller.destroy();
        this.controllers.delete(video);
      }
    }
    /**
     * Repositions all active controllers
     */
    repositionAll() {
      for (const controller of this.controllers.values()) {
        controller.reposition();
      }
    }
    /**
     * Returns controller for a specific video element
     */
    getController(video) {
      return this.controllers.get(video);
    }
    /**
     * Returns all active controllers
     */
    getAllControllers() {
      return Array.from(this.controllers.values());
    }
    /**
     * Returns the count of active controllers
     */
    activeCount() {
      return this.controllers.size;
    }
    /**
     * Destroys all active controllers immediately
     */
    destroyAll() {
      for (const controller of this.controllers.values()) {
        controller.destroy();
      }
      this.controllers.clear();
    }
  }
  function normalizeKey(key) {
    if (key === " ") return "space";
    const k = key.trim().toLowerCase();
    if (k === "space") return "space";
    if (k === "left" || k === "arrowleft") return "arrowleft";
    if (k === "right" || k === "arrowright") return "arrowright";
    if (k === "up" || k === "arrowup") return "arrowup";
    if (k === "down" || k === "arrowdown") return "arrowdown";
    if (k.startsWith("key") && k.length === 4) return k;
    if (/^[a-z]$/.test(k)) return `key${k}`;
    if (/^[0-9]$/.test(k)) return `digit${k}`;
    return k;
  }
  function parseShortcut(shortcutStr) {
    if (!shortcutStr || !shortcutStr.trim()) {
      return { ctrl: false, alt: false, shift: false, meta: false, key: "" };
    }
    const parts = shortcutStr.split("+").map((p) => p.trim());
    let ctrl = false;
    let alt = false;
    let shift = false;
    let meta = false;
    let key = "";
    for (const part of parts) {
      const p = part.toLowerCase();
      if (p === "ctrl" || p === "control") {
        ctrl = true;
      } else if (p === "alt" || p === "option") {
        alt = true;
      } else if (p === "shift") {
        shift = true;
      } else if (p === "meta" || p === "cmd" || p === "command" || p === "win") {
        meta = true;
      } else {
        key = part;
      }
    }
    return { ctrl, alt, shift, meta, key };
  }
  function matchesShortcut(e, shortcutStr) {
    if (!shortcutStr) return false;
    const parsed = parseShortcut(shortcutStr);
    if (!parsed.key) return false;
    if (e.ctrlKey !== parsed.ctrl) return false;
    if (e.altKey !== parsed.alt) return false;
    if (e.shiftKey !== parsed.shift) return false;
    if (e.metaKey !== parsed.meta) return false;
    const expectedKey = normalizeKey(parsed.key);
    const eventCode = normalizeKey(e.code);
    const eventKey = normalizeKey(e.key);
    return eventCode === expectedKey || eventKey === expectedKey;
  }
  class ShortcutManager {
    controllerManager;
    config;
    keydownHandler = null;
    constructor(controllerManager, config) {
      this.controllerManager = controllerManager;
      this.config = config;
    }
    /**
     * Updates shortcut configuration (e.g. seek interval, custom shortcut bindings)
     */
    updateConfig(config) {
      this.config = { ...this.config, ...config };
    }
    /**
     * Starts listening for keyboard shortcuts
     */
    start() {
      if (this.keydownHandler) return;
      this.keydownHandler = (e) => {
        const activeEl = getDeepActiveElement();
        if (isEditableElement(activeEl)) {
          return;
        }
        const shortcuts = this.config.shortcuts || DEFAULT_SHORTCUTS;
        const isPlay = matchesShortcut(e, shortcuts.togglePlay);
        const isSeekBack = matchesShortcut(e, shortcuts.seekBackward) || !shortcuts.seekBackward && (e.code === "KeyJ" || e.code === "ArrowLeft");
        const isSeekFwd = matchesShortcut(e, shortcuts.seekForward) || !shortcuts.seekForward && (e.code === "KeyL" || e.code === "ArrowRight");
        const isVolUp = matchesShortcut(e, shortcuts.volumeUp);
        const isVolDown = matchesShortcut(e, shortcuts.volumeDown);
        const isMute = matchesShortcut(e, shortcuts.toggleMute);
        const isFullscreen = matchesShortcut(e, shortcuts.toggleFullscreen);
        if (!isPlay && !isSeekBack && !isSeekFwd && !isVolUp && !isVolDown && !isMute && !isFullscreen) {
          return;
        }
        const controllers = this.controllerManager.getAllControllers();
        if (controllers.length === 0) {
          return;
        }
        const targetController = controllers.find((c) => !c.video.paused) || controllers[0];
        if (!targetController || !targetController.video.isConnected) {
          return;
        }
        const video = targetController.video;
        const seekSecs = this.config.seekInterval || 5;
        if (isPlay) {
          if (video.paused) {
            video.play().catch(() => {
            });
          } else {
            video.pause();
          }
        } else if (isSeekBack) {
          video.currentTime = Math.max(0, video.currentTime - seekSecs);
        } else if (isSeekFwd) {
          const dur = isFinite(video.duration) ? video.duration : Infinity;
          video.currentTime = Math.min(dur, video.currentTime + seekSecs);
        } else if (isVolUp) {
          video.volume = Math.min(1, Math.round((video.volume + 0.1) * 10) / 10);
          video.muted = false;
        } else if (isVolDown) {
          video.volume = Math.max(0, Math.round((video.volume - 0.1) * 10) / 10);
          if (video.volume === 0) {
            video.muted = true;
          }
        } else if (isMute) {
          video.muted = !video.muted;
          if (!video.muted && video.volume === 0) {
            video.volume = 0.5;
          }
        } else if (isFullscreen) {
          if (!document.fullscreenElement) {
            if (video.requestFullscreen) {
              video.requestFullscreen().catch(() => {
              });
            } else if (video.webkitRequestFullscreen) {
              video.webkitRequestFullscreen();
            }
          } else {
            document.exitFullscreen().catch(() => {
            });
          }
        }
      };
      window.addEventListener("keydown", this.keydownHandler, { capture: true });
    }
    /**
     * Stops listening for keyboard shortcuts
     */
    stop() {
      if (this.keydownHandler) {
        window.removeEventListener("keydown", this.keydownHandler, { capture: true });
        this.keydownHandler = null;
      }
    }
  }
  class ContentCoordinator {
    currentUrl = new URL(window.location.href);
    currentDomain = getDomainFromUrl(window.location);
    activeAdapter;
    currentConfig;
    registry;
    controllerManager;
    shortcutManager;
    observer;
    isInitialized = false;
    constructor() {
      this.activeAdapter = adapterManager.resolve(this.currentUrl);
    }
    async initialize() {
      if (this.isInitialized) return;
      this.isInitialized = true;
      await this.reloadConfiguration();
      this.controllerManager = new ControllerManager(this.currentConfig, (video, isHovered, host) => {
        if (this.activeAdapter.onControllerHover) {
          this.activeAdapter.onControllerHover(video, isHovered, host);
        }
      });
      this.shortcutManager = new ShortcutManager(this.controllerManager, {
        seekInterval: this.currentConfig.seekInterval,
        shortcuts: this.currentConfig.shortcuts
      });
      this.shortcutManager.start();
      this.registry = new VideoRegistry(
        () => this.scheduleSelection(),
        (videoId, video) => {
          this.controllerManager.removeController(video);
          if (this.activeAdapter.onVideoDeactivated) {
            this.activeAdapter.onVideoDeactivated(video);
          }
        },
        {
          filterVideo: this.activeAdapter.filterVideo ? (v) => this.activeAdapter.filterVideo(v) : void 0,
          scoreVideo: this.activeAdapter.scoreVideo ? (v, ctx) => this.activeAdapter.scoreVideo(v, ctx) : void 0
        }
      );
      this.observer = new VideoObserver({
        onVideoAdded: (video) => {
          this.registry.register(video, this.currentConfig);
          if (this.activeAdapter.onVideoDetected) {
            this.activeAdapter.onVideoDetected(video);
          }
          this.scheduleSelection();
        },
        onVideoRemoved: (video) => {
          this.registry.unregister(video);
          this.scheduleSelection();
        }
      });
      this.observer.start();
      storageManager.onChanged(async () => {
        await this.reloadConfiguration();
        this.controllerManager.updateConfig(this.currentConfig);
        this.shortcutManager.updateConfig({
          seekInterval: this.currentConfig.seekInterval,
          shortcuts: this.currentConfig.shortcuts
        });
        this.scheduleSelection();
      });
      this.setupSpaNavigationListener();
      this.setupMessageListener();
    }
    /**
     * Reloads and cascades configuration layers:
     * User per-site > Site adapter > Global user > Built-in defaults
     */
    async reloadConfiguration() {
      const all = await storageManager.getAll();
      themeEngine.setCustomThemes(all.customThemes);
      this.activeAdapter = adapterManager.resolve(this.currentUrl);
      if (this.registry) {
        this.registry.setHooks({
          filterVideo: this.activeAdapter.filterVideo ? (v) => this.activeAdapter.filterVideo(v) : void 0,
          scoreVideo: this.activeAdapter.scoreVideo ? (v, ctx) => this.activeAdapter.scoreVideo(v, ctx) : void 0
        });
        this.registry.updateAll(this.currentConfig);
      }
      this.currentConfig = resolveEffectiveConfig({
        domain: this.currentDomain,
        userSiteSettings: all.siteSettings[this.currentDomain],
        adapterOverrides: this.activeAdapter.getConfigOverrides(),
        globalUserSettings: all.globalSettings
      });
    }
    /**
     * Debounced candidate selection to avoid churning during high-frequency events
     */
    scheduleSelection = debounce(() => {
      if (!this.currentConfig.enabled) {
        this.controllerManager.destroyAll();
        return;
      }
      const candidates = this.registry.getCandidates();
      const activeCandidates = selectActiveVideos(
        candidates,
        this.currentConfig,
        this.activeAdapter.selectVideos ? (c) => this.activeAdapter.selectVideos(c) : void 0
      );
      this.controllerManager.syncActiveVideos(activeCandidates, this.currentConfig);
      if (this.activeAdapter.onVideoActivated) {
        activeCandidates.forEach((c) => this.activeAdapter.onVideoActivated(c.element));
      }
    }, 100);
    /**
     * Intercepts SPA route changes
     */
    setupSpaNavigationListener() {
      const checkNavigation = () => {
        const newUrl = new URL(window.location.href);
        if (newUrl.href !== this.currentUrl.href) {
          this.currentUrl = newUrl;
          const newDomain = getDomainFromUrl(newUrl);
          if (newDomain !== this.currentDomain) {
            this.currentDomain = newDomain;
            this.reloadConfiguration().then(() => {
              this.scheduleSelection();
            });
          }
          this.observer.scanInitialVideos();
          this.scheduleSelection();
        }
      };
      window.addEventListener("popstate", checkNavigation, { passive: true });
      window.addEventListener("hashchange", checkNavigation, { passive: true });
      const originalPushState = history.pushState;
      history.pushState = function(...args) {
        const result = originalPushState.apply(this, args);
        window.dispatchEvent(new Event("ufvc-navigation"));
        return result;
      };
      const originalReplaceState = history.replaceState;
      history.replaceState = function(...args) {
        const result = originalReplaceState.apply(this, args);
        window.dispatchEvent(new Event("ufvc-navigation"));
        return result;
      };
      window.addEventListener("ufvc-navigation", checkNavigation, { passive: true });
    }
    setupMessageListener() {
      if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
        chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
          if (message.type === "GET_STATUS") {
            sendResponse({
              domain: this.currentDomain,
              adapterId: this.activeAdapter.id,
              adapterName: this.activeAdapter.name,
              config: this.currentConfig,
              trackedCount: this.registry.size(),
              activeCount: this.controllerManager.activeCount()
            });
            return true;
          }
          return false;
        });
      }
    }
  }
  const coordinator = new ContentCoordinator();
  coordinator.initialize().catch((err) => {
    console.error("[UFVC] Initialization error:", err);
  });
})();
