const DEFAULT_SHORTCUTS = {
  togglePlay: "Space",
  seekBackward: "ArrowLeft",
  seekForward: "ArrowRight",
  volumeUp: "ArrowUp",
  volumeDown: "ArrowDown",
  toggleMute: "KeyM",
  toggleFullscreen: "KeyF"
};
const DEFAULT_GLOBAL_SETTINGS = {
  enabled: true,
  defaultSitePolicy: "universal",
  defaultTheme: "classic-dark",
  controllerPosition: "bottom-inside",
  controlsLayout: "full",
  minWidth: 160,
  minHeight: 120,
  visibilityThreshold: 0.7,
  seekInterval: 5,
  allowMultiple: true,
  autoHideDelay: 2200,
  shortcuts: DEFAULT_SHORTCUTS
};
const COMMON_TWO_PART_TLDS = /* @__PURE__ */ new Set([
  "co.uk",
  "com.au",
  "co.nz",
  "co.jp",
  "com.br",
  "com.mx",
  "co.za",
  "org.uk",
  "gov.uk"
]);
function normalizeDomain(rawHostname) {
  if (!rawHostname) return "";
  let host = rawHostname.toLowerCase().trim();
  if (host.includes(":")) {
    host = host.split(":")[0];
  }
  if (host.startsWith("www.")) {
    host = host.slice(4);
  }
  return host;
}
function extractBaseDomain(rawHostname) {
  const host = normalizeDomain(rawHostname);
  if (!host) return "";
  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(host) || host === "localhost") {
    return host;
  }
  const parts = host.split(".");
  if (parts.length <= 2) {
    return host;
  }
  const lastTwo = parts.slice(-2).join(".");
  if (COMMON_TWO_PART_TLDS.has(lastTwo)) {
    if (parts.length >= 3) {
      return parts.slice(-3).join(".");
    }
    return host;
  }
  return parts.slice(-2).join(".");
}
function domainMatches(currentHostname, targetDomainPattern) {
  const current = normalizeDomain(currentHostname);
  const target = normalizeDomain(targetDomainPattern);
  if (!current || !target) return false;
  if (current === target) {
    return true;
  }
  if (current.endsWith(`.${target}`)) {
    return true;
  }
  if (extractBaseDomain(current) === target) {
    return true;
  }
  return false;
}
const DOWNLOAD_RESTRICTED_DOMAINS = [
  "youtube.com",
  "youtu.be",
  "youtube-nocookie.com"
];
function isDownloadRestricted(urlOrHostname) {
  try {
    let hostname = "";
    const target = urlOrHostname !== void 0 ? urlOrHostname : typeof window !== "undefined" && window.location ? window.location : "";
    if (typeof target === "string") {
      try {
        hostname = new URL(target).hostname;
      } catch {
        hostname = target;
      }
    } else if (target && typeof target === "object" && "hostname" in target) {
      hostname = target.hostname || "";
    }
    if (!hostname) return false;
    return DOWNLOAD_RESTRICTED_DOMAINS.some((domain) => domainMatches(hostname, domain));
  } catch {
    return false;
  }
}
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "install") {
    const existing = await chrome.storage.sync.get(["globalSettings", "siteSettings", "customThemes"]);
    if (!existing.globalSettings) {
      await chrome.storage.sync.set({
        globalSettings: DEFAULT_GLOBAL_SETTINGS,
        siteSettings: {
          "instagram.com": {
            enabled: true,
            minWidth: 180,
            minHeight: 180,
            visibilityThreshold: 0.65,
            allowMultiple: false
          },
          "youtube.com": {
            enabled: true,
            minWidth: 120,
            minHeight: 80,
            visibilityThreshold: 0.5,
            allowMultiple: true
          }
        },
        customThemes: {}
      });
    }
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "PING") {
    sendResponse({ status: "PONG", version: chrome.runtime.getManifest().version });
    return true;
  }
  if (message.type === "DOWNLOAD_VIDEO") {
    const url = message.url;
    const filename = message.filename || `video_${Date.now()}.mp4`;
    const senderUrl = sender.tab?.url || sender.url || "";
    if (isDownloadRestricted(senderUrl) || isDownloadRestricted(url)) {
      sendResponse({ success: false, error: "Downloads are restricted on this platform per store policy." });
      return true;
    }
    if (typeof url === "string" && url.startsWith("blob:")) {
      sendResponse({ success: false, isBlob: true, error: "Blob URLs must be downloaded in tab context" });
      return true;
    }
    if (chrome.downloads) {
      chrome.downloads.download(
        {
          url,
          filename,
          saveAs: true
        },
        (downloadId) => {
          if (chrome.runtime.lastError) {
            sendResponse({ success: false, error: chrome.runtime.lastError.message });
          } else {
            sendResponse({ success: true, downloadId });
          }
        }
      );
      return true;
    } else {
      sendResponse({ success: false, error: "Downloads API unavailable" });
      return true;
    }
  }
  return false;
});
