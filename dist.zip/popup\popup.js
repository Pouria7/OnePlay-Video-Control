(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
const DEFAULT_SHORTCUTS = {
  togglePlay: "Space",
  seekBackward: "ArrowLeft",
  seekForward: "ArrowRight",
  volumeUp: "ArrowUp",
  volumeDown: "ArrowDown",
  toggleMute: "KeyM",
  toggleFullscreen: "KeyF"
};
const DEFAULT_GLOBAL_SETTINGS = {
  enabled: true,
  defaultSitePolicy: "universal",
  defaultTheme: "classic-dark",
  controllerPosition: "bottom-inside",
  controlsLayout: "full",
  minWidth: 160,
  minHeight: 120,
  visibilityThreshold: 0.7,
  seekInterval: 5,
  allowMultiple: true,
  autoHideDelay: 2200,
  shortcuts: DEFAULT_SHORTCUTS
};
const COMMON_TWO_PART_TLDS = /* @__PURE__ */ new Set([
  "co.uk",
  "com.au",
  "co.nz",
  "co.jp",
  "com.br",
  "com.mx",
  "co.za",
  "org.uk",
  "gov.uk"
]);
function normalizeDomain(rawHostname) {
  if (!rawHostname) return "";
  let host = rawHostname.toLowerCase().trim();
  if (host.includes(":")) {
    host = host.split(":")[0];
  }
  if (host.startsWith("www.")) {
    host = host.slice(4);
  }
  return host;
}
function extractBaseDomain(rawHostname) {
  const host = normalizeDomain(rawHostname);
  if (!host) return "";
  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(host) || host === "localhost") {
    return host;
  }
  const parts = host.split(".");
  if (parts.length <= 2) {
    return host;
  }
  const lastTwo = parts.slice(-2).join(".");
  if (COMMON_TWO_PART_TLDS.has(lastTwo)) {
    if (parts.length >= 3) {
      return parts.slice(-3).join(".");
    }
    return host;
  }
  return parts.slice(-2).join(".");
}
function getDomainFromUrl(urlOrLocation) {
  try {
    if (typeof urlOrLocation === "string") {
      const parsed = new URL(urlOrLocation);
      return extractBaseDomain(parsed.hostname);
    }
    return extractBaseDomain(urlOrLocation.hostname);
  } catch {
    return "";
  }
}
class StorageManager {
  inMemoryCache = {
    globalSettings: { ...DEFAULT_GLOBAL_SETTINGS },
    siteSettings: {},
    customThemes: {}
  };
  isChromeStorageAvailable() {
    return typeof chrome !== "undefined" && !!chrome.storage && (!!chrome.storage.sync || !!chrome.storage.local);
  }
  getStorageArea() {
    if (!this.isChromeStorageAvailable()) return null;
    return chrome.storage.sync || chrome.storage.local || null;
  }
  /**
   * Initializes or fetches all current settings from storage
   */
  async getAll() {
    const storage = this.getStorageArea();
    if (!storage) {
      return this.inMemoryCache;
    }
    try {
      const result = await storage.get(["globalSettings", "siteSettings", "customThemes"]);
      this.inMemoryCache = {
        globalSettings: { ...DEFAULT_GLOBAL_SETTINGS, ...result.globalSettings || {} },
        siteSettings: result.siteSettings || {},
        customThemes: result.customThemes || {}
      };
      return this.inMemoryCache;
    } catch (err) {
      console.warn("[UFVC Storage] Failed to read from chrome.storage, using in-memory cache:", err);
      return this.inMemoryCache;
    }
  }
  /**
   * Retrieves global settings
   */
  async getGlobalSettings() {
    const all = await this.getAll();
    return all.globalSettings;
  }
  /**
   * Updates global settings
   */
  async setGlobalSettings(partial) {
    const all = await this.getAll();
    all.globalSettings = { ...all.globalSettings, ...partial };
    await this.persist("globalSettings", all.globalSettings);
    return all.globalSettings;
  }
  /**
   * Retrieves settings for a specific domain
   */
  async getSiteSettings(rawDomain) {
    const domain = normalizeDomain(rawDomain);
    const all = await this.getAll();
    return all.siteSettings[domain];
  }
  /**
   * Updates or sets settings for a specific domain
   */
  async setSiteSettings(rawDomain, settings) {
    const domain = normalizeDomain(rawDomain);
    const all = await this.getAll();
    const existing = all.siteSettings[domain] || {};
    all.siteSettings[domain] = { ...existing, ...settings };
    await this.persist("siteSettings", all.siteSettings);
    return all.siteSettings[domain];
  }
  /**
   * Retrieves custom theme definitions
   */
  async getCustomThemes() {
    const all = await this.getAll();
    return all.customThemes;
  }
  /**
   * Saves or updates a custom theme definition
   */
  async saveCustomTheme(theme) {
    const all = await this.getAll();
    all.customThemes[theme.id] = theme;
    await this.persist("customThemes", all.customThemes);
  }
  /**
   * Adds an observer callback triggered whenever storage changes
   */
  onChanged(callback) {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.onChanged) {
      const listener = (changes, areaName) => {
        if (areaName === "sync" || areaName === "local") {
          if (changes.globalSettings?.newValue) {
            this.inMemoryCache.globalSettings = changes.globalSettings.newValue;
          }
          if (changes.siteSettings?.newValue) {
            this.inMemoryCache.siteSettings = changes.siteSettings.newValue;
          }
          if (changes.customThemes?.newValue) {
            this.inMemoryCache.customThemes = changes.customThemes.newValue;
          }
          callback(changes);
        }
      };
      chrome.storage.onChanged.addListener(listener);
      return () => chrome.storage.onChanged.removeListener(listener);
    }
    return () => {
    };
  }
  async persist(key, value) {
    const storage = this.getStorageArea();
    if (!storage) return;
    try {
      await storage.set({ [key]: value });
    } catch (err) {
      console.warn(`[UFVC Storage] Failed to persist ${key} to primary storage, trying fallback:`, err);
      if (chrome.storage.local && storage !== chrome.storage.local) {
        try {
          await chrome.storage.local.set({ [key]: value });
        } catch (localErr) {
          console.error("[UFVC Storage] Fallback persistence failed:", localErr);
        }
      }
    }
  }
}
const storageManager = new StorageManager();
function parseShortcut(shortcutStr) {
  if (!shortcutStr || !shortcutStr.trim()) {
    return { ctrl: false, alt: false, shift: false, meta: false, key: "" };
  }
  const parts = shortcutStr.split("+").map((p) => p.trim());
  let ctrl = false;
  let alt = false;
  let shift = false;
  let meta = false;
  let key = "";
  for (const part of parts) {
    const p = part.toLowerCase();
    if (p === "ctrl" || p === "control") {
      ctrl = true;
    } else if (p === "alt" || p === "option") {
      alt = true;
    } else if (p === "shift") {
      shift = true;
    } else if (p === "meta" || p === "cmd" || p === "command" || p === "win") {
      meta = true;
    } else {
      key = part;
    }
  }
  return { ctrl, alt, shift, meta, key };
}
function formatShortcutForDisplay(shortcutStr) {
  if (!shortcutStr) return "None";
  const parsed = parseShortcut(shortcutStr);
  const parts = [];
  if (parsed.ctrl) parts.push("Ctrl");
  if (parsed.alt) parts.push("Alt");
  if (parsed.shift) parts.push("Shift");
  if (parsed.meta) parts.push("Cmd");
  let displayKey = parsed.key;
  const lower = displayKey.toLowerCase();
  if (lower === "space") {
    displayKey = "Space";
  } else if (lower === "arrowleft" || lower === "left") {
    displayKey = "← Left";
  } else if (lower === "arrowright" || lower === "right") {
    displayKey = "→ Right";
  } else if (lower === "arrowup" || lower === "up") {
    displayKey = "↑ Up";
  } else if (lower === "arrowdown" || lower === "down") {
    displayKey = "↓ Down";
  } else if (lower.startsWith("key") && lower.length === 4) {
    displayKey = lower.substring(3).toUpperCase();
  } else if (lower.startsWith("digit") && lower.length === 6) {
    displayKey = lower.substring(5);
  }
  parts.push(displayKey);
  return parts.join(" + ");
}
const CLOUDFLARE_PAGES_UPDATE_URL = "https://anaspect-oneplay.pages.dev/version.json";
const CACHE_KEY = "ufvc_update_cache";
const DISMISSED_KEY = "ufvc_dismissed_update_version";
const CACHE_DURATION_MS = 4 * 60 * 60 * 1e3;
function detectBrowser(customUserAgent) {
  const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
  if (/Edg\//i.test(ua)) return "edge";
  if (/OPR\/|Opera/i.test(ua)) return "opera";
  if (/Firefox|FxiOS/i.test(ua)) return "firefox";
  if (/Chrome|CriOS/i.test(ua)) return "chrome";
  return "default";
}
function getBrowserDisplayName(browser) {
  switch (browser) {
    case "chrome":
      return "Google Chrome";
    case "edge":
      return "Microsoft Edge";
    case "opera":
      return "Opera";
    case "firefox":
      return "Mozilla Firefox";
    default:
      return "Browser Extension Store";
  }
}
function getBrowserRelease(versionInfo, browser = detectBrowser()) {
  const fallbackChrome = {
    version: "1.0.0",
    url: "https://chromewebstore.google.com/detail/universal-video-controls"
  };
  if (!versionInfo) {
    return fallbackChrome;
  }
  if (!versionInfo.browsers && versionInfo.latestVersion) {
    const url = versionInfo.storeUrls?.[browser] || versionInfo.storeUrls?.default || versionInfo.storeUrls?.chrome || fallbackChrome.url;
    return {
      version: versionInfo.latestVersion,
      url
    };
  }
  if (!versionInfo.browsers) {
    return fallbackChrome;
  }
  const chromeRelease = versionInfo.browsers.chrome || fallbackChrome;
  const defaultRelease = versionInfo.browsers.default || chromeRelease;
  if (browser === "default") {
    return defaultRelease;
  }
  return versionInfo.browsers[browser] || defaultRelease || chromeRelease;
}
function isNewerVersion(latest, current) {
  if (!latest || !current) return false;
  const clean = (v) => v.trim().replace(/^v/i, "").split(/[-+]/)[0].split(".").map((part) => parseInt(part, 10) || 0);
  const lParts = clean(latest);
  const cParts = clean(current);
  const maxLen = Math.max(lParts.length, cParts.length);
  for (let i = 0; i < maxLen; i++) {
    const l = lParts[i] ?? 0;
    const c = cParts[i] ?? 0;
    if (l > c) return true;
    if (l < c) return false;
  }
  return false;
}
async function fetchWithTimeout(url, timeoutMs = 5e3) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      cache: "no-cache",
      headers: { Accept: "application/json" }
    });
    return res;
  } finally {
    clearTimeout(timeoutId);
  }
}
async function fetchVersionInfo(primaryUrl = CLOUDFLARE_PAGES_UPDATE_URL) {
  try {
    const res = await fetchWithTimeout(primaryUrl);
    if (res.ok) {
      const data = await res.json();
      if (data && (data.browsers || typeof data.latestVersion === "string")) {
        return data;
      }
    }
  } catch (err) {
    console.warn("[UpdateChecker] Version metadata fetch failed:", err);
  }
  throw new Error("Could not fetch update version metadata.");
}
function getCurrentVersion() {
  if (typeof chrome !== "undefined" && chrome.runtime?.getManifest) {
    return chrome.runtime.getManifest().version || "1.0.0";
  }
  return "1.0.0";
}
async function checkForUpdates(options = {}) {
  const currentVersion = getCurrentVersion();
  const detectedBrowser = detectBrowser();
  const detectedBrowserName = getBrowserDisplayName(detectedBrowser);
  if (!options.force && typeof chrome !== "undefined" && chrome.storage?.local) {
    try {
      const cached = await chrome.storage.local.get(CACHE_KEY);
      const record = cached[CACHE_KEY];
      if (record && record.timestamp && record.versionInfo) {
        const isFresh = Date.now() - record.timestamp < CACHE_DURATION_MS;
        if (isFresh) {
          const vInfo = record.versionInfo;
          const release = getBrowserRelease(vInfo, detectedBrowser);
          const hasUpdate = isNewerVersion(release.version, currentVersion);
          return {
            hasUpdate,
            currentVersion,
            latestVersion: release.version,
            detectedBrowser,
            detectedBrowserName,
            updateUrl: release.url,
            versionInfo: vInfo,
            fromCache: true
          };
        }
      }
    } catch {
    }
  }
  try {
    const versionInfo = await fetchVersionInfo(options.endpointUrl);
    const release = getBrowserRelease(versionInfo, detectedBrowser);
    const hasUpdate = isNewerVersion(release.version, currentVersion);
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      try {
        await chrome.storage.local.set({
          [CACHE_KEY]: {
            timestamp: Date.now(),
            versionInfo
          }
        });
      } catch {
      }
    }
    return {
      hasUpdate,
      currentVersion,
      latestVersion: release.version,
      detectedBrowser,
      detectedBrowserName,
      updateUrl: release.url,
      versionInfo,
      fromCache: false
    };
  } catch (err) {
    const fallbackRelease = getBrowserRelease(void 0, detectedBrowser);
    return {
      hasUpdate: false,
      currentVersion,
      latestVersion: currentVersion,
      detectedBrowser,
      detectedBrowserName,
      updateUrl: fallbackRelease.url,
      versionInfo: null,
      fromCache: false,
      error: err?.message || "Failed to check for updates"
    };
  }
}
async function isVersionDismissed(version) {
  if (typeof chrome !== "undefined" && chrome.storage?.local) {
    try {
      const res = await chrome.storage.local.get(DISMISSED_KEY);
      return res[DISMISSED_KEY] === version;
    } catch {
      return false;
    }
  }
  return false;
}
async function dismissVersion(version) {
  if (typeof chrome !== "undefined" && chrome.storage?.local) {
    try {
      await chrome.storage.local.set({ [DISMISSED_KEY]: version });
    } catch {
    }
  }
}
document.addEventListener("DOMContentLoaded", async () => {
  const versionBadge = document.getElementById("versionBadge");
  const siteDomainName = document.getElementById("siteDomainName");
  const activeSiteBadge = document.getElementById("activeSiteBadge");
  const siteAdapterName = document.getElementById("siteAdapterName");
  const activeVideoCount = document.getElementById("activeVideoCount");
  const globalEnableToggle = document.getElementById("globalEnableToggle");
  const globalThemeSelect = document.getElementById("globalThemeSelect");
  const globalPositionSelect = document.getElementById("globalPositionSelect");
  const globalLayoutSelect = document.getElementById("globalLayoutSelect");
  const siteEnableToggle = document.getElementById("siteEnableToggle");
  const siteThemeSelect = document.getElementById("siteThemeSelect");
  const sitePositionSelect = document.getElementById("sitePositionSelect");
  const siteLayoutSelect = document.getElementById("siteLayoutSelect");
  const openOptionsBtn = document.getElementById("openOptionsBtn");
  if (versionBadge) {
    versionBadge.textContent = `v${getCurrentVersion()}`;
  }
  const runPopupUpdateCheck = async () => {
    try {
      const res = await checkForUpdates({ force: false });
      if (versionBadge) {
        versionBadge.textContent = `v${res.currentVersion || getCurrentVersion()}`;
      }
      if (res.hasUpdate && res.versionInfo) {
        const isDismissed = await isVersionDismissed(res.latestVersion);
        if (!isDismissed) {
          const banner = document.getElementById("updateBanner");
          const versionTag = document.getElementById("popupNewVersion");
          const messageElem = document.getElementById("popupUpdateMessage");
          const linkElem = document.getElementById("popupUpdateLink");
          const dismissBtn = document.getElementById("popupDismissUpdateBtn");
          if (banner && versionTag && messageElem && linkElem) {
            versionTag.textContent = `v${res.latestVersion}`;
            messageElem.textContent = res.versionInfo.message || `A new version (v${res.latestVersion}) is available.`;
            linkElem.href = res.updateUrl;
            banner.style.display = "flex";
            dismissBtn?.addEventListener("click", async (e) => {
              e.stopPropagation();
              banner.style.display = "none";
              await dismissVersion(res.latestVersion);
            });
          }
        }
      }
    } catch (err) {
      console.warn("[UFVC Popup] Update check error:", err);
    }
  };
  runPopupUpdateCheck();
  if (openOptionsBtn) {
    openOptionsBtn.addEventListener("click", () => {
      if (typeof chrome !== "undefined" && chrome.runtime?.openOptionsPage) {
        chrome.runtime.openOptionsPage();
      } else {
        window.open("options/options.html");
      }
    });
  }
  let currentDomain = "";
  let activeTabId;
  if (typeof chrome !== "undefined" && chrome.tabs?.query) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url) {
        activeTabId = tab.id;
        currentDomain = getDomainFromUrl(tab.url);
      }
    } catch (err) {
      console.warn("[UFVC Popup] Could not query active tab:", err);
    }
  }
  siteDomainName.textContent = currentDomain || "Web";
  const storageData = await storageManager.getAll();
  const globalSettings = storageData.globalSettings;
  const siteSettings = currentDomain ? storageData.siteSettings[currentDomain] || {} : {};
  Object.keys(storageData.customThemes).forEach((id) => {
    const custom = storageData.customThemes[id];
    const optGlobal = document.createElement("option");
    optGlobal.value = custom.id;
    optGlobal.textContent = `${custom.name} (Custom)`;
    globalThemeSelect.appendChild(optGlobal);
    const optSite = document.createElement("option");
    optSite.value = custom.id;
    optSite.textContent = `${custom.name} (Custom)`;
    siteThemeSelect.appendChild(optSite);
  });
  globalEnableToggle.checked = globalSettings.enabled;
  globalThemeSelect.value = globalSettings.defaultTheme || "classic-dark";
  globalPositionSelect.value = globalSettings.controllerPosition || "bottom-inside";
  globalLayoutSelect.value = globalSettings.controlsLayout || "full";
  siteEnableToggle.checked = siteSettings.enabled !== void 0 ? siteSettings.enabled : true;
  siteThemeSelect.value = siteSettings.theme || "";
  sitePositionSelect.value = siteSettings.controllerPosition || "";
  siteLayoutSelect.value = siteSettings.controlsLayout || "";
  const popScPlay = document.getElementById("popScPlay");
  const popScSeek = document.getElementById("popScSeek");
  const popScVol = document.getElementById("popScVol");
  const popScMute = document.getElementById("popScMute");
  const shortcuts = globalSettings.shortcuts || DEFAULT_SHORTCUTS;
  if (popScPlay) popScPlay.textContent = formatShortcutForDisplay(shortcuts.togglePlay);
  if (popScSeek) popScSeek.textContent = `${formatShortcutForDisplay(shortcuts.seekBackward)} / ${formatShortcutForDisplay(shortcuts.seekForward)}`;
  if (popScVol) popScVol.textContent = `${formatShortcutForDisplay(shortcuts.volumeUp)} / ${formatShortcutForDisplay(shortcuts.volumeDown)}`;
  if (popScMute) popScMute.textContent = formatShortcutForDisplay(shortcuts.toggleMute);
  if (activeTabId) {
    try {
      chrome.tabs.sendMessage(activeTabId, { type: "GET_STATUS" }, (response) => {
        if (chrome.runtime.lastError || !response) {
          activeSiteBadge.textContent = "Standby";
          activeSiteBadge.style.color = "#9ca3af";
          activeSiteBadge.style.borderColor = "#374151";
          return;
        }
        activeSiteBadge.textContent = "Active";
        if (response.adapterName) {
          siteAdapterName.textContent = `Adapter: ${response.adapterName}`;
        }
        if (response.activeCount !== void 0) {
          activeVideoCount.textContent = String(response.activeCount);
        }
      });
    } catch (err) {
      console.warn("[UFVC Popup] Content script message failed:", err);
    }
  }
  globalEnableToggle.addEventListener("change", async () => {
    await storageManager.setGlobalSettings({ enabled: globalEnableToggle.checked });
  });
  globalThemeSelect.addEventListener("change", async () => {
    await storageManager.setGlobalSettings({ defaultTheme: globalThemeSelect.value });
  });
  globalPositionSelect.addEventListener("change", async () => {
    await storageManager.setGlobalSettings({
      controllerPosition: globalPositionSelect.value
    });
  });
  globalLayoutSelect.addEventListener("change", async () => {
    await storageManager.setGlobalSettings({
      controlsLayout: globalLayoutSelect.value
    });
  });
  if (currentDomain) {
    siteEnableToggle.addEventListener("change", async () => {
      await storageManager.setSiteSettings(currentDomain, {
        enabled: siteEnableToggle.checked
      });
    });
    siteThemeSelect.addEventListener("change", async () => {
      const selectedTheme = siteThemeSelect.value ? siteThemeSelect.value : void 0;
      await storageManager.setSiteSettings(currentDomain, {
        theme: selectedTheme
      });
    });
    sitePositionSelect.addEventListener("change", async () => {
      const selectedPos = sitePositionSelect.value ? sitePositionSelect.value : void 0;
      await storageManager.setSiteSettings(currentDomain, {
        controllerPosition: selectedPos
      });
    });
    siteLayoutSelect.addEventListener("change", async () => {
      const selectedLayout = siteLayoutSelect.value ? siteLayoutSelect.value : void 0;
      await storageManager.setSiteSettings(currentDomain, {
        controlsLayout: selectedLayout
      });
    });
  } else {
    siteEnableToggle.disabled = true;
    siteThemeSelect.disabled = true;
    sitePositionSelect.disabled = true;
    siteLayoutSelect.disabled = true;
  }
});
