(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
const DEFAULT_SHORTCUTS = {
  togglePlay: "Space",
  seekBackward: "ArrowLeft",
  seekForward: "ArrowRight",
  volumeUp: "ArrowUp",
  volumeDown: "ArrowDown",
  toggleMute: "KeyM",
  toggleFullscreen: "KeyF"
};
const DEFAULT_GLOBAL_SETTINGS = {
  enabled: true,
  defaultSitePolicy: "universal",
  defaultTheme: "classic-dark",
  controllerPosition: "bottom-inside",
  controlsLayout: "full",
  minWidth: 160,
  minHeight: 120,
  visibilityThreshold: 0.7,
  seekInterval: 5,
  allowMultiple: true,
  autoHideDelay: 2200,
  shortcuts: DEFAULT_SHORTCUTS
};
const COMMON_TWO_PART_TLDS = /* @__PURE__ */ new Set([
  "co.uk",
  "com.au",
  "co.nz",
  "co.jp",
  "com.br",
  "com.mx",
  "co.za",
  "org.uk",
  "gov.uk"
]);
function normalizeDomain(rawHostname) {
  if (!rawHostname) return "";
  let host = rawHostname.toLowerCase().trim();
  if (host.includes(":")) {
    host = host.split(":")[0];
  }
  if (host.startsWith("www.")) {
    host = host.slice(4);
  }
  return host;
}
function extractBaseDomain(rawHostname) {
  const host = normalizeDomain(rawHostname);
  if (!host) return "";
  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(host) || host === "localhost") {
    return host;
  }
  const parts = host.split(".");
  if (parts.length <= 2) {
    return host;
  }
  const lastTwo = parts.slice(-2).join(".");
  if (COMMON_TWO_PART_TLDS.has(lastTwo)) {
    if (parts.length >= 3) {
      return parts.slice(-3).join(".");
    }
    return host;
  }
  return parts.slice(-2).join(".");
}
function domainMatches(currentHostname, targetDomainPattern) {
  const current = normalizeDomain(currentHostname);
  const target = normalizeDomain(targetDomainPattern);
  if (!current || !target) return false;
  if (current === target) {
    return true;
  }
  if (current.endsWith(`.${target}`)) {
    return true;
  }
  if (extractBaseDomain(current) === target) {
    return true;
  }
  return false;
}
class StorageManager {
  inMemoryCache = {
    globalSettings: { ...DEFAULT_GLOBAL_SETTINGS },
    siteSettings: {},
    customThemes: {}
  };
  isChromeStorageAvailable() {
    return typeof chrome !== "undefined" && !!chrome.storage && (!!chrome.storage.sync || !!chrome.storage.local);
  }
  getStorageArea() {
    if (!this.isChromeStorageAvailable()) return null;
    return chrome.storage.sync || chrome.storage.local || null;
  }
  /**
   * Initializes or fetches all current settings from storage
   */
  async getAll() {
    const storage = this.getStorageArea();
    if (!storage) {
      return this.inMemoryCache;
    }
    try {
      const result = await storage.get(["globalSettings", "siteSettings", "customThemes"]);
      this.inMemoryCache = {
        globalSettings: { ...DEFAULT_GLOBAL_SETTINGS, ...result.globalSettings || {} },
        siteSettings: result.siteSettings || {},
        customThemes: result.customThemes || {}
      };
      return this.inMemoryCache;
    } catch (err) {
      console.warn("[UFVC Storage] Failed to read from chrome.storage, using in-memory cache:", err);
      return this.inMemoryCache;
    }
  }
  /**
   * Retrieves global settings
   */
  async getGlobalSettings() {
    const all = await this.getAll();
    return all.globalSettings;
  }
  /**
   * Updates global settings
   */
  async setGlobalSettings(partial) {
    const all = await this.getAll();
    all.globalSettings = { ...all.globalSettings, ...partial };
    await this.persist("globalSettings", all.globalSettings);
    return all.globalSettings;
  }
  /**
   * Retrieves settings for a specific domain
   */
  async getSiteSettings(rawDomain) {
    const domain = normalizeDomain(rawDomain);
    const all = await this.getAll();
    return all.siteSettings[domain];
  }
  /**
   * Updates or sets settings for a specific domain
   */
  async setSiteSettings(rawDomain, settings) {
    const domain = normalizeDomain(rawDomain);
    const all = await this.getAll();
    const existing = all.siteSettings[domain] || {};
    all.siteSettings[domain] = { ...existing, ...settings };
    await this.persist("siteSettings", all.siteSettings);
    return all.siteSettings[domain];
  }
  /**
   * Retrieves custom theme definitions
   */
  async getCustomThemes() {
    const all = await this.getAll();
    return all.customThemes;
  }
  /**
   * Saves or updates a custom theme definition
   */
  async saveCustomTheme(theme) {
    const all = await this.getAll();
    all.customThemes[theme.id] = theme;
    await this.persist("customThemes", all.customThemes);
  }
  /**
   * Adds an observer callback triggered whenever storage changes
   */
  onChanged(callback) {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.onChanged) {
      const listener = (changes, areaName) => {
        if (areaName === "sync" || areaName === "local") {
          if (changes.globalSettings?.newValue) {
            this.inMemoryCache.globalSettings = changes.globalSettings.newValue;
          }
          if (changes.siteSettings?.newValue) {
            this.inMemoryCache.siteSettings = changes.siteSettings.newValue;
          }
          if (changes.customThemes?.newValue) {
            this.inMemoryCache.customThemes = changes.customThemes.newValue;
          }
          callback(changes);
        }
      };
      chrome.storage.onChanged.addListener(listener);
      return () => chrome.storage.onChanged.removeListener(listener);
    }
    return () => {
    };
  }
  async persist(key, value) {
    const storage = this.getStorageArea();
    if (!storage) return;
    try {
      await storage.set({ [key]: value });
    } catch (err) {
      console.warn(`[UFVC Storage] Failed to persist ${key} to primary storage, trying fallback:`, err);
      if (chrome.storage.local && storage !== chrome.storage.local) {
        try {
          await chrome.storage.local.set({ [key]: value });
        } catch (localErr) {
          console.error("[UFVC Storage] Fallback persistence failed:", localErr);
        }
      }
    }
  }
}
const storageManager = new StorageManager();
const BUILTIN_THEMES = {
  "classic-dark": {
    id: "classic-dark",
    name: "Classic Dark (Default)",
    isBuiltin: true,
    properties: {
      bg: "rgba(18, 20, 24, 0.82)",
      text: "#f3f4f6",
      accent: "#38bdf8",
      accentHover: "#7dd3fc",
      border: "1px solid rgba(255, 255, 255, 0.14)",
      radius: "10px",
      blur: "blur(8px)",
      opacity: 0.95,
      shadow: "0 8px 24px -4px rgba(0, 0, 0, 0.35)",
      scale: 1
    }
  },
  midnight: {
    id: "midnight",
    name: "Midnight OLED",
    isBuiltin: true,
    properties: {
      bg: "rgba(8, 8, 10, 0.95)",
      text: "#ffffff",
      accent: "#e2e8f0",
      accentHover: "#ffffff",
      border: "1px solid rgba(255, 255, 255, 0.18)",
      radius: "8px",
      blur: "none",
      opacity: 1,
      shadow: "0 10px 30px rgba(0, 0, 0, 0.65)",
      scale: 1
    }
  },
  glass: {
    id: "glass",
    name: "Glassmorphism",
    isBuiltin: true,
    properties: {
      bg: "rgba(255, 255, 255, 0.14)",
      text: "#ffffff",
      accent: "#38bdf8",
      accentHover: "#7dd3fc",
      border: "1px solid rgba(255, 255, 255, 0.28)",
      radius: "14px",
      blur: "blur(16px) saturate(180%)",
      opacity: 0.96,
      shadow: "0 12px 32px 0 rgba(31, 38, 135, 0.37), inset 0 1px 0 0 rgba(255, 255, 255, 0.35)",
      scale: 1
    }
  },
  "ocean-blue": {
    id: "ocean-blue",
    name: "Ocean Blue",
    isBuiltin: true,
    properties: {
      bg: "rgba(15, 23, 42, 0.88)",
      text: "#f8fafc",
      accent: "#3b82f6",
      accentHover: "#60a5fa",
      border: "1px solid rgba(59, 130, 246, 0.35)",
      radius: "10px",
      blur: "blur(10px)",
      opacity: 0.98,
      shadow: "0 8px 24px -2px rgba(14, 165, 233, 0.25)",
      scale: 1
    }
  }
};
class GenericAdapter {
  id = "generic";
  name = "Universal Generic Adapter";
  matches(_url) {
    return true;
  }
  getConfigOverrides() {
    return {};
  }
}
class InstagramAdapter {
  id = "instagram";
  name = "Instagram Web Adapter";
  matches(url) {
    return domainMatches(url.hostname, "instagram.com");
  }
  getConfigOverrides() {
    return {
      // Instagram feed and reel videos are at least 180x180px
      minWidth: 180,
      minHeight: 180,
      visibilityThreshold: 0.65,
      // Slightly more lenient threshold for scroll feeds
      allowMultiple: false
      // In Instagram feed/reels, user expects controls on the primary visible item
    };
  }
  /**
   * Filter out Instagram story preview thumbnails or background preloaders
   */
  filterVideo(video) {
    const rect = video.getBoundingClientRect();
    if (rect.width < 140 || rect.height < 140) {
      return false;
    }
    return true;
  }
  /**
   * Instagram-specific scoring:
   * Boost videos that are actively rendering frames in viewport
   */
  scoreVideo(_video, context) {
    let bonus = 0;
    if (context.isPlaying && context.intersectionRatio >= 0.65) {
      bonus += 150;
    }
    return bonus;
  }
  onVideoActivated(video) {
    video.style.pointerEvents = "auto";
  }
}
class YouTubeAdapter {
  id = "youtube";
  name = "YouTube Adapter";
  // Ensures we only attach the mouseleave listener once per preview element
  boundPreviews = /* @__PURE__ */ new WeakSet();
  audioInterceptors = /* @__PURE__ */ new WeakSet();
  matches(url) {
    return domainMatches(url.hostname, "youtube.com");
  }
  getConfigOverrides() {
    return {
      minWidth: 100,
      minHeight: 60,
      visibilityThreshold: 0.2,
      allowMultiple: false
      // Only one active preview at a time
    };
  }
  /**
   * Suppresses YouTube's automatic volume muting and event listeners on preview videos.
   */
  interceptVideoAudio(video) {
    if (this.audioInterceptors.has(video)) return;
    this.audioInterceptors.add(video);
    video.addEventListener(
      "volumechange",
      (e) => {
        e.stopImmediatePropagation();
      },
      true
      // Capture phase intercepts before YouTube's bubble/target listeners
    );
    video.removeAttribute("muted");
    if (video.muted) {
      video.muted = false;
    }
  }
  /**
   * Binds mouseleave with stopImmediatePropagation directly to ytd-video-preview once
   */
  bindPreviewElement(element) {
    if (!element || this.boundPreviews.has(element)) return;
    this.boundPreviews.add(element);
    element.addEventListener(
      "mouseleave",
      (e) => {
        e.stopImmediatePropagation();
      },
      true
    );
  }
  /**
   * YouTube Candidate Filter:
   * 1. Whitelists preview video cards (inline-player, ytd-video-preview, secondary/sidebar recommendations).
   * 2. Excludes YouTube's main watch player.
   * 3. Excludes full-screen Shorts reels.
   */
  filterVideo(video) {
    const isPreview = !!video.closest(
      "ytd-video-preview, #video-preview, #inline-preview-player, ytd-player#inline-player"
    );
    if (isPreview) {
      const previewEl = video.closest("ytd-video-preview");
      if (previewEl) {
        this.bindPreviewElement(previewEl);
      }
      return true;
    }
    const isMainWatchPlayer = !!video.closest(
      "ytd-watch-flexy, ytd-watch-grid, #player-theater-container, #full-bleed-container, #primary #player, #primary #ytd-player"
    );
    if (isMainWatchPlayer) {
      return false;
    }
    if (video.closest("ytd-shorts, ytd-reel-video-renderer")) {
      return false;
    }
    const rect = video.getBoundingClientRect();
    if (rect.width > 550 || rect.height > 420) {
      return false;
    }
    return true;
  }
  scoreVideo(_video, context) {
    if (context.isPlaying) {
      return 300;
    }
    return 100;
  }
  onVideoDetected(video) {
    this.interceptVideoAudio(video);
    const preview = video.closest("ytd-video-preview") || document.querySelector("ytd-video-preview");
    if (preview) {
      this.bindPreviewElement(preview);
    }
  }
  onVideoActivated(video) {
    this.interceptVideoAudio(video);
    const preview = video.closest("ytd-video-preview") || document.querySelector("ytd-video-preview");
    if (preview) {
      this.bindPreviewElement(preview);
    }
  }
}
class AdapterManager {
  adapters = [];
  genericAdapter = new GenericAdapter();
  constructor() {
    this.register(new InstagramAdapter());
    this.register(new YouTubeAdapter());
  }
  /**
   * Registers a site adapter
   */
  register(adapter) {
    this.adapters.push(adapter);
  }
  /**
   * Resolves the matching adapter for a given URL, falling back to GenericAdapter
   */
  resolve(url) {
    const urlObj = url instanceof URL ? url : new URL(url.href);
    for (const adapter of this.adapters) {
      try {
        if (adapter.matches(urlObj)) {
          return adapter;
        }
      } catch (err) {
        console.warn(`[UFVC AdapterManager] Error matching adapter ${adapter.id}:`, err);
      }
    }
    return this.genericAdapter;
  }
}
const adapterManager = new AdapterManager();
const MODIFIER_KEYS = /* @__PURE__ */ new Set(["Control", "Shift", "Alt", "Meta"]);
function parseShortcut(shortcutStr) {
  if (!shortcutStr || !shortcutStr.trim()) {
    return { ctrl: false, alt: false, shift: false, meta: false, key: "" };
  }
  const parts = shortcutStr.split("+").map((p) => p.trim());
  let ctrl = false;
  let alt = false;
  let shift = false;
  let meta = false;
  let key = "";
  for (const part of parts) {
    const p = part.toLowerCase();
    if (p === "ctrl" || p === "control") {
      ctrl = true;
    } else if (p === "alt" || p === "option") {
      alt = true;
    } else if (p === "shift") {
      shift = true;
    } else if (p === "meta" || p === "cmd" || p === "command" || p === "win") {
      meta = true;
    } else {
      key = part;
    }
  }
  return { ctrl, alt, shift, meta, key };
}
function eventToShortcutString(e) {
  if (MODIFIER_KEYS.has(e.key)) {
    return "";
  }
  const parts = [];
  if (e.ctrlKey) parts.push("Ctrl");
  if (e.altKey) parts.push("Alt");
  if (e.shiftKey) parts.push("Shift");
  if (e.metaKey) parts.push("Meta");
  let keyPart = e.code;
  if (!keyPart) {
    keyPart = e.key.toUpperCase();
  }
  parts.push(keyPart);
  return parts.join("+");
}
function formatShortcutForDisplay(shortcutStr) {
  if (!shortcutStr) return "None";
  const parsed = parseShortcut(shortcutStr);
  const parts = [];
  if (parsed.ctrl) parts.push("Ctrl");
  if (parsed.alt) parts.push("Alt");
  if (parsed.shift) parts.push("Shift");
  if (parsed.meta) parts.push("Cmd");
  let displayKey = parsed.key;
  const lower = displayKey.toLowerCase();
  if (lower === "space") {
    displayKey = "Space";
  } else if (lower === "arrowleft" || lower === "left") {
    displayKey = "← Left";
  } else if (lower === "arrowright" || lower === "right") {
    displayKey = "→ Right";
  } else if (lower === "arrowup" || lower === "up") {
    displayKey = "↑ Up";
  } else if (lower === "arrowdown" || lower === "down") {
    displayKey = "↓ Down";
  } else if (lower.startsWith("key") && lower.length === 4) {
    displayKey = lower.substring(3).toUpperCase();
  } else if (lower.startsWith("digit") && lower.length === 6) {
    displayKey = lower.substring(5);
  }
  parts.push(displayKey);
  return parts.join(" + ");
}
const CLOUDFLARE_PAGES_UPDATE_URL = "https://universal-video-controls.pages.dev/version.json";
const CACHE_KEY = "ufvc_update_cache";
const CACHE_DURATION_MS = 4 * 60 * 60 * 1e3;
function detectBrowser(customUserAgent) {
  const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
  if (/Edg\//i.test(ua)) return "edge";
  if (/OPR\/|Opera/i.test(ua)) return "opera";
  if (/Firefox|FxiOS/i.test(ua)) return "firefox";
  if (/Chrome|CriOS/i.test(ua)) return "chrome";
  return "default";
}
function getBrowserDisplayName(browser) {
  switch (browser) {
    case "chrome":
      return "Google Chrome";
    case "edge":
      return "Microsoft Edge";
    case "opera":
      return "Opera";
    case "firefox":
      return "Mozilla Firefox";
    default:
      return "Browser Extension Store";
  }
}
function getBrowserRelease(versionInfo, browser = detectBrowser()) {
  const fallbackChrome = {
    version: "1.0.0",
    url: "https://chromewebstore.google.com/detail/universal-video-controls"
  };
  if (!versionInfo) {
    return fallbackChrome;
  }
  if (!versionInfo.browsers && versionInfo.latestVersion) {
    const url = versionInfo.storeUrls?.[browser] || versionInfo.storeUrls?.default || versionInfo.storeUrls?.chrome || fallbackChrome.url;
    return {
      version: versionInfo.latestVersion,
      url
    };
  }
  if (!versionInfo.browsers) {
    return fallbackChrome;
  }
  const chromeRelease = versionInfo.browsers.chrome || fallbackChrome;
  const defaultRelease = versionInfo.browsers.default || chromeRelease;
  if (browser === "default") {
    return defaultRelease;
  }
  return versionInfo.browsers[browser] || defaultRelease || chromeRelease;
}
function isNewerVersion(latest, current) {
  if (!latest || !current) return false;
  const clean = (v) => v.trim().replace(/^v/i, "").split(/[-+]/)[0].split(".").map((part) => parseInt(part, 10) || 0);
  const lParts = clean(latest);
  const cParts = clean(current);
  const maxLen = Math.max(lParts.length, cParts.length);
  for (let i = 0; i < maxLen; i++) {
    const l = lParts[i] ?? 0;
    const c = cParts[i] ?? 0;
    if (l > c) return true;
    if (l < c) return false;
  }
  return false;
}
async function fetchWithTimeout(url, timeoutMs = 5e3) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      cache: "no-cache",
      headers: { Accept: "application/json" }
    });
    return res;
  } finally {
    clearTimeout(timeoutId);
  }
}
async function fetchVersionInfo(primaryUrl = CLOUDFLARE_PAGES_UPDATE_URL) {
  try {
    const res = await fetchWithTimeout(primaryUrl);
    if (res.ok) {
      const data = await res.json();
      if (data && (data.browsers || typeof data.latestVersion === "string")) {
        return data;
      }
    }
  } catch (err) {
    console.warn("[UpdateChecker] Version metadata fetch failed:", err);
  }
  throw new Error("Could not fetch update version metadata.");
}
function getCurrentVersion() {
  if (typeof chrome !== "undefined" && chrome.runtime?.getManifest) {
    return chrome.runtime.getManifest().version || "1.0.0";
  }
  return "1.0.0";
}
async function checkForUpdates(options = {}) {
  const currentVersion = getCurrentVersion();
  const detectedBrowser = detectBrowser();
  const detectedBrowserName = getBrowserDisplayName(detectedBrowser);
  if (!options.force && typeof chrome !== "undefined" && chrome.storage?.local) {
    try {
      const cached = await chrome.storage.local.get(CACHE_KEY);
      const record = cached[CACHE_KEY];
      if (record && record.timestamp && record.versionInfo) {
        const isFresh = Date.now() - record.timestamp < CACHE_DURATION_MS;
        if (isFresh) {
          const vInfo = record.versionInfo;
          const release = getBrowserRelease(vInfo, detectedBrowser);
          const hasUpdate = isNewerVersion(release.version, currentVersion);
          return {
            hasUpdate,
            currentVersion,
            latestVersion: release.version,
            detectedBrowser,
            detectedBrowserName,
            updateUrl: release.url,
            versionInfo: vInfo,
            fromCache: true
          };
        }
      }
    } catch {
    }
  }
  try {
    const versionInfo = await fetchVersionInfo(options.endpointUrl);
    const release = getBrowserRelease(versionInfo, detectedBrowser);
    const hasUpdate = isNewerVersion(release.version, currentVersion);
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      try {
        await chrome.storage.local.set({
          [CACHE_KEY]: {
            timestamp: Date.now(),
            versionInfo
          }
        });
      } catch {
      }
    }
    return {
      hasUpdate,
      currentVersion,
      latestVersion: release.version,
      detectedBrowser,
      detectedBrowserName,
      updateUrl: release.url,
      versionInfo,
      fromCache: false
    };
  } catch (err) {
    const fallbackRelease = getBrowserRelease(void 0, detectedBrowser);
    return {
      hasUpdate: false,
      currentVersion,
      latestVersion: currentVersion,
      detectedBrowser,
      detectedBrowserName,
      updateUrl: fallbackRelease.url,
      versionInfo: null,
      fromCache: false,
      error: err?.message || "Failed to check for updates"
    };
  }
}
document.addEventListener("DOMContentLoaded", async () => {
  const navItems = document.querySelectorAll(".nav-item");
  const sections = document.querySelectorAll(".content-section");
  navItems.forEach((nav) => {
    nav.addEventListener("click", (e) => {
      e.preventDefault();
      const targetTab = nav.getAttribute("data-tab");
      navItems.forEach((item) => item.classList.remove("active"));
      nav.classList.add("active");
      sections.forEach((sec) => {
        if (sec.id === `section-${targetTab}`) {
          sec.classList.add("active");
        } else {
          sec.classList.remove("active");
        }
      });
      if (targetTab) {
        history.replaceState(null, "", `#${targetTab}`);
      }
    });
  });
  const currentVersion = getCurrentVersion();
  const versionLabel = document.getElementById("optVersion");
  if (versionLabel) {
    versionLabel.textContent = `Version ${currentVersion}`;
  }
  let storageData = await storageManager.getAll();
  const optGlobalEnabled = document.getElementById("optGlobalEnabled");
  const policyUniversal = document.getElementById("policyUniversal");
  const policySelective = document.getElementById("policySelective");
  const optDefaultTheme = document.getElementById("optDefaultTheme");
  const optDefaultPosition = document.getElementById("optDefaultPosition");
  const optDefaultLayout = document.getElementById("optDefaultLayout");
  const optAllowMultiple = document.getElementById("optAllowMultiple");
  const optMinWidth = document.getElementById("optMinWidth");
  const valMinSize = document.getElementById("valMinSize");
  const optVisibility = document.getElementById("optVisibility");
  const valVisibility = document.getElementById("valVisibility");
  const optSeek = document.getElementById("optSeek");
  const valSeek = document.getElementById("valSeek");
  const optAutoHide = document.getElementById("optAutoHide");
  const valAutoHide = document.getElementById("valAutoHide");
  function initGeneralSettings() {
    const g = storageData.globalSettings;
    optGlobalEnabled.checked = g.enabled;
    if (g.defaultSitePolicy === "selective") {
      policySelective.checked = true;
    } else {
      policyUniversal.checked = true;
    }
    optDefaultTheme.value = g.defaultTheme || "classic-dark";
    optDefaultPosition.value = g.controllerPosition || "bottom-inside";
    optDefaultLayout.value = g.controlsLayout || "full";
    optAllowMultiple.checked = g.allowMultiple;
    optMinWidth.value = String(g.minWidth);
    valMinSize.textContent = `${g.minWidth} × ${g.minHeight} px`;
    optVisibility.value = String(Math.round(g.visibilityThreshold * 100));
    valVisibility.textContent = `${Math.round(g.visibilityThreshold * 100)}%`;
    optSeek.value = String(g.seekInterval);
    valSeek.textContent = `${g.seekInterval} seconds`;
    optAutoHide.value = String(g.autoHideDelay);
    valAutoHide.textContent = `${(g.autoHideDelay / 1e3).toFixed(1)} seconds`;
  }
  initGeneralSettings();
  optGlobalEnabled.addEventListener("change", async () => {
    await storageManager.setGlobalSettings({ enabled: optGlobalEnabled.checked });
  });
  const handlePolicyChange = async () => {
    const policy = policySelective.checked ? "selective" : "universal";
    await storageManager.setGlobalSettings({ defaultSitePolicy: policy });
  };
  policyUniversal.addEventListener("change", handlePolicyChange);
  policySelective.addEventListener("change", handlePolicyChange);
  optDefaultTheme.addEventListener("change", async () => {
    await storageManager.setGlobalSettings({ defaultTheme: optDefaultTheme.value });
  });
  optDefaultPosition.addEventListener("change", async () => {
    await storageManager.setGlobalSettings({
      controllerPosition: optDefaultPosition.value
    });
  });
  optDefaultLayout.addEventListener("change", async () => {
    await storageManager.setGlobalSettings({
      controlsLayout: optDefaultLayout.value
    });
  });
  optAllowMultiple.addEventListener("change", async () => {
    await storageManager.setGlobalSettings({ allowMultiple: optAllowMultiple.checked });
  });
  optMinWidth.addEventListener("input", async () => {
    const w = parseInt(optMinWidth.value, 10);
    const h = Math.round(w * 3 / 4);
    valMinSize.textContent = `${w} × ${h} px`;
    await storageManager.setGlobalSettings({ minWidth: w, minHeight: h });
  });
  optVisibility.addEventListener("input", async () => {
    const val = parseInt(optVisibility.value, 10);
    valVisibility.textContent = `${val}%`;
    await storageManager.setGlobalSettings({ visibilityThreshold: val / 100 });
  });
  optSeek.addEventListener("input", async () => {
    const s = parseInt(optSeek.value, 10);
    valSeek.textContent = `${s} seconds`;
    await storageManager.setGlobalSettings({ seekInterval: s });
  });
  optAutoHide.addEventListener("input", async () => {
    const ms = parseInt(optAutoHide.value, 10);
    valAutoHide.textContent = `${(ms / 1e3).toFixed(1)} seconds`;
    await storageManager.setGlobalSettings({ autoHideDelay: ms });
  });
  const sitesTableBody = document.getElementById("sitesTableBody");
  const siteSearchInput = document.getElementById("siteSearchInput");
  const newDomainInput = document.getElementById("newDomainInput");
  const addSiteBtn = document.getElementById("addSiteBtn");
  function renderSitesTable(filter = "") {
    sitesTableBody.innerHTML = "";
    const sites = storageData.siteSettings;
    const domains = Object.keys(sites).sort();
    const filtered = domains.filter((d) => d.toLowerCase().includes(filter.toLowerCase()));
    if (filtered.length === 0) {
      const emptyRow = document.createElement("tr");
      emptyRow.innerHTML = `<td colspan="7" style="text-align:center; color: var(--text-secondary); padding: 24px;">No configured sites found.</td>`;
      sitesTableBody.appendChild(emptyRow);
      return;
    }
    filtered.forEach((domain) => {
      const cfg = sites[domain];
      const adapter = adapterManager.resolve(new URL(`https://${domain}`));
      const tr = document.createElement("tr");
      let themeOptions = `<option value="">(Inherit Global)</option>`;
      Object.keys(BUILTIN_THEMES).forEach((tKey) => {
        const sel = cfg.theme === tKey ? "selected" : "";
        themeOptions += `<option value="${tKey}" ${sel}>${BUILTIN_THEMES[tKey].name}</option>`;
      });
      Object.keys(storageData.customThemes).forEach((cKey) => {
        const sel = cfg.theme === cKey ? "selected" : "";
        themeOptions += `<option value="${cKey}" ${sel}>${storageData.customThemes[cKey].name} (Custom)</option>`;
      });
      const positionOptions = `
        <option value="">(Inherit)</option>
        <option value="bottom-inside" ${cfg.controllerPosition === "bottom-inside" ? "selected" : ""}>Bottom (Inside)</option>
        <option value="bottom-outside" ${cfg.controllerPosition === "bottom-outside" ? "selected" : ""}>Bottom (Outside)</option>
        <option value="top-inside" ${cfg.controllerPosition === "top-inside" ? "selected" : ""}>Top (Inside)</option>
        <option value="top-outside" ${cfg.controllerPosition === "top-outside" ? "selected" : ""}>Top (Outside)</option>
      `;
      const layoutOptions = `
        <option value="">(Inherit)</option>
        <option value="full" ${cfg.controlsLayout === "full" ? "selected" : ""}>Full</option>
        <option value="minimal" ${cfg.controlsLayout === "minimal" ? "selected" : ""}>Minimal</option>
      `;
      const isEnabled = cfg.enabled !== void 0 ? cfg.enabled : true;
      tr.innerHTML = `
        <td><span class="domain-badge">${domain}</span></td>
        <td><span class="adapter-tag">${adapter.name}</span></td>
        <td>
          <label class="toggle-switch">
            <input type="checkbox" class="site-toggle" data-domain="${domain}" ${isEnabled ? "checked" : ""}>
            <span class="toggle-slider"></span>
          </label>
        </td>
        <td>
          <select class="dashboard-select site-theme-select" data-domain="${domain}">
            ${themeOptions}
          </select>
        </td>
        <td>
          <select class="dashboard-select site-position-select" data-domain="${domain}">
            ${positionOptions}
          </select>
        </td>
        <td>
          <select class="dashboard-select site-layout-select" data-domain="${domain}">
            ${layoutOptions}
          </select>
        </td>
        <td>
          <button class="btn-danger remove-site-btn" data-domain="${domain}">Reset / Remove</button>
        </td>
      `;
      sitesTableBody.appendChild(tr);
    });
    sitesTableBody.querySelectorAll(".site-toggle").forEach((toggle) => {
      toggle.addEventListener("change", async (e) => {
        const target = e.target;
        const dom = target.getAttribute("data-domain");
        await storageManager.setSiteSettings(dom, { enabled: target.checked });
      });
    });
    sitesTableBody.querySelectorAll(".site-theme-select").forEach((sel) => {
      sel.addEventListener("change", async (e) => {
        const target = e.target;
        const dom = target.getAttribute("data-domain");
        const val = target.value ? target.value : void 0;
        await storageManager.setSiteSettings(dom, { theme: val });
      });
    });
    sitesTableBody.querySelectorAll(".site-position-select").forEach((sel) => {
      sel.addEventListener("change", async (e) => {
        const target = e.target;
        const dom = target.getAttribute("data-domain");
        const val = target.value ? target.value : void 0;
        await storageManager.setSiteSettings(dom, { controllerPosition: val });
      });
    });
    sitesTableBody.querySelectorAll(".site-layout-select").forEach((sel) => {
      sel.addEventListener("change", async (e) => {
        const target = e.target;
        const dom = target.getAttribute("data-domain");
        const val = target.value ? target.value : void 0;
        await storageManager.setSiteSettings(dom, { controlsLayout: val });
      });
    });
    sitesTableBody.querySelectorAll(".remove-site-btn").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        const target = e.target;
        const dom = target.getAttribute("data-domain");
        delete storageData.siteSettings[dom];
        await chrome.storage.sync.set({ siteSettings: storageData.siteSettings });
        renderSitesTable(siteSearchInput.value);
      });
    });
  }
  renderSitesTable();
  siteSearchInput.addEventListener("input", () => {
    renderSitesTable(siteSearchInput.value);
  });
  addSiteBtn.addEventListener("click", async () => {
    const raw = newDomainInput.value.trim();
    if (!raw) return;
    const domain = normalizeDomain(raw);
    if (!domain) return;
    await storageManager.setSiteSettings(domain, { enabled: true });
    storageData = await storageManager.getAll();
    newDomainInput.value = "";
    renderSitesTable(siteSearchInput.value);
  });
  const builderThemeSelect = document.getElementById("builderThemeSelect");
  const builderThemeName = document.getElementById("builderThemeName");
  const builderBgColor = document.getElementById("builderBgColor");
  const builderTextColor = document.getElementById("builderTextColor");
  const builderAccentColor = document.getElementById("builderAccentColor");
  const builderBorderColor = document.getElementById("builderBorderColor");
  const builderOpacity = document.getElementById("builderOpacity");
  const valBuilderOpacity = document.getElementById("valBuilderOpacity");
  const builderBlur = document.getElementById("builderBlur");
  const valBuilderBlur = document.getElementById("valBuilderBlur");
  const builderRadius = document.getElementById("builderRadius");
  const valBuilderRadius = document.getElementById("valBuilderRadius");
  const builderScale = document.getElementById("builderScale");
  const valBuilderScale = document.getElementById("valBuilderScale");
  const saveThemeBtn = document.getElementById("saveThemeBtn");
  const deleteThemeBtn = document.getElementById("deleteThemeBtn");
  const mockBar = document.getElementById("mockBar");
  function hexToRgba(hex, alpha) {
    const cleanHex = hex.replace("#", "");
    const r = parseInt(cleanHex.substring(0, 2), 16) || 0;
    const g = parseInt(cleanHex.substring(2, 4), 16) || 0;
    const b = parseInt(cleanHex.substring(4, 6), 16) || 0;
    return `rgba(${r}, ${g}, ${b}, ${alpha.toFixed(2)})`;
  }
  function updateLivePreview() {
    const opacity = parseInt(builderOpacity.value, 10) / 100;
    valBuilderOpacity.textContent = `${Math.round(opacity * 100)}%`;
    const blurVal = `${builderBlur.value}px`;
    valBuilderBlur.textContent = blurVal;
    const radiusVal = `${builderRadius.value}px`;
    valBuilderRadius.textContent = radiusVal;
    const scaleVal = (parseInt(builderScale.value, 10) / 100).toFixed(2);
    valBuilderScale.textContent = `${scaleVal}x`;
    const bgRgba = hexToRgba(builderBgColor.value, opacity);
    mockBar.style.background = bgRgba;
    mockBar.style.color = builderTextColor.value;
    mockBar.style.border = `1px solid ${builderBorderColor.value}`;
    mockBar.style.borderRadius = radiusVal;
    mockBar.style.backdropFilter = `blur(${blurVal})`;
    mockBar.style.transform = `scale(${scaleVal})`;
    const progressBar = mockBar.querySelector(".mock-progress-bar");
    if (progressBar) {
      progressBar.style.backgroundColor = builderAccentColor.value;
    }
    const miniProgressBar = mockBar.querySelector(".mock-mini-progress-bar");
    if (miniProgressBar) {
      miniProgressBar.style.backgroundColor = builderAccentColor.value;
    }
    const speedBtn = mockBar.querySelector(".mock-speed-btn");
    if (speedBtn) {
      speedBtn.style.backgroundColor = builderAccentColor.value;
      speedBtn.style.color = "#000000";
    }
  }
  function refreshThemeSelectOptions() {
    builderThemeSelect.innerHTML = `<option value="new">+ Create New Custom Theme</option>`;
    Object.keys(BUILTIN_THEMES).forEach((key) => {
      builderThemeSelect.innerHTML += `<option value="builtin:${key}">${BUILTIN_THEMES[key].name} (Preset)</option>`;
    });
    Object.keys(storageData.customThemes).forEach((key) => {
      const theme = storageData.customThemes[key];
      builderThemeSelect.innerHTML += `<option value="custom:${key}">${theme.name}</option>`;
    });
  }
  refreshThemeSelectOptions();
  builderThemeSelect.addEventListener("change", () => {
    const val = builderThemeSelect.value;
    if (val === "new") {
      builderThemeName.value = "My Custom Theme";
      builderBgColor.value = "#121418";
      builderTextColor.value = "#f3f4f6";
      builderAccentColor.value = "#38bdf8";
      builderBorderColor.value = "#374151";
      builderOpacity.value = "85";
      builderBlur.value = "12";
      builderRadius.value = "12";
      builderScale.value = "100";
      deleteThemeBtn.style.display = "none";
    } else if (val.startsWith("builtin:")) {
      const bKey = val.split(":")[1];
      const theme = BUILTIN_THEMES[bKey];
      if (theme) {
        builderThemeName.value = `${theme.name} Copy`;
        builderTextColor.value = theme.properties.text;
        builderAccentColor.value = theme.properties.accent;
        builderBorderColor.value = "#374151";
        builderOpacity.value = String(Math.round(theme.properties.opacity * 100));
        builderBlur.value = theme.properties.blur.replace("px", "").replace("blur(", "").replace(")", "");
        builderRadius.value = theme.properties.radius.replace("px", "");
        builderScale.value = String(Math.round(theme.properties.scale * 100));
      }
      deleteThemeBtn.style.display = "none";
    } else if (val.startsWith("custom:")) {
      const cKey = val.split(":")[1];
      const theme = storageData.customThemes[cKey];
      if (theme) {
        builderThemeName.value = theme.name;
        builderTextColor.value = theme.textColor || "#f3f4f6";
        builderAccentColor.value = theme.accentColor || "#38bdf8";
        builderBorderColor.value = theme.borderColor || "#374151";
        builderOpacity.value = String(Math.round((theme.opacity || 0.85) * 100));
        builderBlur.value = theme.backdropBlur?.replace("px", "").replace("blur(", "") || "12";
        builderRadius.value = theme.borderRadius?.replace("px", "") || "12";
        builderScale.value = String(Math.round((theme.scale || 1) * 100));
        deleteThemeBtn.style.display = "inline-block";
      }
    }
    updateLivePreview();
  });
  [
    builderBgColor,
    builderTextColor,
    builderAccentColor,
    builderBorderColor,
    builderOpacity,
    builderBlur,
    builderRadius,
    builderScale
  ].forEach((input) => {
    input.addEventListener("input", updateLivePreview);
  });
  updateLivePreview();
  saveThemeBtn.addEventListener("click", async () => {
    const name = builderThemeName.value.trim() || "Custom Theme";
    const id = `custom-${name.toLowerCase().replace(/[^a-z0-9]/g, "-")}-${Date.now()}`;
    const opacity = parseInt(builderOpacity.value, 10) / 100;
    const bg = hexToRgba(builderBgColor.value, opacity);
    const customTheme = {
      id,
      name,
      background: bg,
      textColor: builderTextColor.value,
      accentColor: builderAccentColor.value,
      borderColor: builderBorderColor.value,
      borderRadius: `${builderRadius.value}px`,
      backdropBlur: `blur(${builderBlur.value}px)`,
      opacity,
      scale: parseInt(builderScale.value, 10) / 100
    };
    await storageManager.saveCustomTheme(customTheme);
    storageData = await storageManager.getAll();
    refreshThemeSelectOptions();
    builderThemeSelect.value = `custom:${id}`;
    deleteThemeBtn.style.display = "inline-block";
    renderSitesTable(siteSearchInput.value);
    const originalText = saveThemeBtn.textContent;
    saveThemeBtn.textContent = "Saved!";
    setTimeout(() => {
      saveThemeBtn.textContent = originalText;
    }, 1500);
  });
  deleteThemeBtn.addEventListener("click", async () => {
    const val = builderThemeSelect.value;
    if (val.startsWith("custom:")) {
      const cKey = val.split(":")[1];
      delete storageData.customThemes[cKey];
      await chrome.storage.sync.set({ customThemes: storageData.customThemes });
      refreshThemeSelectOptions();
      builderThemeSelect.value = "new";
      deleteThemeBtn.style.display = "none";
      renderSitesTable(siteSearchInput.value);
    }
  });
  const mockPositionSelect = document.getElementById("mockPositionSelect");
  const mockLayoutSelect = document.getElementById("mockLayoutSelect");
  const mockWidthSelect = document.getElementById("mockWidthSelect");
  const mockControllerHost = document.getElementById("mockControllerHost");
  if (mockPositionSelect && mockControllerHost) {
    mockPositionSelect.addEventListener("change", () => {
      mockControllerHost.className = `mock-floating-host pos-${mockPositionSelect.value}`;
    });
    mockControllerHost.className = `mock-floating-host pos-${mockPositionSelect.value}`;
  }
  if (mockLayoutSelect && mockBar) {
    mockLayoutSelect.addEventListener("change", () => {
      const isMinimal = mockLayoutSelect.value === "minimal";
      mockBar.classList.toggle("minimal-mode", isMinimal);
      if (mockControllerHost) {
        mockControllerHost.style.maxWidth = isMinimal ? "118px" : mockWidthSelect.value === "narrow" ? "280px" : "380px";
      }
    });
  }
  if (mockWidthSelect && mockControllerHost && mockBar) {
    mockWidthSelect.addEventListener("change", () => {
      const isNarrow = mockWidthSelect.value === "narrow";
      if (mockLayoutSelect.value !== "minimal") {
        mockControllerHost.style.maxWidth = isNarrow ? "280px" : "380px";
      }
      mockBar.classList.toggle("two-row", isNarrow);
    });
  }
  let shortcuts = {
    ...DEFAULT_SHORTCUTS,
    ...storageData.globalSettings.shortcuts || {}
  };
  const actionKeys = [
    "togglePlay",
    "seekBackward",
    "seekForward",
    "volumeUp",
    "volumeDown",
    "toggleMute",
    "toggleFullscreen"
  ];
  function renderShortcutsUI() {
    actionKeys.forEach((action) => {
      const btn = document.getElementById(`scBtn-${action}`);
      if (btn) {
        btn.textContent = formatShortcutForDisplay(shortcuts[action]);
        btn.classList.remove("recording");
      }
    });
  }
  renderShortcutsUI();
  let activeRecordingAction = null;
  let keydownRecordingHandler = null;
  function stopRecording() {
    if (keydownRecordingHandler) {
      window.removeEventListener("keydown", keydownRecordingHandler, true);
      keydownRecordingHandler = null;
    }
    activeRecordingAction = null;
    renderShortcutsUI();
  }
  actionKeys.forEach((action) => {
    const btn = document.getElementById(`scBtn-${action}`);
    if (!btn) return;
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (activeRecordingAction === action) {
        stopRecording();
        return;
      }
      stopRecording();
      activeRecordingAction = action;
      btn.classList.add("recording");
      btn.textContent = "Press keys...";
      keydownRecordingHandler = async (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        if (evt.key === "Escape") {
          stopRecording();
          return;
        }
        if (["Control", "Shift", "Alt", "Meta"].includes(evt.key)) {
          const parts = [];
          if (evt.ctrlKey) parts.push("Ctrl");
          if (evt.altKey) parts.push("Alt");
          if (evt.shiftKey) parts.push("Shift");
          if (evt.metaKey) parts.push("Cmd");
          btn.textContent = parts.length > 0 ? `${parts.join(" + ")} + ...` : "Press keys...";
          return;
        }
        const combo = eventToShortcutString(evt);
        if (!combo) return;
        shortcuts[action] = combo;
        await storageManager.setGlobalSettings({ shortcuts });
        stopRecording();
      };
      window.addEventListener("keydown", keydownRecordingHandler, true);
    });
  });
  const resetShortcutsBtn = document.getElementById("resetShortcutsBtn");
  if (resetShortcutsBtn) {
    resetShortcutsBtn.addEventListener("click", async () => {
      shortcuts = { ...DEFAULT_SHORTCUTS };
      await storageManager.setGlobalSettings({ shortcuts });
      stopRecording();
    });
  }
  const aboutInstalledVersion = document.getElementById("aboutInstalledVersion");
  const aboutDetectedBrowser = document.getElementById("aboutDetectedBrowser");
  const btnCheckUpdates = document.getElementById("btnCheckUpdates");
  const btnCheckUpdatesText = document.getElementById("btnCheckUpdatesText");
  const updateStatusNotice = document.getElementById("updateStatusNotice");
  const updateNoticeText = document.getElementById("updateNoticeText");
  const updateAvailableCard = document.getElementById("updateAvailableCard");
  const aboutReleaseTitle = document.getElementById("aboutReleaseTitle");
  const aboutReleaseMeta = document.getElementById("aboutReleaseMeta");
  const aboutReleaseMessage = document.getElementById("aboutReleaseMessage");
  const aboutPrimaryStoreBtn = document.getElementById("aboutPrimaryStoreBtn");
  const optUpdateBadge = document.getElementById("optUpdateBadge");
  if (aboutInstalledVersion) {
    aboutInstalledVersion.textContent = `v${currentVersion}`;
  }
  const currentBrowser = detectBrowser();
  const currentBrowserName = getBrowserDisplayName(currentBrowser);
  if (aboutDetectedBrowser) {
    aboutDetectedBrowser.textContent = currentBrowserName;
  }
  if (optUpdateBadge) {
    optUpdateBadge.addEventListener("click", () => {
      const updatesNav = document.querySelector('.nav-item[data-tab="updates"]');
      if (updatesNav) updatesNav.click();
    });
  }
  const renderUpdateUI = (res) => {
    if (!updateStatusNotice || !updateNoticeText) return;
    const installedVer = res.currentVersion || getCurrentVersion();
    if (aboutInstalledVersion) {
      aboutInstalledVersion.textContent = `v${installedVer}`;
    }
    if (res.hasUpdate && res.versionInfo) {
      updateStatusNotice.className = "update-notice update-found";
      updateNoticeText.textContent = `A new version (v${res.latestVersion}) is available for ${res.detectedBrowserName}!`;
      if (optUpdateBadge) {
        optUpdateBadge.style.display = "inline-block";
      }
      if (updateAvailableCard) {
        updateAvailableCard.style.display = "block";
        if (aboutReleaseTitle) {
          aboutReleaseTitle.textContent = res.versionInfo.title || "OnePlay - Video Control Update";
        }
        if (aboutReleaseMeta) {
          aboutReleaseMeta.textContent = `Version v${res.latestVersion}`;
        }
        if (aboutReleaseMessage) {
          aboutReleaseMessage.textContent = res.versionInfo.message || "";
        }
        if (aboutPrimaryStoreBtn) {
          aboutPrimaryStoreBtn.href = res.updateUrl;
          const btnSpan = aboutPrimaryStoreBtn.querySelector("span");
          if (btnSpan) {
            btnSpan.textContent = `Update for ${res.detectedBrowserName}`;
          }
        }
      }
    } else if (res.error) {
      updateStatusNotice.className = "update-notice error";
      updateNoticeText.textContent = `Could not reach update server (${res.error}). Please try again later.`;
      if (updateAvailableCard) updateAvailableCard.style.display = "none";
      if (optUpdateBadge) optUpdateBadge.style.display = "none";
    } else {
      updateStatusNotice.className = "update-notice up-to-date";
      updateNoticeText.textContent = `You are running the latest version of OnePlay - Video Control (v${installedVer}).`;
      if (updateAvailableCard) updateAvailableCard.style.display = "none";
      if (optUpdateBadge) optUpdateBadge.style.display = "none";
    }
    if (res.versionInfo?.browsers) {
      const b = res.versionInfo.browsers;
      const setLink = (id, url) => {
        const el = document.getElementById(id);
        if (el && url) el.href = url;
      };
      setLink("storeLinkChrome", b.chrome?.url);
      setLink("storeLinkEdge", b.edge?.url);
      setLink("storeLinkOpera", b.opera?.url);
      setLink("storeLinkFirefox", b.firefox?.url);
      setLink("storeLinkDefault", b.default?.url || b.chrome?.url);
    }
  };
  const handleCheckUpdatesClick = async (force) => {
    if (btnCheckUpdates) {
      btnCheckUpdates.classList.add("loading");
      btnCheckUpdates.disabled = true;
    }
    if (btnCheckUpdatesText) {
      btnCheckUpdatesText.textContent = "Checking for updates...";
    }
    try {
      const res = await checkForUpdates({ force });
      renderUpdateUI(res);
    } catch (err) {
      if (updateStatusNotice && updateNoticeText) {
        updateStatusNotice.className = "update-notice error";
        updateNoticeText.textContent = `Error checking for updates: ${err?.message || err}`;
      }
    } finally {
      if (btnCheckUpdates) {
        btnCheckUpdates.classList.remove("loading");
        btnCheckUpdates.disabled = false;
      }
      if (btnCheckUpdatesText) {
        btnCheckUpdatesText.textContent = "Check for Updates";
      }
    }
  };
  if (btnCheckUpdates) {
    btnCheckUpdates.addEventListener("click", () => handleCheckUpdatesClick(true));
  }
  handleCheckUpdatesClick(false);
  const initialHash = window.location.hash.replace(/^#/, "");
  if (initialHash) {
    const matchingNav = document.querySelector(`.nav-item[data-tab="${initialHash}"]`);
    if (matchingNav) {
      matchingNav.click();
    }
  }
});
